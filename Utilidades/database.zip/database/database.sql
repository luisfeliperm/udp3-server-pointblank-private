/*
 Navicat Premium Data Transfer

 Source Server         : localhost_5432
 Source Server Type    : PostgreSQL
 Source Server Version : 90519
 Source Host           : localhost:5432
 Source Catalog        : postgres
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90519
 File Encoding         : 65001

 Date: 21/11/2019 19:14:37
*/


-- ----------------------------
-- Sequence structure for account_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."account_id_seq";
CREATE SEQUENCE "public"."account_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for banimentos_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."banimentos_id_seq";
CREATE SEQUENCE "public"."banimentos_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for block_mac_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."block_mac_id_seq";
CREATE SEQUENCE "public"."block_mac_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for check_event_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."check_event_seq";
CREATE SEQUENCE "public"."check_event_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for clan_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."clan_seq";
CREATE SEQUENCE "public"."clan_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for player_items_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."player_items_id_seq";
CREATE SEQUENCE "public"."player_items_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for player_messages_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."player_messages_id_seq";
CREATE SEQUENCE "public"."player_messages_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for regras_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."regras_id_seq";
CREATE SEQUENCE "public"."regras_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for shop_good_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."shop_good_id_seq";
CREATE SEQUENCE "public"."shop_good_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for site_accounts_confirm_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."site_accounts_confirm_id_seq";
CREATE SEQUENCE "public"."site_accounts_confirm_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for site_news_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."site_news_id_seq";
CREATE SEQUENCE "public"."site_news_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for site_pincode_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."site_pincode_id_seq";
CREATE SEQUENCE "public"."site_pincode_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 32767
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for site_pincode_logs_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."site_pincode_logs_id_seq";
CREATE SEQUENCE "public"."site_pincode_logs_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 32767
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for site_recuperar_senha_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."site_recuperar_senha_id_seq";
CREATE SEQUENCE "public"."site_recuperar_senha_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Table structure for banimentos
-- ----------------------------
DROP TABLE IF EXISTS "public"."banimentos";
CREATE TABLE "public"."banimentos" (
  "id" int4 NOT NULL DEFAULT nextval('banimentos_id_seq'::regclass),
  "player" int4 NOT NULL,
  "motivo" varchar(150) COLLATE "pg_catalog"."default" NOT NULL,
  "staffer" int4 NOT NULL,
  "inicio" date NOT NULL DEFAULT (now())::date,
  "dias" int2 NOT NULL DEFAULT 3
)
;

-- ----------------------------
-- Table structure for block_mac
-- ----------------------------
DROP TABLE IF EXISTS "public"."block_mac";
CREATE TABLE "public"."block_mac" (
  "id" int2 NOT NULL DEFAULT nextval('block_mac_id_seq'::regclass),
  "mac" macaddr NOT NULL,
  "motivo" varchar(150) COLLATE "pg_catalog"."default" NOT NULL,
  "inicio" date NOT NULL DEFAULT (now())::date,
  "dias" int2 NOT NULL DEFAULT 3
)
;

-- ----------------------------
-- Table structure for clan_data
-- ----------------------------
DROP TABLE IF EXISTS "public"."clan_data";
CREATE TABLE "public"."clan_data" (
  "clan_id" int4 NOT NULL DEFAULT nextval('clan_seq'::regclass),
  "clan_rank" int4 NOT NULL DEFAULT 0,
  "clan_name" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "owner_id" int8 NOT NULL DEFAULT 0,
  "logo" int8 NOT NULL DEFAULT 0,
  "color" int4 NOT NULL DEFAULT 0,
  "clan_info" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "clan_news" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_date" int4 NOT NULL DEFAULT 0,
  "autoridade" int4 NOT NULL DEFAULT 0,
  "limite_rank" int4 NOT NULL DEFAULT 0,
  "limite_idade" int4 NOT NULL DEFAULT 0,
  "limite_idade2" int4 NOT NULL DEFAULT 0,
  "partidas" int4 NOT NULL DEFAULT 0,
  "vitorias" int4 NOT NULL DEFAULT 0,
  "derrotas" int4 NOT NULL DEFAULT 0,
  "pontos" float4 NOT NULL DEFAULT 1000,
  "max_players" int4 NOT NULL DEFAULT 50,
  "clan_exp" int4 NOT NULL DEFAULT 0,
  "best_exp" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "best_participation" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "best_wins" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "best_kills" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "best_headshot" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying
)
;

-- ----------------------------
-- Table structure for clan_invites
-- ----------------------------
DROP TABLE IF EXISTS "public"."clan_invites";
CREATE TABLE "public"."clan_invites" (
  "clan_id" int4 NOT NULL DEFAULT 0,
  "player_id" int8 NOT NULL DEFAULT 0,
  "dateinvite" int4 NOT NULL DEFAULT 0,
  "text" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying
)
;

-- ----------------------------
-- Table structure for contas
-- ----------------------------
DROP TABLE IF EXISTS "public"."contas";
CREATE TABLE "public"."contas" (
  "login" varchar(16) COLLATE "pg_catalog"."default" NOT NULL,
  "password" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "player_id" int8 NOT NULL DEFAULT nextval('account_id_seq'::regclass),
  "player_name" varchar(16) COLLATE "pg_catalog"."default" DEFAULT ''::character varying,
  "name_color" int2 NOT NULL DEFAULT 0,
  "clan_id" int4 NOT NULL DEFAULT 0,
  "rank" int2 NOT NULL DEFAULT 0,
  "gp" int4 NOT NULL DEFAULT 60000,
  "exp" int4 NOT NULL DEFAULT 0,
  "pc_cafe" int4 NOT NULL DEFAULT 0,
  "fights" int4 NOT NULL DEFAULT 0,
  "fights_win" int4 NOT NULL DEFAULT 0,
  "fights_lost" int4 NOT NULL DEFAULT 0,
  "kills_count" int4 NOT NULL DEFAULT 0,
  "deaths_count" int4 NOT NULL DEFAULT 0,
  "headshots_count" int4 NOT NULL DEFAULT 0,
  "escapes" int4 NOT NULL DEFAULT 0,
  "access_level" int2 NOT NULL DEFAULT 0,
  "lastip" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT '127.0.0.1'::character varying,
  "email" varchar(245) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "money" int4 NOT NULL DEFAULT 240000,
  "online" bool NOT NULL DEFAULT false,
  "weapon_primary" int4 NOT NULL DEFAULT 0,
  "weapon_secondary" int4 NOT NULL DEFAULT 601002003,
  "weapon_melee" int4 NOT NULL DEFAULT 702001001,
  "weapon_thrown_normal" int4 NOT NULL DEFAULT 803007001,
  "weapon_thrown_special" int4 NOT NULL DEFAULT 904007002,
  "char_red" int4 NOT NULL DEFAULT 1001001005,
  "char_blue" int4 NOT NULL DEFAULT 1001002006,
  "char_helmet" int4 NOT NULL DEFAULT 1102003001,
  "char_dino" int4 NOT NULL DEFAULT 1006003041,
  "char_beret" int4 NOT NULL DEFAULT 0,
  "brooch" int4 NOT NULL DEFAULT 10,
  "insignia" int4 NOT NULL DEFAULT 124,
  "medal" int4 NOT NULL DEFAULT 403,
  "blue_order" int4 NOT NULL DEFAULT 186,
  "mission_id1" int4 NOT NULL DEFAULT 1,
  "clanaccess" int2 NOT NULL DEFAULT 0,
  "clandate" int4 NOT NULL DEFAULT 0,
  "effects" int8 NOT NULL DEFAULT 0,
  "fights_draw" int4 NOT NULL DEFAULT 0,
  "mission_id2" int4 NOT NULL DEFAULT 0,
  "mission_id3" int4 NOT NULL DEFAULT 0,
  "totalkills_count" int4 NOT NULL DEFAULT 0,
  "totalfights_count" int4 NOT NULL DEFAULT 0,
  "status" int8 NOT NULL DEFAULT '4294967295'::bigint,
  "last_login" int8 NOT NULL DEFAULT 0,
  "clan_game_pt" int4 NOT NULL DEFAULT 0,
  "clan_wins_pt" int4 NOT NULL DEFAULT 0,
  "last_mac" macaddr NOT NULL DEFAULT '00:00:00:00:00:00'::macaddr,
  "data" timestamp(6) NOT NULL DEFAULT now(),
  "daycash" date NOT NULL DEFAULT (now() - '1 day'::interval)
)
;

-- ----------------------------
-- Records of contas
-- ----------------------------
INSERT INTO "public"."contas" VALUES ('admin', 'd660b09a70e7d3f521611b011554de5b', 2, '', 0, 0, 0, 60000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, '192.99.216.57', 'suporteprojectstar@gmail.com', 240500, 'f', 0, 601002003, 702001001, 803007001, 904007002, 1001001005, 1001002006, 1102003001, 1006003041, 0, 10, 124, 403, 186, 1, 0, 0, 0, 0, 0, 0, 0, 0, 4294967295, 0, 0, 0, '00:00:00:00:00:00', '2019-11-22 03:04:05.279274', '2019-11-22');

-- ----------------------------
-- Table structure for events_login
-- ----------------------------
DROP TABLE IF EXISTS "public"."events_login";
CREATE TABLE "public"."events_login" (
  "start_date" int8 NOT NULL DEFAULT 0,
  "end_date" int8 NOT NULL DEFAULT 0,
  "reward_id" int4 NOT NULL DEFAULT 0,
  "reward_count" int4 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Table structure for events_quest
-- ----------------------------
DROP TABLE IF EXISTS "public"."events_quest";
CREATE TABLE "public"."events_quest" (
  "start_date" int8 NOT NULL DEFAULT 0,
  "end_date" int8 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Table structure for events_visit
-- ----------------------------
DROP TABLE IF EXISTS "public"."events_visit";
CREATE TABLE "public"."events_visit" (
  "event_id" int4 NOT NULL DEFAULT nextval('check_event_seq'::regclass),
  "start_date" int8 NOT NULL DEFAULT 0,
  "end_date" int8 NOT NULL DEFAULT 0,
  "title" varchar(59) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "checks" int4 NOT NULL DEFAULT 7,
  "goods1" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "counts1" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "goods2" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "counts2" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying
)
;

-- ----------------------------
-- Table structure for events_xmas
-- ----------------------------
DROP TABLE IF EXISTS "public"."events_xmas";
CREATE TABLE "public"."events_xmas" (
  "start_date" int8 NOT NULL DEFAULT 0,
  "end_date" int8 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Table structure for friends
-- ----------------------------
DROP TABLE IF EXISTS "public"."friends";
CREATE TABLE "public"."friends" (
  "user_id" int4 NOT NULL,
  "friend_id" int4 NOT NULL,
  "state" int2 NOT NULL
)
;

-- ----------------------------
-- Table structure for info_basic_items
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_basic_items";
CREATE TABLE "public"."info_basic_items" (
  "item_id" int4 NOT NULL,
  "item_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "item_count" int2 NOT NULL,
  "item_equip" int2 NOT NULL,
  "presente" bool NOT NULL DEFAULT false
)
;

-- ----------------------------
-- Records of info_basic_items
-- ----------------------------
INSERT INTO "public"."info_basic_items" VALUES (601002002, 'MK23_SILENCER', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (702001001, 'M-7', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (702001007, 'MiniAxe', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (803007001, 'K-400', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (904007002, 'Smoke', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1001001003, 'REBEL_Female', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1001001005, 'Red Bulls', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1001002004, 'SWAT_Female', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1001002006, 'Acid Pol', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1006003041, 'Raptor', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1006003042, 'Sting', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1006003043, 'Acid', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (1102003001, 'Capacete básico', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (100003129, 'AUG_A3_BLOODY', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (200004112, ' P90_BLOODY', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (300005057, ' CHEYTAC_M200_BLOODY', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (400006030, 'M1887_BLOODY', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (601002017, 'C. Python G', 1, 3, 'f');
INSERT INTO "public"."info_basic_items" VALUES (702015003, 'Faca de Osso', 1, 3, 'f');

-- ----------------------------
-- Table structure for info_channels
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_channels";
CREATE TABLE "public"."info_channels" (
  "server_id" int4 NOT NULL DEFAULT 0,
  "channel_id" int4 NOT NULL DEFAULT 0,
  "type" int4 NOT NULL DEFAULT 0,
  "announce" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying
)
;

-- ----------------------------
-- Records of info_channels
-- ----------------------------
INSERT INTO "public"."info_channels" VALUES (1, 7, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 6, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 5, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 4, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 3, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 2, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 1, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 9, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 8, 4, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');
INSERT INTO "public"."info_channels" VALUES (1, 0, 1, 'Bem vindo ao Project Bloodi! TS3: bloodi.ts3cts.com          Respeite as regras!         Bom Jogo!');

-- ----------------------------
-- Table structure for info_cupons_flags
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_cupons_flags";
CREATE TABLE "public"."info_cupons_flags" (
  "item_id" int4 NOT NULL,
  "effect_flag" int8 NOT NULL
)
;

-- ----------------------------
-- Records of info_cupons_flags
-- ----------------------------
INSERT INTO "public"."info_cupons_flags" VALUES (1200007000, 1048576);
INSERT INTO "public"."info_cupons_flags" VALUES (1200008000, 262144);
INSERT INTO "public"."info_cupons_flags" VALUES (1200017000, 131072);
INSERT INTO "public"."info_cupons_flags" VALUES (1200026000, 32768);
INSERT INTO "public"."info_cupons_flags" VALUES (1200027000, 16384);
INSERT INTO "public"."info_cupons_flags" VALUES (1200028000, 8192);
INSERT INTO "public"."info_cupons_flags" VALUES (1200029000, 4096);
INSERT INTO "public"."info_cupons_flags" VALUES (1200030000, 2048);
INSERT INTO "public"."info_cupons_flags" VALUES (1200031000, 1024);
INSERT INTO "public"."info_cupons_flags" VALUES (1200032000, 512);
INSERT INTO "public"."info_cupons_flags" VALUES (1200033000, 65536);
INSERT INTO "public"."info_cupons_flags" VALUES (1200034000, 256);
INSERT INTO "public"."info_cupons_flags" VALUES (1200035000, 128);
INSERT INTO "public"."info_cupons_flags" VALUES (1200036000, 64);
INSERT INTO "public"."info_cupons_flags" VALUES (1200040000, 32);
INSERT INTO "public"."info_cupons_flags" VALUES (1200044000, 16);
INSERT INTO "public"."info_cupons_flags" VALUES (1200064000, 2097152);
INSERT INTO "public"."info_cupons_flags" VALUES (1200065000, 1);
INSERT INTO "public"."info_cupons_flags" VALUES (1200078000, 8);
INSERT INTO "public"."info_cupons_flags" VALUES (1200079000, 4);
INSERT INTO "public"."info_cupons_flags" VALUES (1200080000, 4194304);
INSERT INTO "public"."info_cupons_flags" VALUES (1200185000, 8388608);
INSERT INTO "public"."info_cupons_flags" VALUES (1200242000, 16777216);

-- ----------------------------
-- Table structure for info_gameservers
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_gameservers";
CREATE TABLE "public"."info_gameservers" (
  "id" int2 NOT NULL,
  "state" int2 NOT NULL,
  "type" int2 NOT NULL,
  "ip" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "port" int4 NOT NULL,
  "sync_port" int4 NOT NULL,
  "max_players" int2 NOT NULL
)
;

-- ----------------------------
-- Records of info_gameservers
-- ----------------------------
INSERT INTO "public"."info_gameservers" VALUES (1, 1, 1, '192.99.216.57', 39192, 1919, 110);
INSERT INTO "public"."info_gameservers" VALUES (0, 1, 1, '192.99.216.57', 39190, 1918, 100);

-- ----------------------------
-- Table structure for info_missions
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_missions";
CREATE TABLE "public"."info_missions" (
  "mission_id" int4 NOT NULL DEFAULT 0,
  "price" int4 NOT NULL DEFAULT 0,
  "enable" bool NOT NULL DEFAULT false
)
;

-- ----------------------------
-- Records of info_missions
-- ----------------------------
INSERT INTO "public"."info_missions" VALUES (1, 0, 'f');
INSERT INTO "public"."info_missions" VALUES (5, 5000, 't');
INSERT INTO "public"."info_missions" VALUES (6, 5000, 't');
INSERT INTO "public"."info_missions" VALUES (7, 10000, 't');
INSERT INTO "public"."info_missions" VALUES (8, 10000, 't');
INSERT INTO "public"."info_missions" VALUES (9, 12000, 't');
INSERT INTO "public"."info_missions" VALUES (10, 12000, 't');
INSERT INTO "public"."info_missions" VALUES (11, 15000, 't');
INSERT INTO "public"."info_missions" VALUES (12, 15000, 't');

-- ----------------------------
-- Table structure for info_rank_awards
-- ----------------------------
DROP TABLE IF EXISTS "public"."info_rank_awards";
CREATE TABLE "public"."info_rank_awards" (
  "rank_id" int4 NOT NULL,
  "item_id" int4 NOT NULL,
  "item_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "item_count" int4 NOT NULL,
  "item_equip" int4 NOT NULL
)
;

-- ----------------------------
-- Records of info_rank_awards
-- ----------------------------
INSERT INTO "public"."info_rank_awards" VALUES (0, 702015010, 'Faca de Osso Camo Soldier', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (0, 803007062, 'K-400 Alien', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (0, 100003163, 'AUG A3 PC Cafe', 15, 1);
INSERT INTO "public"."info_rank_awards" VALUES (1, 1300032001, 'Munição Hollow Point', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (1, 1300030001, '5% Defense Up', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (1, 601002058, 'C. Python Summer', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (2, 702001110, 'Ballistic Knife Spy', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (2, 904007061, 'Smoke Yellow', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (3, 300005148, 'Cheytac M200 Sakura', 172800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (4, 400006052, 'M1887 Summer', 172800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (5, 100003470, 'AUG_A3_ARCADE', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (5, 200004011, 'P90 Ext.', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (6, 200004110, 'Kriss S.V Turkey', 172800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (6, 1001001069, 'Bella FBI [R]', 172800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (7, 300005083, 'Cheytac M200 Brazuca', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (7, 702001052, 'Fang Blade Brazuca', 86400, 1);
INSERT INTO "public"."info_rank_awards" VALUES (8, 200004232, 'OA-93 Cobra', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (8, 601002073, 'R.B 454 SS8M+S Cobra', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (9, 702015012, 'Kunai Serpent', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (9, 803007057, 'Mummy Grenade', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (10, 100003243, 'AUG A3 Monkey', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (11, 100003304, 'Pindad SS2 V5 Mystic', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (12, 300005210, 'TACTILITE_T2_SAMURAI', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (13, 702001220, 'KARAMBIT_NEVASCA', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (14, 1001001275, 'Bella WW2', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (15, 200004341, 'P90 Ext Latin6', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (16, 100003096, 'SCAR-L FC', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (17, 1104003013, 'Crânio Mask', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (18, 1300002001, '130% EXP UP', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (19, 702001149, 'Fang Blade Alien', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (20, 100003279, 'AUG A3 Alien', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (21, 300005184, 'AS-50 PBTC2016', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (22, 200004228, 'OA-93 Medical', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (23, 200004195, 'P90 M.C. Rose', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (24, 100003151, 'TAR-21 BR Camo', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (25, 100003185, 'SC-2010 Newborn 2015', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (26, 601002072, 'C. Python VeraCruz', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (27, 702001232, 'KARAMBIT M1LGR4U', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (28, 803007077, 'K 400 M1LGR4U', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (29, 1103003031, 'Beret FireDragon', 239200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (2, 1300044001, '10% Defense Up', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (30, 400006120, 'CERBERUS FIREDRAGON', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (31, 1301047000, 'Change nickname', 3, 1);
INSERT INTO "public"."info_rank_awards" VALUES (32, 200004187, 'P90 Ext Ongame', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (33, 200004231, 'MP9 Ext. D.', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (34, 100003451, 'AUG  A3 M1LGR4U', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (34, 100003450, 'AK 47 DIGITAL', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (35, 601002068, 'R.B Mech', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (35, 702001232, 'KARAMBIT M1LGR4U', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (36, 803007077, 'K 400 M1LGR4U', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (4, 803007037, 'K-413 PC Cafe', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (36, 1001002353, 'Hide_Vacance17', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (37, 1001001356, 'REBEL_Viper_Vacance17', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (37, 100003250, 'AUG A3 Cupido', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (38, 300005290, 'CHEYTAC_M200_GRSV', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (38, 702001223, 'KARAMBIT_GRSV', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (39, 300005311, 'L115A1 WHITERABBIT', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (39, 200004332, 'OA-93 Gorgeous', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (40, 1103003034, 'BeretM1LGR4U', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (41, 200004473, 'P90_EXT_7TH_ANNIVERSARY', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (41, 300005182, 'TACTILITE_T2_PBIC2016', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (42, 702001140, 'Mini Axe Poison', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (42, 300005247, 'PGM_HECATE2_7TH_ANNIVERSARY', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (43, 100003155, 'AUG A3 Brazuca', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (43, 702001155, 'GH5007_PBIC2016', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (44, 200004478, 'MX4_PBST_ES', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (44, 601002118, 'COLTPYTHON_PBWC2017', 259200, 1);
INSERT INTO "public"."info_rank_awards" VALUES (45, 300005301, 'TACTILITE T2 M1LGR4U', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (45, 601002072, 'C. Python VeraCruz', 604800, 1);
INSERT INTO "public"."info_rank_awards" VALUES (46, 1001001286, 'General Viper[General Combo Set] [R]', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (46, 1001002287, 'General Hide[General Combo Set] [R]', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (47, 100003192, 'AUG-A3 Rose', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (47, 601002100, 'C. Python SUPREME', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (48, 300005055, 'Cheytac M200 GSL', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (49, 601002097, 'C. Python PBIC2016', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (49, 100003283, 'AUG_A3_PUZZLE', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (50, 601002081, 'Taurus 454SS Scope VeraCruz2016', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (50, 100003257, 'AUG A3 PBGC', 2592000, 1);
INSERT INTO "public"."info_rank_awards" VALUES (46, 1103003016, 'Boina E-General', 1, 3);
INSERT INTO "public"."info_rank_awards" VALUES (20, 1300027007, 'Quick Change Reload', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (35, 1300026007, 'Quick Change Weapon', 1, 1);
INSERT INTO "public"."info_rank_awards" VALUES (51, 1103003010, 'PBTN Beret', 1, 3);
INSERT INTO "public"."info_rank_awards" VALUES (51, 100003325, 'AUG_A3_MECHHERO', 1, 3);
INSERT INTO "public"."info_rank_awards" VALUES (40, 100003318, 'Aug A3 Hybridman', 604800, 1);

-- ----------------------------
-- Table structure for nick_history
-- ----------------------------
DROP TABLE IF EXISTS "public"."nick_history";
CREATE TABLE "public"."nick_history" (
  "player_id" int4 NOT NULL,
  "after" varchar(16) COLLATE "pg_catalog"."default",
  "before" varchar(16) COLLATE "pg_catalog"."default",
  "date" timestamp(6) DEFAULT now()
)
;

-- ----------------------------
-- Table structure for player_bonus
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_bonus";
CREATE TABLE "public"."player_bonus" (
  "player_id" int8 NOT NULL DEFAULT 0,
  "bonuses" int4 NOT NULL DEFAULT 0,
  "sightcolor" int4 NOT NULL DEFAULT 4,
  "freepass" int4 NOT NULL DEFAULT 0,
  "fakerank" int4 NOT NULL DEFAULT 55,
  "fakenick" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying
)
;

-- ----------------------------
-- Records of player_bonus
-- ----------------------------
INSERT INTO "public"."player_bonus" VALUES (5, 0, 4, 0, 55, '');
INSERT INTO "public"."player_bonus" VALUES (1, 0, 4, 0, 55, '');

-- ----------------------------
-- Table structure for player_configs
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_configs";
CREATE TABLE "public"."player_configs" (
  "owner_id" int8 NOT NULL DEFAULT 0,
  "config" int4 NOT NULL DEFAULT 55,
  "sangue" int4 NOT NULL DEFAULT 1,
  "mira" int4 NOT NULL DEFAULT 0,
  "mao" int4 NOT NULL DEFAULT 0,
  "audio1" int4 NOT NULL DEFAULT 100,
  "audio2" int4 NOT NULL DEFAULT 60,
  "audio_enable" int4 NOT NULL DEFAULT 7,
  "sensibilidade" int4 NOT NULL DEFAULT 50,
  "visao" int4 NOT NULL DEFAULT 70,
  "mouse_invertido" int4 NOT NULL DEFAULT 0,
  "msgconvite" int4 NOT NULL DEFAULT 0,
  "chatsussurro" int4 NOT NULL DEFAULT 0,
  "macro" int4 NOT NULL DEFAULT 31,
  "macro_1" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "macro_2" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "macro_3" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "macro_4" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "macro_5" varchar COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "keys" bytea NOT NULL DEFAULT '\x'::bytea
)
;

-- ----------------------------
-- Table structure for player_events
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_events";
CREATE TABLE "public"."player_events" (
  "player_id" int8 NOT NULL DEFAULT 0,
  "last_visit_event_id" int4 NOT NULL DEFAULT 0,
  "last_visit_sequence1" int4 NOT NULL DEFAULT 0,
  "last_visit_sequence2" int4 NOT NULL DEFAULT 0,
  "next_visit_date" int4 NOT NULL DEFAULT 0,
  "last_xmas_reward_date" int8 NOT NULL DEFAULT 0,
  "last_login_date" int8 NOT NULL DEFAULT 0,
  "last_quest_date" int8 NOT NULL DEFAULT 0,
  "last_quest_finish" int4 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Table structure for player_items
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_items";
CREATE TABLE "public"."player_items" (
  "id" int8 NOT NULL DEFAULT nextval('player_items_id_seq'::regclass),
  "owner_id" int4 NOT NULL,
  "item_id" int4 NOT NULL,
  "item_name" varchar COLLATE "pg_catalog"."default",
  "count" int8,
  "category" int2,
  "equip" int2
)
;

-- ----------------------------
-- Table structure for player_messages
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_messages";
CREATE TABLE "public"."player_messages" (
  "id" int8 NOT NULL DEFAULT nextval('player_messages_id_seq'::regclass),
  "owner_id" int4 NOT NULL,
  "sender_id" int4,
  "clan_id" int2,
  "sender_name" varchar COLLATE "pg_catalog"."default",
  "text" varchar COLLATE "pg_catalog"."default",
  "type" int2,
  "state" int2,
  "expire" int4 NOT NULL,
  "cb" int2
)
;

-- ----------------------------
-- Table structure for player_missions
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_missions";
CREATE TABLE "public"."player_missions" (
  "owner_id" int8 NOT NULL DEFAULT 0,
  "actual_mission" int4 NOT NULL DEFAULT 0,
  "card1" int4 NOT NULL DEFAULT 0,
  "card2" int4 NOT NULL DEFAULT 0,
  "card3" int4 NOT NULL DEFAULT 0,
  "card4" int4 NOT NULL DEFAULT 0,
  "mission1" bytea NOT NULL DEFAULT '\x'::bytea,
  "mission2" bytea NOT NULL DEFAULT '\x'::bytea,
  "mission3" bytea NOT NULL DEFAULT '\x'::bytea,
  "mission4" bytea NOT NULL DEFAULT '\x'::bytea
)
;

-- ----------------------------
-- Table structure for player_titles
-- ----------------------------
DROP TABLE IF EXISTS "public"."player_titles";
CREATE TABLE "public"."player_titles" (
  "owner_id" int8 NOT NULL DEFAULT 0,
  "titleequiped1" int4 NOT NULL DEFAULT 0,
  "titleequiped2" int4 NOT NULL DEFAULT 0,
  "titleequiped3" int4 NOT NULL DEFAULT 0,
  "titleflags" int8 NOT NULL DEFAULT 0,
  "titleslots" int4 NOT NULL DEFAULT 1
)
;

-- ----------------------------
-- Table structure for regras
-- ----------------------------
DROP TABLE IF EXISTS "public"."regras";
CREATE TABLE "public"."regras" (
  "id" int2 NOT NULL DEFAULT nextval('regras_id_seq'::regclass),
  "item_id" int4 NOT NULL,
  "descricao" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "camp" bool NOT NULL DEFAULT false,
  "cnpb" bool NOT NULL DEFAULT false,
  "lan" bool NOT NULL DEFAULT false,
  "_79" bool NOT NULL DEFAULT false
)
;

-- ----------------------------
-- Records of regras
-- ----------------------------
INSERT INTO "public"."regras" VALUES (401, 1105003001, 'Gorro do Papai Noel', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (156, 100003125, 'AK-47 F.C', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (138, 100003221, 'AK-47 SOPMOD Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (229, 1104003015, 'Alienígina Azul Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (140, 1103003007, 'Boina Che-Vermelha', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (464, 200004295, 'Kriss S.V Lebaran2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (477, 200004452, 'KRISSSUPERV_PBNC2017', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (410, 200004079, 'Kriss S.V PBTN', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (458, 200004275, 'Kriss S.V PBWC2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (416, 200004116, 'Kriss S.V Serpent', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (580, 200004107, 'MP9 Ext', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (98, 1001001036, 'Reinforced Bella', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (600, 1102003006, 'Target Tracking HeadGearSet[DarkSteel Assault Set]', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (601, 200004410, 'OA_93_PBWC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (602, 400006103, 'M1887_PBWC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (603, 300005292, 'SNIPER_BARRETT_PREMIUM_NUSANTARA', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (604, 300005232, 'BARRETT_PREMIUM', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (116, 1001002294, 'Hide Special Force', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (117, 1001002418, 'Chou HalloweenNurse', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (118, 1001002462, 'Chou_MintChoco', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (129, 1006003044, 'Raptor Mercury Dino (Reinforced Raptor)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (133, 200004436, 'APC9 G.', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (134, 400006004, '870MCS W.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (135, 400006011, '870MCS W. D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (136, 400006014, '870MCS SI D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (137, 400006015, '870MCS D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (139, 1102003009, 'Anel de Anjo', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (141, 1200033000, 'C4 Speed Up', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (145, 400006047, 'Cerberus', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (130, 1006003045, 'Sting Mars Dino (Reinforced Sting)', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (168, 400006010, 'M1887 W.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (167, 400006005, 'M1887', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (169, 400006017, 'M1887 D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (170, 400006021, 'M1887 SL', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (279, 1104003150, 'WC 2014 Italy Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (172, 400006030, 'M1887 Bloody', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (222, 100003114, 'M4A1 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (237, 1104003033, 'Jester_BW Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (173, 400006033, 'M1887 W TH 1st Anniversary', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (174, 400006034, 'M1887 R', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (444, 200004223, 'Kriss S.V Basketball', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (887, 1200065000, 'Bulletproof Vest 90%', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (220, 100003052, 'FAMAS G2 M203', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (488, 200004659, 'SMG_KRISSSUPERV_SILENCE_RENEGADE2', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (403, 200004013, 'Kriss S.V', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (428, 200004168, 'Kriss S.V Especial de Natal', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (409, 200004060, 'Kriss S.V IC', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (460, 200004280, 'Kriss S.V ID 1stAnni', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (483, 200004598, 'KRISSSUPERV DIGITAL', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (383, 1103003009, 'Cross Knife Beret', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (119, 702001018, 'Ballistic Knife', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (127, 702015008, 'Kunai', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (515, 100003270, 'Pindad SS2 V5 Silver', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (380, 1103003016, 'Boina E-General', 'f', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (888, 1104003049, 'Latin Chile', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (889, 1105003016, 'Monkey', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (890, 1103003019, 'BeretID1stAnni', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (891, 702001007, 'Mini Axe', 'f', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (892, 702001012, 'Mini Axe D', 'f', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (534, 100003381, 'SC_2010_7TH_ANNIVERSARY', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (581, 100003316, 'Pindad SS2 V5 Ice', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (148, 400006120, 'CERBERUS FIREDRAGON', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (641, 100003246, 'AK 12', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (179, 400006049, 'M1887 GSL2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (640, 100003247, 'AK 12 Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (195, 400006069, 'M1887 Skeleton', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (209, 400006085, 'M1887 Mystic', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (358, 400006016, 'SPAS-15 SI D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (126, 702001080, 'Field Shovel Royal', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (125, 702001025, 'Field Shovel', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (629, 100003275, 'AUG A3 Dolphin', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (163, 100003289, 'Groza Russian Deluxe', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (230, 1104003016, 'Alienígina Vermelho Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (123, 702001153, 'Ballistic Knife Russian Deluxe', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (122, 702001151, 'Ballistic Knife Russian Normal', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (120, 702001110, 'Ballistic Knife Spy', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (144, 1300034030, 'C4 Speed Up', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (143, 1300034007, 'C4 Speed Up', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (142, 1300034001, 'C4 Speed Up', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (146, 400006084, 'Cerberus Gorgeous', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (147, 400006118, 'Cerberus_Kemerde', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (124, 702001058, 'Chinese Cleaver', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (271, 1104003142, 'WC 2014 Argentina Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (281, 1104003152, 'WC 2014 Korea Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (151, 1105003010, 'Chapéu Cangaceiro', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (152, 1105003012, 'Chapéu da Independência', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (153, 1105003013, 'Chapéu Camo Soldier', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (154, 1105003014, 'Chapéu de Cowboy (GM)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (270, 1104003137, 'TH 1st Anniversary Mask', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (157, 100003218, 'SCAR-L F.C PBNC2015US', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (158, 904007013, 'FlashBang Plus', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (224, 1104003008, 'Hockey Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (164, 1102003002, 'Normal Headgear', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (165, 1102003008, 'Super Headgear', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (225, 1104003011, 'Pink Death Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (226, 1104003012, 'Golden Smile Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (227, 1104003013, 'Crânio Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (228, 1104003014, 'Palhaço Assassino Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (175, 400006035, 'M1887 PBNC5', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (176, 400006037, 'M1887 Brazuca', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (177, 400006038, 'M1887 PBIC2014', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (180, 400006052, 'M1887 Summer', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (181, 400006053, 'M1887 PBNC2015', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (182, 400006055, 'M1887 PBTC2015', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (183, 400006056, 'M1887 Mech', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (184, 400006058, 'M1887 PBIC2015', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (185, 400006059, 'M1887 Gold', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (186, 400006060, 'M1887 Medical', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (187, 400006061, 'M1887 Steam', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (188, 400006062, 'M1887 Obsidian', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (189, 400006063, 'M1887 Arena Normal', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (190, 400006064, 'M1887 Arena Deluxe', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (191, 400006065, 'M1887 Cupid', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (192, 400006066, 'M1887 GRS3', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (193, 400006067, 'M1887 Beast', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (194, 400006068, 'M1887 PBGC', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (197, 400006071, 'M1887 ID 1stAnni', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (198, 400006072, 'M1887 Dolphin', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (199, 400006074, 'M1887 Lebaran2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (200, 400006075, 'M1887 Woody', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (201, 400006076, 'M1887 Newborn2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (202, 400006077, 'M1887 Liberty', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (203, 400006078, 'M1887 PBIC2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (204, 400006079, 'M1887 PBTC2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (205, 400006080, 'M1887 Dark Steel', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (206, 400006081, 'M1887 PBNC2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (207, 400006082, 'M1887 SUPREME', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (208, 400006083, 'M1887 Gorgeous', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (210, 400006105, 'M1887_LEBARAN2017', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (893, 100003406, 'AUG_HBAR', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (587, 100003324, 'AUG A3 GRS4', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (591, 100003300, 'AUG A3 Halloween 2016', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (586, 100003315, 'AUG A3 Ice', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (623, 100003294, 'AUG A3 PBTC2016', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (642, 100003241, 'AUG A3 X-MAS 2015', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (589, 100003326, 'FAMAS G2 Fire', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (391, 1301646000, 'Random Box Elite Pro', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (221, 100003264, 'Famas G2 M203 E-Sport2', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (622, 100003282, 'FAMAS G2 Newborn2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (632, 100003254, 'Water Gun 2016', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (583, 400006102, 'M1187 Green', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (584, 400006099, 'M1887 Beach', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (595, 400006092, 'SPAS-15 Fire', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (596, 400006090, 'M1887 GRS4', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (597, 702001098, 'Hair Dryer', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (598, 702001097, 'Hair Dryer Indonesia', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (619, 702001143, 'Amok Kukri Poison', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (620, 702001139, 'Amok Kukri Mummy', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (621, 702001137, 'Amok Kukri PBWC 2016', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (624, 702001146, 'Death Scythe Demonic', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (626, 400006114, 'UTS-15 Newborn 2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (633, 702001041, 'Arabian Sword', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (637, 702001049, 'Arabian Sword2', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (638, 100003239, 'M14 EBR Gold', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (645, 100003223, 'M14 EBR', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (646, 702001073, 'Chinese Cleaver CNY 2015', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (650, 702001083, 'Nunchaku', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (651, 702001082, 'Arabian Sword Midnight', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (659, 702001069, 'Ice Trident', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (234, 1104003020, 'Máscara de Páscoa Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (731, 100003086, 'AK-47 Goddess', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (695, 100003122, 'AK-47 PBIC2013', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (727, 100003099, 'AK SOPMOD GRS', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (132, 904007005, 'WP Smoke', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (721, 100003101, 'AK SOPMOD PBNC', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (96, 1001001015, 'Reinforced Combo D-Fox (+20% EXP)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (717, 100003092, 'AK SOPMOD R', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (676, 100003178, 'AUG A3 CoupleBreaker', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (733, 100003062, 'FAMAS G2 Commando E-Sports', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (704, 100003105, 'FAMAS G2 Commando GSL', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (719, 100003091, 'FAMAS G2 Commando PBTN', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (722, 100003100, 'FAMAS G2 GRS', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (712, 100003113, 'FAMAS G2 GRS EV', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (730, 100003087, 'FAMAS G2 Silver', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (720, 100003090, 'FAMAS G2 White Digital', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (697, 200004391, 'Kriss S.V Beach', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (672, 200004465, 'Kriss S.V Brightness', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (677, 200004468, 'Kriss S.V Darkness', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (726, 200004357, 'Kriss S.V GRS4', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (708, 200004403, 'Kriss S.V Midnight3', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (686, 200004441, 'Kriss S.V Vacance2017', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (700, 300005169, 'L115A1 Dolphin', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (131, 1006003046, 'Acid Vulcan Dino (Reinforced Acid)', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (97, 1001001017, 'Reinforced Combo Viper Red (+30% Gold)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (99, 1001001054, 'WC 2014 Tarantula', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (100, 1001001055, 'Viper Shadow', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (101, 1001001068, 'Viper Kopassus', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (102, 1001001069, 'Bella FBI', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (103, 1001001283, 'Pirate Tarantula', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (104, 1001001295, 'Viper Red Special Force', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (105, 1001001415, 'Bella HalloweenNurse', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (660, 100003209, 'Vz.52 Black Pearl', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (670, 200004467, 'P90 Ext. Brightness', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (674, 200004470, 'P90 Ext. Darkness', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (680, 702001011, 'Amok Kukri D', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (683, 200004443, 'OA-93 Vacance2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (690, 904007007, 'WP Smoke D', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (694, 601013008, 'C. Python Cutlass', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (703, 601014022, 'Scorpion Vz.61 Newborn 2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (705, 601014023, 'Scorpion Prasasti', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (707, 601014021, 'Scorpion Vz.61 Gorgeous', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (713, 200004405, 'OA-93 Midnight3', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (716, 200004362, 'OA-93 Mech Hero', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (718, 200004361, 'P90 Ext. GRS4', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (724, 200004359, 'OA-93 GRS4', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (106, 1001001465, 'Bella_PinkChoco', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (107, 1001002016, 'Reinforced Combo Leopard (+20% EXP)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (108, 1001002018, 'Reinforced Combo Hide (+30% Gold)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (109, 1001002035, 'Reinforced Chou', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (110, 1001002051, 'Hide Kopassus', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (111, 1001002053, 'WC 2014 Hide', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (112, 1001002056, 'Hide Recon', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (113, 1001002067, 'Hide Strike', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (114, 1001002144, 'Chou FBI', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (115, 1001002287, 'General Hide', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (735, 100003059, 'AK-47 Non Ext', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (736, 100003058, 'AK-47 Full Custom', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (737, 100003068, 'AK-47 FC Red', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (824, 100003336, 'AUG A3 Samurai', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (797, 100003367, 'AUG A3 Vacance2017', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (822, 100003342, 'AK-47 Ext Chicano', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (816, 100003346, 'AK-47 Ext Comic', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (760, 100003002, 'AK-47 Ext.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (742, 100003054, 'AK-47 G. D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (756, 100003017, 'AK-47 Silver', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (746, 100003025, 'AK-47 Silver +', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (752, 100003015, 'AK SOPMOD', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (740, 100003041, 'AK SOPMOD CG', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (749, 100003039, 'AK SOPMOD D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (886, 1200079000, 'Bulletproof Vest 20%', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (819, 100003343, 'AUG A3 Beach', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (789, 100003378, 'AUG A3 Brightness', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (788, 100003379, 'AUG A3 Darkness', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (814, 100003347, 'AUG A3 Green', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (810, 100003349, 'AUG A3 Midnight3', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (743, 100003049, 'FAMAS G2', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (745, 100003050, 'FAMAS G2 Com', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (818, 100003332, 'FAMAS G2 Comando Talos', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (739, 100003064, 'FAMAS G2 Commando Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (812, 100003351, 'FAMAS G2 Commando PBWC 2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (744, 100003051, 'FAMAS G2 Sniper', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (820, 601002024, 'Kriss Vector SDP', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (771, 601002074, 'Kriss Vector SDP Camo Soldier', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (770, 601002069, 'Kriss Vector SDP DarkDays', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (778, 601002111, 'Kriss Vector SDP Fire', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (656, 904007060, 'Blue Smoke', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (658, 904007061, 'Yellow Smoke', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (689, 300005213, 'PGM Hecate2 Beach', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (777, 601002110, 'Kriss Vector SDP Mech Hero', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (786, 601002093, 'Kriss Vector SDP Puzzle', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (593, 702001103, 'Bambu Runcing', 'f', 'f', 'f', 't');
INSERT INTO "public"."regras" VALUES (585, 100003313, 'Cane Gun', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (588, 400006108, 'Zombie Slayer Infinitum', 't', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (590, 400006087, 'Cane Shotgun', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (599, 400006088, 'Zombie Slayer Ice', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (639, 400006019, 'JackHammer', 't', 'f', 'f', 't');
INSERT INTO "public"."regras" VALUES (661, 300005217, 'AS-50 Midnight3', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (252, 1104003097, 'Angry Cartoon Mask Set (Respect Meme)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (709, 200004402, 'P90 Ext. Green', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (711, 200004400, 'Kriss S.V Green', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (872, 1103003026, 'Beret Green', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (747, 200004291, 'P90 Ext. Dolphin', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (755, 300005082, 'Barret M82A1 P.', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (563, 100003096, 'SCAR-L FC', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (757, 601002128, 'R.B 454 SS8M+S Brightness', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (873, 1103003024, 'Fire Beret', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (758, 601002129, 'R.B 454 SS8M+S Darkness', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (759, 300005032, 'Barret M82A1', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (762, 601002115, 'Glock 18 Samurai', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (763, 601002112, 'TEC-9', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (764, 601002113, 'TEC-9 Silver', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (766, 601002123, 'C.Python Vacance2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (769, 803007066, 'FootBall Bomb2016', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (773, 601002054, 'GL-06 ANC 2015', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (776, 601002106, 'C. Python Ice', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (782, 200018004, 'Dual Uzi', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (278, 1104003149, 'WC 2014 Germany Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (290, 1104003161, 'WC 2014 Netherlands Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (292, 1104003163, 'WC 2014 Bosnia and Herzegovina Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (308, 1104003235, 'ID 1stAnni Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (341, 601014017, 'Scorpion Vz.61', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (373, 400006042, 'Zombie Slayer', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (783, 200018005, 'Dual Mini Uzi', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (785, 803007072, 'K-400 Fire', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (787, 702001173, 'Ice Terrent Fire', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (792, 702001180, 'Arabian Sword Beach', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (793, 500010013, 'Ultimax-100 Madness', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (794, 500010012, 'Ultimax-100 Gold', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (795, 702001158, 'Dual Sword PBTC2016', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (796, 500010015, 'L86 LSW Beach', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (798, 500010014, 'Ultimax-100 Mummy', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (799, 500010009, 'L86 LSW XMAS', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (800, 500010011, 'Ultimax-100', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (801, 500010010, 'MK.46 Non Ext', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (803, 500010004, 'L86 LSW', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (804, 500010007, 'RPD SI', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (805, 500010001, 'Mk 46 Ext.', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (806, 702001162, 'Halloween Hammer', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (807, 500010003, 'RPD', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (808, 702001160, 'Arabian Sword PBNC 2016', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (809, 500010002, 'Mk 46 Silver', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (813, 803007033, 'Soccer Grenade', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (815, 702001200, 'Kukri Newborn 2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (817, 702015015, 'Dual Sword PBTC2016', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (821, 702001196, 'Arabian Sword Phantom', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (823, 702015018, 'Dual Sword Samurai', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (825, 601002029, 'GL-06', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (826, 702015016, 'Dual Bone Knife GRS4', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (827, 200004431, 'OA-93 Kareem', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (836, 200004383, 'OA-93 GSL 2017', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (840, 1001002175, 'Undercover Hide', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (841, 1001001137, 'Hitman D-Fox', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (842, 1001002225, 'Hitman Leopard', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (846, 1001002019, 'Reinforced Acid Poll', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (848, 1001002020, 'Reinforced Keen Eyes', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (849, 1001001022, 'Reinforced Tarantula', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (850, 1001001021, 'Reinforced Red Bulls', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (851, 1001001011, 'Reinforced D-Fox', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (856, 1001002012, 'Reinforced Leopard', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (860, 1001001087, 'Gengster Viper Red', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (863, 1001002052, 'Leopard Bope', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (874, 1001002282, 'Swat sniper', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (879, 1001001268, 'Poather Tarantula', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (880, 1001002270, 'SAS Kin Yeis', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (885, 1200028000, 'Life extra 10%', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (211, 400006106, 'M1887_NAGI_BASIC', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (212, 400006107, 'M1887_NAGI_DELUXE', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (213, 400006113, 'M1887_PBNC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (214, 400006117, 'M1887_Kemerde', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (215, 400006119, 'M1887_PBIC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (216, 400006144, 'M1887 DIGITAL', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (217, 400006146, 'SHOTGUN M1887 PBWC2018', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (218, 400006152, 'M1887_ARCADE', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (219, 400006156, 'SHOTGUN_M1887_RENEGADE2', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (223, 1301650000, 'Random Box M4A1 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (241, 1104003038, 'Kazahstan Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (240, 1104003037, 'Belorus Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (242, 1104003040, 'Besiktas FC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (236, 1104003032, 'Tigre Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (231, 1104003017, 'Máscara Templária Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (247, 1104003072, 'Raptr Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (239, 1104003036, 'Ukraine Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (232, 1104003018, 'Jason Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (233, 1104003019, 'Panda Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (235, 1104003021, 'Death Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (238, 1104003034, 'Wrestling Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (243, 1104003041, 'Bursapor FC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (244, 1104003042, 'Fenerbahce FC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (245, 1104003043, 'Galatasaray FC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (249, 1104003076, 'Indonesia Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (246, 1104003044, 'Trabzonspor FC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (258, 1104003117, 'Gatotkaca Gold Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (248, 1104003073, 'Canada Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (255, 1104003101, 'Mask Frail Skull Gold', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (263, 1104003124, 'Black Snake Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (264, 1104003125, 'Egg Tarantula Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (250, 1104003079, 'Red Eyes Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (260, 1104003121, 'Garena Gold Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (256, 1104003113, 'Gatotkaca Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (268, 1104003135, 'LATIN3 Premium Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (257, 1104003115, 'Mask set of Korea marine corps', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (259, 1104003118, 'PBSC Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (276, 1104003147, 'WC 2014 England Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (266, 1104003127, 'Egg RedBulls Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (274, 1104003145, 'WC 2014 Colombia Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (261, 1104003122, 'Garena Red Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (269, 1104003136, 'Unicorn Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (262, 1104003123, 'Garena White Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (272, 1104003143, 'WC 2014 Brazil Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (273, 1104003144, 'WC 2014 Chile Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (265, 1104003126, 'GSL Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (267, 1104003134, 'LATIN3 Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (280, 1104003151, 'WC 2014 Japan Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (277, 1104003148, 'WC 2014 France Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (282, 1104003153, 'WC 2014 Spain Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (155, 100003045, 'M4 SR-16 F.C.', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (166, 1104003099, 'Trex Headgear', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (171, 400006026, 'M1887 W GRS', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (149, 1105003004, 'Chapéu de Cowboy', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (150, 1105003008, 'Chapéu Kopassus', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (394, 1301649000, 'Random Box G36C Elite', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (395, 1301651000, 'Random Box PSG1 Elite', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (396, 1301653000, 'Random Box SVU Elite', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (397, 1301654000, 'Random Box VSK94 Elite', 't', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (772, 803007053, 'Water Bomb', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (325, 904007025, 'Medical Kit Opor Ayam', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (285, 1104003156, 'WC 2014 Honduras Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (312, 1104003262, 'Mask Mystic Blue', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (844, 1001001302, 'P1000 Tarantula', 't', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (837, 300005209, 'AS-50 GSL 2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (790, 702001168, 'Chicken Hummer', 'f', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (253, 1104003098, 'Crazy Cartoon Mask Set (Ffuu Meme)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (254, 1104003100, 'Trojan Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (811, 100003348, 'SC-2010 Green', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (287, 1104003158, 'WC 2014 CostaRica Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (288, 1104003159, 'GSL 2014 Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (294, 1104003165, 'WC 2014 Croatia Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (360, 400006032, 'SPAS-15 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (361, 400006040, 'SPAS-15 NonLogo PBSC2013', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (372, 100003281, 'XM8 Woody', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (295, 1104003166, 'WC 2014 Portugal Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (296, 1104003167, 'WC 2014 Ghana Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (297, 1104003168, 'WC 2014 Nigeria Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (298, 1104003169, 'WC 2014 Algeria Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (299, 1104003170, 'WC 2014 Cameroon Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (300, 1104003171, 'WC 2014 Cote dIvoire Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (305, 1104003177, 'Mask Midnight', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (326, 904007029, 'Medical Kit PBNC5', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (347, 200004285, 'P90 Ext. Silence Strike', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (335, 200004486, 'OA93_MILITARY', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (284, 1104003155, 'WC 2014 Uruguay Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (306, 1104003178, 'Brazuca Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (307, 1104003179, 'Indonesia Mask (GW)', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (343, 601014020, 'Scorpion Vz.61 Woody', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (336, 200004498, 'OA93 HALLOWEEN2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (339, 200004641, 'OA93_ARCADE', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (283, 1104003154, 'WC 2014 U.S.A Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (313, 1104003270, 'Mask Black Skull', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (286, 1104003157, 'WC 2014 Mexico Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (321, 904007011, 'Medical Kit', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (315, 1301507000, 'Random Box of Masks', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (289, 1104003160, 'WC 2014 Greece Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (367, 601002114, 'Tec-9G', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (304, 1104003176, 'Egg KeenEyes Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (369, 400006046, 'UTS-15 D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (323, 904007015, 'Chocolate Medical Kit', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (291, 1104003162, 'WC 2014 Belgium Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (324, 904007021, 'Medical Kit Lotus', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (293, 1104003164, 'WC 2014 Switzerland Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (301, 1104003172, 'WC 2014 Iran Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (302, 1104003173, 'WC 2014 Australia Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (386, 300005075, 'PSG1 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (387, 300005076, 'Dragunov Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (390, 1006003032, 'Elite Dino', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (330, 200004607, 'SMG_OA_93_PBWC2018', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (331, 200004349, 'OA93 Hybridman', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (332, 200004455, 'OA93_PBNC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (333, 200004461, 'OA93_Kemerde', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (334, 200004474, 'OA93_AGUILA', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (303, 1104003174, 'WC 2014 Russia Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (309, 1104003236, 'Demonic Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (337, 200004522, 'OA93 FIREDRAGON', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (338, 200004572, 'OA93_GRSV', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (342, 601014018, 'Scorpion Vz.61 G.', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (340, 200004657, 'SMG_OA93_RENEGADE2', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (406, 200004039, 'Kriss S.V Black', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (402, 200004005, 'Kriss S.V Cupido', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (405, 200004030, 'Kriss S.V D', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (407, 200004050, 'Kriss S.V E-Sport', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (404, 200004026, 'Kriss S.V Gold', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (411, 200004083, 'Kriss S.V GRS', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (412, 200004087, 'Kriss S.V GSL', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (413, 200004103, 'Kriss S.V PBIC2013', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (415, 200004115, 'Kriss S.V Sakura', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (345, 200004108, 'Kriss S.V Silence', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (414, 200004110, 'Kriss S.V Turkey', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (408, 200004054, 'Kriss S.V Vector', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (400, 1103003008, 'Yellow Star Beret', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (375, 1103003031, 'Beret FireDragon', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (378, 1103003013, 'Boina Kopassus', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (310, 1104003238, 'Mask Puzzle', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (311, 1104003251, 'Phantom Mask', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (344, 100003010, 'M4A1 Camoflage with Silencer', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (346, 200004182, 'P90 Ext Silence GSL2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (348, 200004288, 'P90 Ext. Silence Demonic', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (349, 200018007, 'Dual Uzi Silencer', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (352, 200018011, 'Dual Micro Uzi Silencer Sl.', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (350, 200018008, 'Dual Mini Uzi Silencer', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (351, 200018009, 'Dual Micro Uzi Silencer', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (354, 1301202000, 'Random Box Silence', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (314, 1104003273, 'Mask New Generation', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (355, 400006003, 'SPAS-15', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (356, 400006006, 'SPAS-15 SL', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (357, 400006012, 'SPAS-15 D', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (359, 400006018, 'SPAS-15 MSC', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (366, 100003151, 'TAR-21 BR Camo', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (362, 400006054, 'SPAS-15 PBNC2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (363, 400006057, 'SPAS-15 MSC PBNC2015 U.S.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (364, 400006073, 'SPAS-15 Blue Diamond', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (365, 1301652000, 'Random Box SPAS-15 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (368, 400006039, 'UTS-15', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (318, 1300028001, 'MAX HP Up 10%', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (370, 400006048, 'UTS-15 G.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (319, 1300028007, 'MAX HP Up 10%', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (371, 100003177, 'XM8 GOLD', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (320, 1300028030, 'MAX HP Up 10%', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (385, 100003146, 'G36C Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (388, 300005077, 'SVU Elite', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (389, 300005078, 'VSK94 Elite', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (328, 904007043, 'Medical Kit Kurma', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (329, 904007051, 'Medical Kit PBNC2015', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (392, 1301647000, 'Random Box AK Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (393, 1301648000, 'Random Box Dragunov Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (398, 100003103, 'M4 SR-16 D Hunter', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (489, 100003167, 'AN-94 Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (539, 100003123, 'TAR-21', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (519, 100003154, 'SC-2010 Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (518, 100003153, 'SC-2010', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (520, 100003185, 'SC-2010 Newborn 2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (521, 100003191, 'SC-2010 Rose', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (522, 100003226, 'SC-2010 Medical', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (523, 100003242, 'SC-2010 XMAS2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (524, 100003273, 'SC-2010 Strike', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (525, 100003276, 'SC-2010 Dolphin', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (526, 100003287, 'SC-2010 Dracula', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (527, 100003292, 'SC-2010 PBIC2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (322, 904007014, 'Halloween Medical Kit', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (327, 904007032, 'Medical Kit Lotus2014', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (384, 100003119, 'AK-47 Elite', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (317, 1200027000, 'MAX HP Up 10%', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (374, 100003152, 'AK SOPMOD BR Camo', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (548, 100003274, 'AUG A3 Demonic', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (376, 1103003006, 'Boina Negra', 'f', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (512, 100003118, 'Pindad SS2-V4 Para Sniper Reload', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (513, 100003268, 'Pindad SS2 V5', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (514, 100003269, 'Pindad SS2 V5 Gold', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (516, 100003297, 'Pindad SS2 V5 PBNC2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (517, 100003304, 'Pindad SS2 V5 Mystic', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (486, 200004609, 'SMG_KRISSSUPERV_PBWC2018', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (465, 200004298, 'Kriss S.V Alien', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (430, 200004172, 'Kriss S.V ANC 2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (452, 200004258, 'Kriss S.V Beast', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (422, 200004139, 'Kriss S.V Brazuca', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (316, 1104003294, 'MASK BOLT', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (423, 200004142, 'Kriss S.V Champion', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (429, 200004170, 'Kriss S.V Couple Breaker', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (469, 200004318, 'Kriss S.V Dark Steel', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (160, 100003285, 'Groza Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (441, 200004212, 'Kriss S.V DarkDays', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (462, 200004286, 'Kriss S.V Demonic', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (448, 200004245, 'Kriss S.V DFN', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (463, 200004289, 'Kriss S.V Dolphin', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (457, 200004270, 'Kriss S.V E-Sport2', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (426, 200004155, 'Kriss S.V G E-Sport', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (473, 200004330, 'Kriss S.V Gorgeous', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (431, 200004175, 'Kriss S.V GRS2', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (451, 200004255, 'Kriss S.V GRS3', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (420, 200004130, 'Kriss S.V GSL2014', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (454, 200004263, 'Kriss S.V GSL2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (446, 200004237, 'Kriss S.V Halloween', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (436, 200004196, 'Kriss S.V Harimau', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (419, 200004126, 'Kriss S.V Inferno', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (440, 200004209, 'Kriss S.V Mech', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (421, 200004132, 'Kriss S.V Midnight', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (455, 200004265, 'Kriss S.V Midnigth2', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (450, 200004253, 'Kriss S.V Monkey', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (459, 200004278, 'Kriss S.V Mummy', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (432, 200004178, 'Kriss S.V Newborn 2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (447, 200004242, 'Kriss S.V Obsidian', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (433, 200004185, 'Kriss S.V Ongame', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (453, 200004260, 'Kriss S.V PBGC', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (442, 200004216, 'Kriss S.V PBIC2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (467, 200004312, 'Kriss S.V PBIC2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (438, 200004205, 'Kriss S.V PBNC2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (470, 200004321, 'Kriss S.V PBNC2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (471, 200004323, 'Kriss S.V PBST2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (439, 200004207, 'Kriss S.V PBTC2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (468, 200004316, 'Kriss S.V PBTC2016', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (425, 200004151, 'Kriss S.V PC Cafe', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (466, 200004304, 'Kriss S.V Puzzle', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (418, 200004123, 'Kriss S.V R', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (437, 200004201, 'Kriss S.V Red', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (434, 200004188, 'Kriss S.V Redemption', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (443, 200004221, 'Kriss S.V Sheep', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (456, 200004267, 'Kriss S.V Skeleton', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (445, 200004235, 'Kriss S.V Steam', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (461, 200004283, 'Kriss S.V Strike', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (435, 200004191, 'Kriss S.V Summer', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (472, 200004325, 'Kriss S.V SUPREME', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (427, 200004157, 'Kriss S.V Toy', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (424, 200004144, 'Kriss S.V W.O.E', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (449, 200004249, 'Kriss S.V XMAS2015', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (481, 200004519, 'KRISSSUPERV FIREDRAGON', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (484, 200004600, 'KRISSSUPERV M1LGR4U', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (485, 200004601, 'KRISSSUPERV M1LGR4U DUMMY', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (478, 200004471, 'KRISSSUPERV_7TH_ANNIVERSARY', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (487, 200004639, 'KRISSSUPERV_ARCADE', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (475, 200004396, 'KRISSSUPERV_COMIC', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (482, 200004574, 'KRISSSUPERV_GRSV', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (476, 200004416, 'KRISSSUPERV_LEBARAN2017', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (479, 200004483, 'KRISSSUPERV_MILITARY', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (480, 200004489, 'KRISSSUPERV_PBIC2017', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (474, 200004385, 'KRISSSUPERV_SAMURAI', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (379, 1103003014, 'Boina Skull', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (399, 1103003011, 'PB Black Beret', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (377, 1103003012, 'Boina da Turkia', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (382, 1103003018, 'Boina Vera Cruz 2016', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (381, 1103003017, 'Boina Brasil', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (528, 100003353, 'SC-2010 CNPB T5', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (529, 100003460, 'SC-2010 WHITERABBIT', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (530, 100003395, 'SC 2010 HALLOWEEN2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (531, 100003452, 'SC 2010 M1LGR4U', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (532, 100003356, 'SC_2010_LEBARAN2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (533, 100003372, 'SC_2010_PBNC2017', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (535, 100003383, 'SC_2010_AGUILA', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (536, 100003429, 'SC_2010_NEVASCA', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (537, 100003438, 'ASSAULT_SC_2010_GRSV', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (538, 100003455, 'ASSAULT_SC_2010_PBWC2018', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (540, 100003169, 'TAR-21 Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (541, 100003182, 'TAR-21 Sheep', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (542, 100003340, 'Msbs Gold', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (545, 100003143, 'FG 42', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (546, 100003115, 'AN-94', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (547, 100003057, 'Vz. 52', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (490, 200004134, 'OA-93', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (491, 200004136, 'OA-93 Gold', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (492, 200004159, 'OA-93 D.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (493, 200004165, 'OA-93 Especial de Natal', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (494, 200004180, 'OA-93 GSL2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (495, 200004198, 'OA-93 Independência', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (496, 200004203, 'OA-93 PBST2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (497, 200004214, 'OA-93 PBNC2015 U.S.', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (498, 200004225, 'OA-93 Basketball', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (499, 200004228, 'OA-93 Medical', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (500, 200004232, 'OA-93 Cobra', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (501, 200004247, 'OA-93 DFN', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (502, 200004251, 'OA-93 XMAS2015', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (504, 200004292, 'OA-93 Blue Diamond', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (505, 200004300, 'OA-93 Woody', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (506, 200004302, 'OA-93 Newborn2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (507, 200004309, 'OA-93 Liberty', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (508, 200004314, 'OA-93 PBIC2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (509, 200004328, 'OA-93 Halloween 2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (510, 200004332, 'OA-93 Gorgeous', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (511, 200004628, 'OA-93 PALADIN', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (562, 300005268, 'Barret Black', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (549, 803007040, 'M18A1 Claymore', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (564, 1001001275, 'Bella WW2', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (565, 1001002278, 'Chou WW2', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (566, 1001002311, 'Chou Invasion', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (567, 1001001320, 'Bella Invasion', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (568, 601014028, 'SCORPION_VZ61_ARCADE', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (571, 1103003022, 'Baret RussianDelux', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (577, 100003480, 'ASSAULT_AUG_HBAR_RENEGADE2', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (579, 601014024, 'DUALHANDGUN_SCORPION_VZ61_7TH_ANNIVERSARY', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (559, 1001002014, 'Hide 120', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (557, 1104003194, 'Máscara Viper Egg', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (556, 1001001356, 'REBEL_Viper_Vacance17', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (555, 1001001286, 'General Viper', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (554, 1001001013, 'ViperRed 120', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (550, 1102003007, 'Capacete Avançado Plus', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (560, 1001002064, 'Hide Infectada', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (561, 1001002353, 'Hide_Vacance17', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (569, 1103003021, 'Baret RussiaNormal', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (570, 1103003020, 'Baret Strik', 't', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (574, 1103003010, 'PBTN Beret', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (417, 200004121, 'Kriss S.V TH 1st Anniversary', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (575, 200004626, 'KRISS SV PALADIN', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (572, 1103003034, 'BeretM1LGR4U', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (576, 1103003030, 'BeretMilitary', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (573, 1103003027, 'BeretPBNC2017', 'f', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (894, 601002104, 'LUGER_P08_Gold', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (895, 601002103, 'LUGER_P08_Silver', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (896, 100003366, 'SC_2010_BOLT', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (897, 200004437, 'KRISSSUPERV_BOLT', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (898, 200004439, 'OA93_BOLT', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (899, 400006110, 'M1887_KAREEM', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (654, 904007059, 'Pink Smoke', 'f', 'f', 'f', 'f');
INSERT INTO "public"."regras" VALUES (553, 1001001010, 'Viper Red (+30% Gold)', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (558, 1001002009, 'Hide (+30% Gold)', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (551, 100003431, 'AUG HBAR PANDORA', 't', 't', 't', 'f');
INSERT INTO "public"."regras" VALUES (503, 200004273, 'OA-93 PBWC2016', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (900, 200004036, 'M4_CQBR_LV3', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (128, 702015012, 'Kunai Serpent', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (901, 1103003001, 'Assault Beret', 'f', 't', 'f', 't');
INSERT INTO "public"."regras" VALUES (902, 1103003002, 'Sniper Beret', 'f', 't', 'f', 't');
INSERT INTO "public"."regras" VALUES (903, 1103003003, 'Shoting Beret', 'f', 't', 'f', 't');
INSERT INTO "public"."regras" VALUES (904, 1103003004, 'SMG Beret', 'f', 't', 'f', 't');
INSERT INTO "public"."regras" VALUES (905, 1103003005, 'Shotgun Beret', 'f', 't', 'f', 't');
INSERT INTO "public"."regras" VALUES (906, 100003319, 'PINDAD_SS2_V5_LIGHTNING', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (578, 300005247, 'PGM_HECATE2_7TH_ANNIVERSARY', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (907, 300005145, 'PGM Hecate2', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (908, 300005146, 'PGM-Hecate2 G.', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (909, 100003440, 'ASSAULT_SC_2010_NUSANTARA', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (910, 200004578, 'SMG_KRISSSUPERV_NUSANTARA', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (911, 200004580, 'SMG_OA93_NUSANTARA', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (912, 400006141, 'SHOTGUN_M1887_NUSANTARA', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (913, 601002144, 'HANDGUN_TAURUS_454SS_SCOPE_NUSANTARA', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (914, 200004524, 'OA93_LATIN7', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (915, 400006121, 'ZOMBIE_SLAYER_LATIN7', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (916, 601014025, ' DUALHANDGUN_SCORPION_VZ61_LATIN7', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (917, 601034003, 'COMPOUND BOW GOLD', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (918, 601034004, 'COMPOUND BOW BLUE', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (883, 1001002305, 'P1000 Keen Eyes', 't', 't', 'f', 'f');
INSERT INTO "public"."regras" VALUES (884, 100003159, 'AUG A3 PBIC2014', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (920, 100003063, 'AUG A3 E-Sports', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (921, 601002081, 'Taurus 454SS Scope VeraCruz2016', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (922, 601002126, 'TAURUS_454SS_SCOPE_PBNC2017', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (923, 601002070, 'TAURUS_454SS_SCOPE_PBIC2015', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (924, 601002013, 'TAURUS_454SS_2M', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (926, 601002015, 'TAURUS_454SS_8M', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (159, 100003284, 'Groza', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (161, 100003286, 'Groza Silver', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (162, 100003288, 'Groza Russian Normal', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (275, 1104003146, 'WC 2014 Equador Mask', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (178, 400006041, 'M1887 Lion-Heart', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (196, 400006070, 'M1887 Dragon', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (121, 702001114, 'Ballistic Knife Spy-Deluxe', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (678, 300005184, 'AS-50 PBTC2016', 't', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (927, 300005159, 'AS 50 G.', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (928, 300005157, 'AS 50', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (929, 300005164, 'AS 50 D.', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (930, 200004366, 'KRISSSUPERV_CURSED_VALENTINE', 'f', 'f', 't', 'f');
INSERT INTO "public"."regras" VALUES (931, 200004368, 'OA93_CURSED_VALENTINE', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (932, 400006093, 'M1887_CURSED_VALENTINE', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (933, 200004345, 'KRISSSUPERV_CHICKEN', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (935, 200004354, 'MX4 Gold', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (934, 1105003018, 'Chicken', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (936, 200004352, 'MX4', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (251, 1104003096, 'Smile Cartoon Mask Set (Troll Meme)', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (552, 100003408, 'AUG HBAR Gold', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (925, 601002014, 'TAURUS_454SS_5M', 'f', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (937, 1104003107, 'Máscara PBIC2012', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (938, 1104003182, 'Mask 2014 PBIC', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (939, 400006043, 'Remington ETA', 't', 'f', 't', 't');
INSERT INTO "public"."regras" VALUES (940, 803007026, 'Decoy Bomb', 't', 't', 't', 't');
INSERT INTO "public"."regras" VALUES (941, 100003120, 'AUG A3 PBIC2013', 't', 'f', 't', 't');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS "public"."shop";
CREATE TABLE "public"."shop" (
  "good_id" int4 NOT NULL DEFAULT nextval('shop_good_id_seq'::regclass),
  "item_id" int4 NOT NULL,
  "item_name" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "price_gold" int4 DEFAULT 0,
  "price_cash" int4 DEFAULT 0,
  "count" int4 DEFAULT 0,
  "buy_type" int2 DEFAULT 2,
  "buy_type2" int2 DEFAULT 0,
  "buy_type3" int2 DEFAULT 0,
  "tag" int2 DEFAULT 0,
  "title" int2 DEFAULT 0,
  "visibility" int2 DEFAULT 0
)
;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO "public"."shop" VALUES (1003, 601002021, '[FOR SET VISIBLE]Glock 18 D[Aug A3 Black Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1004, 1104003101, '[FOR SET VISIBLE]Mask Frail Skull Gold[p90 G Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1005, 200004075, '[FOR SET VISIBLE]p90 G [p90 G Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1006, 1001002052, '[FOR SET VISIBLE]Skull Package - Leopard Bope', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1007, 200004114, '[FOR SET VISIBLE]Skull Package - P90 BR Camo', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1009, 300005065, '[FOR SET VISIBLE]Skull Package - L115A1 BR Camo', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1011, 601002012, '[FOR SET VISIBLE]Kit Pro Player - C. Python D', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1012, 1103003006, '[FOR SET VISIBLE]Kit Pro Player - Boina Negra', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1013, 601002049, '[FOR SET VISIBLE]Kit Pro A - C. Python Brazuca', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1014, 1102003003, '[FOR SET VISIBLE]Kit Pro A - Capacete avançado', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1015, 1001001295, '[FOR SET VISIBLE]Viper Red Special Force[Special Force Combo Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1016, 1001002294, '[FOR SET VISIBLE]Hide Special Force[Special Force Combo Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1017, 300005199, '[FOR SET VISIBLE]CheyTec M200 Beyond[Beyond Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1018, 1001002067, '[FOR SET VISIBLE]Hide Strike[Beyond Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1019, 1104003273, '[FOR SET VISIBLE]Mask New Generation[Beyond Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1020, 1001001286, '[FOR SET VISIBLE]General Viper[General Combo Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1021, 1001002287, '[FOR SET VISIBLE]General Hide[General Combo Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1022, 1001001283, '[FOR SET VISIBLE]Pirate Tarantula [Pirate Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1023, 100003323, '[FOR SET VISIBLE]Aug A3 Pirate[Pirate Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1024, 1104003012, '[FOR SET VISIBLE]Golden Smile Mask[Golden Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1025, 601002114, '[FOR SET VISIBLE]Tec-9G[Golden Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1026, 702001043, '[FOR SET VISIBLE]Combat Machet G[Golden Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1027, 100003249, '[FOR SET VISIBLE]Aug A3 S.[Golden Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1028, 1001001295, '[FOR SET VISIBLE]Hitman Viper Red[Hot Star Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1029, 100003040, '[FOR SET VISIBLE]Aug A3 D[Hot Star Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1030, 601002068, '[FOR SET VISIBLE]HG_r.b454_ss28M_Mech[Hot Star Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1031, 1001002067, '[FOR SET VISIBLE]HideStrike[Hot Star Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1032, 1104003270, '[FOR SET VISIBLE]Mask Black Skull[Golden Warrior Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1033, 100003340, '[FOR SET VISIBLE]Msbs Gold[Golden Warrior Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1034, 601002017, '[FOR SET VISIBLE]Python Gold[Golden Warrior Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1035, 601002098, '[FOR SET VISIBLE]Python DarkSteel[DarkSteel Assault Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1036, 100003295, '[FOR SET VISIBLE]Aug A3 DarkSteel[DarkSteel Assault Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1037, 1102003006, '[FOR SET VISIBLE]Target Tracking HeadGearSet[DarkSteel Assault Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1038, 702001159, '[FOR SET VISIBLE]FangBlade Steel[DarkSteel Assault Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1040, 1001002053, '[FOR SET VISIBLE]WC 2014 Hide[Word Cup 2014 Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1041, 601002049, '[FOR SET VISIBLE]Python Brazuca[Word Cup 2014 Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1042, 1001001054, '[FOR SET VISIBLE]WC 2014 Tarantula[Word Cup 2014 Set] [R]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1043, 100003037, '[FOR SET VISIBLE]Aug A3 Gold[GM Selection Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1044, 1104003251, '[FOR SET VISIBLE]Phantom Mask[GM Selection Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1045, 702001051, '[FOR SET VISIBLE]FangBlade GSL 2014[GM Selection Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1046, 803007026, '[FOR SET VISIBLE]Decoy Bomb[GM Selection Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1047, 601002104, '[FOR SET VISIBLE]Luger p08 Gold[GM Selection Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1048, 200004436, '[FOR SET VISIBLE]APC9 G. [Penetrator Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1049, 1104003294, '[FOR SET VISIBLE]MASK BOLT [Penetrator Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000101, 100003011, 'K-201 Ext.', 600, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000102, 100003011, 'K-201 Ext.', 2400, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000202, 100003013, 'G36C Ext.', 36000, 0, 500, 1, 1, 2, 0, 10, 0);
INSERT INTO "public"."shop" VALUES (10000301, 100003236, 'K2C', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000302, 100003236, 'K2C', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000501, 100003046, 'F2000 Silver', 400, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000502, 100003046, 'F2000 Silver', 1600, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000601, 100003015, 'AK SOPMOD Ext.', 16000, 0, 100, 1, 1, 2, 0, 12, 0);
INSERT INTO "public"."shop" VALUES (10000602, 100003015, 'AK SOPMOD Ext.', 64000, 0, 500, 1, 1, 2, 0, 12, 0);
INSERT INTO "public"."shop" VALUES (10000701, 100003174, 'XM8', 22000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000702, 100003174, 'XM8', 88000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10000801, 100003049, 'FAMAS G2', 10000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000802, 100003049, 'FAMAS G2', 40000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000901, 100003017, 'AK-47 Silver', 1200, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000902, 100003017, 'AK-47 Silver', 4800, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001001, 100003019, 'SG-550 Silver', 1000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001002, 100003019, 'SG-550 Silver', 4000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001102, 100003246, 'AK-12', 12000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001201, 100003053, 'SS2-V4 Para Sniper', 3000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001202, 100003053, 'SS2-V4 Para Sniper', 12000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001301, 100003054, 'AK-47 Gold D', 1500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001302, 100003054, 'AK-47 Gold D', 6000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001401, 100003102, 'HK-417', 2400, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001402, 100003102, 'HK-417', 9600, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001501, 100003057, 'Vz. 52', 14000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001502, 100003057, 'Vz. 52', 56000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001701, 100003061, 'SS2-V4 Para Sniper Gold', 2500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001702, 100003061, 'SS2-V4 Para Sniper Gold', 10000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001801, 100003153, 'SC-2010', 25000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001802, 100003153, 'SC-2010', 100000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002101, 100003029, 'G36C Silver', 11500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002102, 100003029, 'G36C Silver', 46000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002201, 100003036, 'AUG A3', 20000, 0, 100, 1, 1, 2, 6, 12, 3);
INSERT INTO "public"."shop" VALUES (10002202, 100003036, 'AUG A3', 80000, 0, 500, 1, 1, 2, 6, 12, 3);
INSERT INTO "public"."shop" VALUES (10002301, 100003115, 'AN-94', 8000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002302, 100003115, 'AN-94', 32000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002401, 100003116, 'F2000 Reload', 500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001901, 100003021, 'M4A1 Silver', 3600, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001902, 100003021, 'M4A1 Silver', 14400, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002001, 100003023, 'M4A1 Gold', 4000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002002, 100003023, 'M4A1 Gold', 16000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002402, 100003116, 'F2000 Reload', 2000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002501, 100003223, 'M14-EBR', 5600, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002502, 100003223, 'M14-EBR', 22400, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002601, 100003117, 'SG550 Reload', 600, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002602, 100003117, 'SG550 Reload', 2400, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002701, 100003004, 'K-2 Ext.', 600, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002702, 100003004, 'K-2 Ext.', 2400, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002801, 100003069, 'SCAR-H CQC', 14600, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10002802, 100003069, 'SCAR-H CQC', 58400, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003001, 100003086, 'AK-47 Goddess', 1000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003002, 100003086, 'AK-47 Goddess', 4000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003101, 100003087, 'Famas G2 Silver', 12000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003102, 100003087, 'Famas G2 Silver', 48000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003201, 100003123, 'TAR-21', 16000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003202, 100003123, 'TAR-21', 64000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003301, 100003002, 'AK-47 Ext.', 1000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003302, 100003002, 'AK-47 Ext.', 4000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003401, 100003268, 'Pindad SS2 V5', 23600, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003402, 100003268, 'Pindad SS2 V5', 94400, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003501, 100003001, 'SG-550 Ext.', 600, 0, 100, 1, 1, 2, 0, 8, 0);
INSERT INTO "public"."shop" VALUES (10003502, 100003001, 'SG-550 Ext.', 2400, 0, 500, 1, 1, 2, 0, 8, 0);
INSERT INTO "public"."shop" VALUES (10003601, 100003118, 'Pindad SS2-V4 Para Sniper Reload', 1000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003602, 100003118, 'Pindad SS2-V4 Para Sniper Reload', 6000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003603, 100003118, 'Pindad SS2-V4 Para Sniper Reload', 10000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10003701, 100003119, 'AK-47 Elite', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003702, 100003119, 'AK-47 Elite', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003703, 100003119, 'AK-47 Elite', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004101, 100003125, 'AK-47 F.C', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004102, 100003125, 'AK-47 F.C', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004103, 100003125, 'AK-47 F.C', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004201, 100003126, 'AK SOPMOD CG', 4200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10004202, 100003126, 'AK SOPMOD CG', 25200, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10004203, 100003126, 'AK SOPMOD CG', 42000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10004301, 100003128, 'AUG A3 Azerbaijan', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004303, 100003128, 'AUG A3 Azerbaijan', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004501, 100003130, 'AUG A3 G Bloody', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004502, 100003130, 'AUG A3 G Bloody', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004503, 100003130, 'AUG A3 G Bloody', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004601, 100003131, 'AUG A3 LATIN3', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004602, 100003131, 'AUG A3 LATIN3', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004603, 100003131, 'AUG A3 LATIN3', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004701, 100003142, 'AUG A3 TH 1st Anniversary', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004702, 100003142, 'AUG A3 TH 1st Anniversary', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004703, 100003142, 'AUG A3 TH 1st Anniversary', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004801, 100003143, 'FG 42', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004802, 100003143, 'FG 42', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004803, 100003143, 'FG 42', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004901, 100003144, 'AUG A3 R', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004902, 100003144, 'AUG A3 R', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004903, 100003144, 'AUG A3 R', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005001, 100003146, 'G36C Elite', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005002, 100003146, 'G36C Elite', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005003, 100003146, 'G36C Elite', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003802, 100003120, 'AUG A3 PBIC2013', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003803, 100003120, 'AUG A3 PBIC2013', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003901, 100003121, 'M4A1 PBIC2013', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003902, 100003121, 'M4A1 PBIC2013', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003903, 100003121, 'M4A1 PBIC2013', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004001, 100003122, 'AK47 PBIC2013', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004002, 100003122, 'AK47 PBIC2013', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004003, 100003122, 'AK47 PBIC2013', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001601, 100003284, 'Groza', 26000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10001602, 100003284, 'Groza', 104000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005101, 100003147, 'AUG A3 Inferno', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005102, 100003147, 'AUG A3 Inferno', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005103, 100003147, 'AUG A3 Inferno', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005201, 100003148, 'AUG A3 PBNC5', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005202, 100003148, 'AUG A3 PBNC5', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005203, 100003148, 'AUG A3 PBNC5', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005301, 100003149, 'AUG A3 GSL2014', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005302, 100003149, 'AUG A3 GSL2014', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005303, 100003149, 'AUG A3 GSL2014', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005401, 100003152, 'AK SOPMOD BR Camo', 0, 420, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005402, 100003152, 'AK SOPMOD BR Camo', 0, 2520, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005403, 100003152, 'AK SOPMOD BR Camo', 0, 4200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005501, 100003154, 'SC-2010 Gold', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005502, 100003154, 'SC-2010 Gold', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005503, 100003154, 'SC-2010 Gold', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005701, 100003157, 'AUG A3 Champion', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005702, 100003157, 'AUG A3 Champion', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005703, 100003157, 'AUG A3 Champion', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005901, 100003159, 'AUG A3 PBIC2014', 0, 450, 86400, 2, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (10005902, 100003159, 'AUG A3 PBIC2014', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006001, 100003160, 'AUG A3 BR 4th Anniversary', 0, 400, 86400, 2, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (10006002, 100003160, 'AUG A3 BR 4th Anniversary', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006003, 100003160, 'AUG A3 BR 4th Anniversary', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006101, 100003151, 'TAR-21 BR Camo', 0, 390, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006102, 100003151, 'TAR-21 BR Camo', 0, 2340, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006103, 100003151, 'TAR-21 BR Camo', 0, 3900, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006301, 100003164, 'AUG A3 G E-Sport', 0, 4500, 2592000, 2, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (10006302, 100003164, 'AUG A3 G E-Sport', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006303, 100003164, 'AUG A3 G E-Sport', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006401, 100003165, 'AUG A3 Toy', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006402, 100003165, 'AUG A3 Toy', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006403, 100003165, 'AUG A3 Toy', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006501, 100003167, 'AN-94 Gold', 38000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006502, 100003167, 'AN-94 Gold', 3800, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006503, 100003167, 'AN-94 Gold', 22800, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006601, 100003168, 'HK-417 Gold', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006602, 100003168, 'HK-417 Gold', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006603, 100003168, 'HK-417 Gold', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004402, 100003129, 'AUG A3 Bloody', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006701, 100003169, 'TAR-21 Gold', 41000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006702, 100003169, 'TAR-21 Gold', 4100, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002902, 100003005, 'F2000 Ext.', 2400, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006703, 100003169, 'TAR-21 Gold', 24600, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10006801, 100003170, 'SCAR-L Carbine Gold', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006802, 100003170, 'SCAR-L Carbine Gold', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006803, 100003170, 'SCAR-L Carbine Gold', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006901, 100003171, 'AUG A3 LATIN4', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006902, 100003171, 'AUG A3 LATIN4', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006903, 100003171, 'AUG A3 LATIN4', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007101, 100003175, 'SCAR-L Carbine D.', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007102, 100003175, 'SCAR-L Carbine D.', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007103, 100003175, 'SCAR-L Carbine D.', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007201, 100003176, 'SCAR-L Recon D.', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007202, 100003176, 'SCAR-L Recon D.', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007203, 100003176, 'SCAR-L Recon D.', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007301, 100003177, 'XM8 GOLD', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007302, 100003177, 'XM8 GOLD', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007303, 100003177, 'XM8 GOLD', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007401, 100003178, 'AUG A3 CoupleBreaker', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007402, 100003178, 'AUG A3 CoupleBreaker', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007403, 100003178, 'AUG A3 CoupleBreaker', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007501, 100003180, 'AUG A3 ANC 2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007502, 100003180, 'AUG A3 ANC 2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007503, 100003180, 'AUG A3 ANC 2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007601, 100003181, 'AUG A3 Sheep', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007602, 100003181, 'AUG A3 Sheep', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007603, 100003181, 'AUG A3 Sheep', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007701, 100003182, 'TAR-21 Sheep', 0, 3900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007702, 100003182, 'TAR-21 Sheep', 0, 390, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007801, 100003183, 'AUG A3 GRS2', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007802, 100003183, 'AUG A3 GRS2', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007803, 100003183, 'AUG A3 GRS2', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007901, 100003184, 'AUG A3 Newborn 2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007902, 100003184, 'AUG A3 Newborn 2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10007903, 100003184, 'AUG A3 Newborn 2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008001, 100003185, 'SC-2010 Newborn 2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008002, 100003185, 'SC-2010 Newborn 2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008003, 100003185, 'SC-2010 Newborn 2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006201, 100003163, 'AUG A3 PC Cafe', 4000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10006202, 100003163, 'AUG A3 PC Cafe', 16000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008101, 100003186, 'AUG A3 GSL2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005803, 100003158, 'AUG A3 W.O.E', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005802, 100003158, 'AUG A3 W.O.E', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005801, 100003158, 'AUG A3 W.O.E', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008102, 100003186, 'AUG A3 GSL2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008103, 100003186, 'AUG A3 GSL2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008201, 100003188, 'AUG A3 Ongame', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005602, 100003155, 'AUG A3 Brazuca', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10007002, 100003173, 'AUG A3 Cangaceiro', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10008202, 100003188, 'AUG A3 Ongame', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008203, 100003188, 'AUG A3 Ongame', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008301, 100003189, 'AUG A3 Redemption', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008302, 100003189, 'AUG A3 Redemption', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008303, 100003189, 'AUG A3 Redemption', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008801, 100003194, 'AUG A3 Independência', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008802, 100003194, 'AUG A3 Independência', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008803, 100003194, 'AUG A3 Independência', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008901, 100003195, 'AUG A3 Brazil', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008902, 100003195, 'AUG A3 Brazil', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009001, 100003196, 'AUG A3 PBST2015', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009002, 100003196, 'AUG A3 PBST2015', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009003, 100003196, 'AUG A3 PBST2015', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009101, 100003197, 'AUG A3 4Game', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009102, 100003197, 'AUG A3 4Game', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009103, 100003197, 'AUG A3 4Game', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009201, 100003198, 'AUG A3 4Game SE', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009202, 100003198, 'AUG A3 4Game SE', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009203, 100003198, 'AUG A3 4Game SE', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010102, 100003207, 'AUG A3 Lebaran2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010103, 100003207, 'AUG A3 Lebaran2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010103, 100003207, 'AUG A3 Lebaran2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010201, 100003209, 'Vz.52 BlackPearl', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010202, 100003209, 'Vz.52 BlackPearl', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010203, 100003209, 'Vz.52 BlackPearl', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010601, 100003213, 'AUG A3 UAE', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010602, 100003213, 'AUG A3 UAE', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010603, 100003213, 'AUG A3 UAE', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010701, 100003214, 'AUG A3 PBNC2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010702, 100003214, 'AUG A3 PBNC2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010703, 100003214, 'AUG A3 PBNC2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010801, 100003215, 'AUG A3 PBTC2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010802, 100003215, 'AUG A3 PBTC2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010803, 100003215, 'AUG A3 PBTC2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010901, 100003216, 'AUG A3 Mech', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010902, 100003216, 'AUG A3 Mech', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010903, 100003216, 'AUG A3 Mech', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011001, 100003217, 'AUG A3 DarkDays', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011002, 100003217, 'AUG A3 DarkDays', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011003, 100003217, 'AUG A3 DarkDays', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009302, 100003199, 'AUG A3 México', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009401, 100003200, 'AUG A3 Bolivia', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009402, 100003200, 'AUG A3 Bolivia', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010301, 100003210, 'AUG A3 Egypt', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010302, 100003210, 'AUG A3 Egypt', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010401, 100003211, 'AUG A3 Jordan', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010402, 100003211, 'AUG A3 Jordan', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010501, 100003212, 'AUG A3 Saudi', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010502, 100003212, 'AUG A3 Saudi', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10009501, 100003201, 'AUG A3 Equador', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009601, 100003202, 'AUG A3 Colombia', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009801, 100003204, 'AUG A3 Argentina', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009802, 100003204, 'AUG A3 Argentina', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009901, 100003205, 'AUG A3 Chile', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009902, 100003205, 'AUG A3 Chile', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009301, 100003199, 'AUG A3 México', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011101, 100003218, 'SCAR-L  F.C PBNC2015US', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011102, 100003218, 'SCAR-L  F.C PBNC2015US', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011103, 100003218, 'SCAR-L  F.C PBNC2015US', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008702, 100003193, 'AUG A3 LionFlame', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008703, 100003193, 'AUG A3 LionFlame', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008501, 100003191, 'SC-2010 Rose', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008602, 100003192, 'AUG-A3 Rose', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008502, 100003191, 'SC-2010 Rose', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008603, 100003192, 'AUG-A3 Rose', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008503, 100003191, 'SC-2010 Rose', 0, 1000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011201, 100003219, 'AUG A3 PBIC2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011202, 100003219, 'AUG A3 PBIC2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011203, 100003219, 'AUG A3 PBIC2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011301, 100003221, 'AK-47 SOPMOD Gold', 42000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10011302, 100003221, 'AK-47 SOPMOD Gold', 4200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10011303, 100003221, 'AK-47 SOPMOD Gold', 25200, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010303, 100003210, 'AUG A3 Egypt', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010101, 100003206, 'AUG A3 Peru', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10009503, 100003201, 'AUG A3 Equador', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10008903, 100003195, 'AUG A3 Brazil', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010403, 100003211, 'AUG A3 Jordan', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010503, 100003212, 'AUG A3 Saudi', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10009602, 100003202, 'AUG A3 Colombia', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011501, 100003224, 'AUG A3 Basketball', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011502, 100003224, 'AUG A3 Basketball', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011503, 100003224, 'AUG A3 Basketball', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011601, 100003225, 'AK-47 SOPMOD Medical', 0, 4200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011602, 100003225, 'AK-47 SOPMOD Medical', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011603, 100003225, 'AK-47 SOPMOD Medical', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011701, 100003226, 'SC-2010 Medical', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011702, 100003226, 'SC-2010 Medical', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011703, 100003226, 'SC-2010 Medical', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011901, 100003228, 'AUG A3 Camo Soldier', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011902, 100003228, 'AUG A3 Camo Soldier', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10011903, 100003228, 'AUG A3 Camo Soldier', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012001, 100003229, 'G36C Ext. Camo Soldier', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012002, 100003229, 'G36C Ext. Camo Soldier', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012003, 100003229, 'G36C Ext. Camo Soldier', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012101, 100003231, 'AUG A3 Steam', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012102, 100003231, 'AUG A3 Steam', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012103, 100003231, 'AUG A3 Steam', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012201, 100003232, 'AUG A3 Halloween', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012202, 100003232, 'AUG A3 Halloween', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012203, 100003232, 'AUG A3 Halloween', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012301, 100003234, 'AUG A3 Latin5', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012302, 100003234, 'AUG A3 Latin5', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012303, 100003234, 'AUG A3 Latin5', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012401, 100003235, 'AUG A3 Obsidian', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012402, 100003235, 'AUG A3 Obsidian', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012403, 100003235, 'AUG A3 Obsidian', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012501, 100003238, 'AUG A3 Spy-Deluxe', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012502, 100003238, 'AUG A3 Spy-Deluxe', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012503, 100003238, 'AUG A3 Spy-Deluxe', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012601, 100003240, 'AUG A3 DFN', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012602, 100003240, 'AUG A3 DFN', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012603, 100003240, 'AUG A3 DFN', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012701, 100003241, 'AUG A3 XMAS2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012702, 100003241, 'AUG A3 XMAS2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012703, 100003241, 'AUG A3 XMAS2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012801, 100003242, 'SC-2010 XMAS2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012802, 100003242, 'SC-2010 XMAS2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012803, 100003242, 'SC-2010 XMAS2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013101, 100003245, 'AUG A3 Arena Deluxe', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013102, 100003245, 'AUG A3 Arena Deluxe', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013103, 100003245, 'AUG A3 Arena Deluxe', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013201, 100003247, 'AK-12 Gold', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013202, 100003247, 'AK-12 Gold', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013203, 100003247, 'AK-12 Gold', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013402, 100003249, 'AUG A3 Silence', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013403, 100003249, 'AUG A3 Silence', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013502, 100003250, 'AUG A3 Cupido', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013601, 100003251, 'AUG A3 Sakura', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013602, 100003251, 'AUG A3 Sakura', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013701, 100003252, 'AK SOPMOD Sakura', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013702, 100003252, 'AK SOPMOD Sakura', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013801, 100003253, 'AUG A3 Serpent', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013802, 100003253, 'AUG A3 Serpent', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10010001, 100003206, 'AUG A3 Peru', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10010002, 100003206, 'AUG A3 Peru', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10009903, 100003205, 'AUG A3 Chile', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013803, 100003253, 'AUG A3 Serpent', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014001, 100003255, 'AUG A3 GRS3', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014002, 100003255, 'AUG A3 GRS3', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014003, 100003255, 'AUG A3 GRS3', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014101, 100003256, 'AUG A3 Beast', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014102, 100003256, 'AUG A3 Beast', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014103, 100003256, 'AUG A3 Beast', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014301, 100003258, 'AUG A3 GSL2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014302, 100003258, 'AUG A3 GSL2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013002, 100003244, 'AUG A3 Arena Normal', 15000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10014303, 100003258, 'AUG A3 GSL2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014202, 100003257, 'AUG A3 PBGC', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10011802, 100003227, 'AUG A3 Cobra', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011801, 100003227, 'AUG A3 Cobra', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011803, 100003227, 'AUG A3 Cobra', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011402, 100003222, 'AUG A3 VeraCruz', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10011403, 100003222, 'AUG A3 VeraCruz', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10013302, 100003248, 'AUG A3 VeraCruz 2016', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10013303, 100003248, 'AUG A3 VeraCruz 2016', 0, 2400, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10014501, 100003260, 'AUG A3 Tiger-Deluxe', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013401, 100003249, 'AUG A3 Silence', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10009703, 100003203, 'AUG A3 Venezuela', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10014502, 100003260, 'AUG A3 Tiger-Deluxe', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014503, 100003260, 'AUG A3 Tiger-Deluxe', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014601, 100003261, 'AUG A3 Midnight2', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014602, 100003261, 'AUG A3 Midnight2', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014603, 100003261, 'AUG A3 Midnight2', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014701, 100003262, 'AUG A3 Skeleton', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014702, 100003262, 'AUG A3 Skeleton', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014703, 100003262, 'AUG A3 Skeleton', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015001, 100003265, 'AUG A3 Dragon', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015002, 100003265, 'AUG A3 Dragon', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015003, 100003265, 'AUG A3 Dragon', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015101, 100003266, 'AUG A3 PBWC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015102, 100003266, 'AUG A3 PBWC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015103, 100003266, 'AUG A3 PBWC2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015201, 100003267, 'AUG A3 Mummy', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015202, 100003267, 'AUG A3 Mummy', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015203, 100003267, 'AUG A3 Mummy', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015301, 100003269, 'Pindad SS2 V5 Gold', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015302, 100003269, 'Pindad SS2 V5 Gold', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015303, 100003269, 'Pindad SS2 V5 Gold', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015401, 100003270, 'Pindad SS2 V5 Silver', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015402, 100003270, 'Pindad SS2 V5 Silver', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015403, 100003270, 'Pindad SS2 V5 Silver', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10015501, 100003271, 'AUG A3 ID 1stAnni', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015502, 100003271, 'AUG A3 ID 1stAnni', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015503, 100003271, 'AUG A3 ID 1stAnni', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015601, 100003272, 'AUG A3 Strike', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015602, 100003272, 'AUG A3 Strike', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015603, 100003272, 'AUG A3 Strike', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015701, 100003273, 'SC-2010 Strike', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015702, 100003273, 'SC-2010 Strike', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015703, 100003273, 'SC-2010 Strike', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015801, 100003274, 'AUG A3 Demonic', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015802, 100003274, 'AUG A3 Demonic', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015803, 100003274, 'AUG A3 Demonic', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015901, 100003275, 'AUG A3 Dolphin', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015902, 100003275, 'AUG A3 Dolphin', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10015903, 100003275, 'AUG A3 Dolphin', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016001, 100003276, 'SC-2010 Dolphin', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016002, 100003276, 'SC-2010 Dolphin', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016003, 100003276, 'SC-2010 Dolphin', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016101, 100003277, 'AUG A3 Blue Diamond', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016102, 100003277, 'AUG A3 Blue Diamond', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016103, 100003277, 'AUG A3 Blue Diamond', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016201, 100003278, 'AUG A3 Lebaran2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016202, 100003278, 'AUG A3 Lebaran2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016203, 100003278, 'AUG A3 Lebaran2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016401, 100003280, 'AUG A3 Woody', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016402, 100003280, 'AUG A3 Woody', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016403, 100003280, 'AUG A3 Woody', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016502, 100003281, 'XM8 Woody', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016503, 100003281, 'XM8 Woody', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016601, 100003282, 'Famas G2 Newborn2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016602, 100003282, 'Famas G2 Newborn2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016603, 100003282, 'Famas G2 Newborn2016', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016701, 100003283, 'AUG A3 Puzzle', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016702, 100003283, 'AUG A3 Puzzle', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016703, 100003283, 'AUG A3 Puzzle', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016901, 100003286, 'Groza Silver', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016902, 100003286, 'Groza Silver', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016903, 100003286, 'Groza Silver', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017102, 100003288, 'Groza Russian Normal', 0, 350, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017201, 100003289, 'Groza Russian Deluxe', 0, 3500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017202, 100003289, 'Groza Russian Deluxe', 0, 350, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10016801, 100003285, 'Groza Gold', 0, 3700, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10016802, 100003285, 'Groza Gold', 0, 370, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10016803, 100003285, 'Groza Gold', 0, 2220, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10017203, 100003289, 'Groza Russian Deluxe', 0, 2100, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017301, 100003290, 'AUG A3 Liberty', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017302, 100003290, 'AUG A3 Liberty', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017303, 100003290, 'AUG A3 Liberty', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017401, 100003291, 'AUG A3 PBIC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017402, 100003291, 'AUG A3 PBIC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016501, 100003281, 'XM8 Woody', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017403, 100003291, 'AUG A3 PBIC2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017501, 100003292, 'SC-2010 PBIC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10013603, 100003251, 'AUG A3 Sakura', 0, 2400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (10017502, 100003292, 'SC-2010 PBIC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10016303, 100003279, 'AUG A3 Alien', 0, 2400, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017503, 100003292, 'SC-2010 PBIC2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017601, 100003293, 'K2C PBIC2016', 0, 3700, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017602, 100003293, 'K2C PBIC2016', 0, 370, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017603, 100003293, 'K2C PBIC2016', 0, 2220, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017701, 100003294, 'AUG A3 PBTC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017702, 100003294, 'AUG A3 PBTC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017703, 100003294, 'AUG A3 PBTC2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017801, 100003295, 'AUG A3 Dark Steel', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017802, 100003295, 'AUG A3 Dark Steel', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017803, 100003295, 'AUG A3 Dark Steel', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017901, 100003296, 'AUG A3 PBNC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017902, 100003296, 'AUG A3 PBNC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017903, 100003296, 'AUG A3 PBNC2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018001, 100003297, 'Pindad SS2 V5 PBNC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018002, 100003297, 'Pindad SS2 V5 PBNC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018003, 100003297, 'Pindad SS2 V5 PBNC2016', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014402, 100003259, 'AUG A3 Tiger-Normal', 15000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018101, 100003298, 'AUG A3 PBST2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018102, 100003298, 'AUG A3 PBST2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018103, 100003298, 'AUG A3 PBST2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018301, 100003300, 'AUG A3 Halloween 2016', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018302, 100003300, 'AUG A3 Halloween 2016', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018303, 100003300, 'AUG A3 Halloween 2016', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018401, 100003301, 'AK-12 Gorgeous', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018402, 100003301, 'AK-12 Gorgeous', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018403, 100003301, 'AK-12 Gorgeous', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018501, 100003302, 'AUG A3 Gorgeous', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018502, 100003302, 'AUG A3 Gorgeous', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018503, 100003302, 'AUG A3 Gorgeous', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018703, 100003010, 'M4A1 Camoflage with Silencer', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018801, 100003014, 'SG-550 Camoflage', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018802, 100003014, 'SG-550 Camoflage', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018803, 100003014, 'SG-550 Camoflage', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018901, 100003037, 'AUG A3 Gold', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018902, 100003037, 'AUG A3 Gold', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018903, 100003037, 'AUG A3 Gold', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019001, 100003038, 'G36C D.', 25000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019002, 100003038, 'G36C D.', 2500, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019003, 100003038, 'G36C D.', 15000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019101, 100003039, 'AK SOPMOD D', 42000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019102, 100003039, 'AK SOPMOD D', 4200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019103, 100003039, 'AK SOPMOD D', 25200, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019201, 100003040, 'AUG A3 D', 20000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019202, 100003040, 'AUG A3 D', 2000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019203, 100003040, 'AUG A3 D', 12000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019301, 100003041, 'AK SOPMOD CG.', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019302, 100003041, 'AK SOPMOD CG.', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019303, 100003041, 'AK SOPMOD CG.', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019401, 100003045, 'M4 SR-16 F.C.', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019402, 100003045, 'M4 SR-16 F.C.', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019403, 100003045, 'M4 SR-16 F.C.', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019501, 100003048, 'AUG A3 Black', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019502, 100003048, 'AUG A3 Black', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019503, 100003048, 'AUG A3 Black', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019801, 100003062, 'FAMAS G2 Commando E-Sports', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019802, 100003062, 'FAMAS G2 Commando E-Sports', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019803, 100003062, 'FAMAS G2 Commando E-Sports', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017003, 100003287, 'SC-2010 Dracula', 0, 2400, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017002, 100003287, 'SC-2010 Dracula', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017001, 100003287, 'SC-2010 Dracula', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10019901, 100003063, 'AUG A3 E-Sports', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019902, 100003063, 'AUG A3 E-Sports', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019903, 100003063, 'AUG A3 E-Sports', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018203, 100003299, 'AUG A3 SUPREME', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10018202, 100003299, 'AUG A3 SUPREME', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10020101, 100003065, 'AUG A3 Blue', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020102, 100003065, 'AUG A3 Blue', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020103, 100003065, 'AUG A3 Blue', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020301, 100003071, 'AUG A3 PBIC', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020302, 100003071, 'AUG A3 PBIC', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020303, 100003071, 'AUG A3 PBIC', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020401, 100003090, 'Famas G2/M', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020402, 100003090, 'Famas G2/M', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020403, 100003090, 'Famas G2/M', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020501, 100003091, 'Famas G2 Commando PBTN', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020502, 100003091, 'Famas G2 Commando PBTN', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019702, 100003052, 'FAMAS G2 M203', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10019703, 100003052, 'FAMAS G2 M203', 0, 1920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020002, 100003064, 'Famas G2 Commando Gold', 0, 350, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020003, 100003064, 'Famas G2 Commando Gold', 0, 2100, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020503, 100003091, 'Famas G2 Commando PBTN', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020601, 100003092, 'AK SOPMOD R', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020602, 100003092, 'AK SOPMOD R', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020603, 100003092, 'AK SOPMOD R', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020701, 100003093, 'AUG A3 Blitz', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020702, 100003093, 'AUG A3 Blitz', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020703, 100003093, 'AUG A3 Blitz', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021101, 100003097, 'AUG A3 GRS', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10014903, 100003264, 'Famas G2 M203 E-Sport2', 0, 2100, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10014802, 100003263, 'AUG A3 E-Sport2', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10021102, 100003097, 'AUG A3 GRS', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021103, 100003097, 'AUG A3 GRS', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021201, 100003098, 'M4A1 GRS', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021202, 100003098, 'M4A1 GRS', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021203, 100003098, 'M4A1 GRS', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021301, 100003099, 'AK SOPMOD GRS', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10018702, 100003010, 'M4A1 Camoflage with Silencer', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021302, 100003099, 'AK SOPMOD GRS', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021303, 100003099, 'AK SOPMOD GRS', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021401, 100003100, 'Famas G2 GRS', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021402, 100003100, 'Famas G2 GRS', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10019601, 100003051, 'FAMAS G2 M203', 32000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021403, 100003100, 'Famas G2 GRS', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021501, 100003103, 'M4 SR-16 D Hunter', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021502, 100003103, 'M4 SR-16 D Hunter', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021503, 100003103, 'M4 SR-16 D Hunter', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021601, 100003104, 'AUG A3 GSL', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021602, 100003104, 'AUG A3 GSL', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021603, 100003104, 'AUG A3 GSL', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021701, 100003105, 'Famas G2 Commando GSL', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021702, 100003105, 'Famas G2 Commando GSL', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021703, 100003105, 'Famas G2 Commando GSL', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021801, 100003111, 'AUG A3 Bralizian Edition', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021802, 100003111, 'AUG A3 Bralizian Edition', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021803, 100003111, 'AUG A3 Bralizian Edition', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020202, 100003068, 'AK-47 FC Red', 0, 420, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020203, 100003068, 'AK-47 FC Red', 0, 2520, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018603, 100003233, 'AUG A3 SPY', 30000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018602, 100003233, 'AUG A3 SPY', 15000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022001, 200004033, 'AKS74U Ext.', 4000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022002, 200004033, 'AKS74U Ext.', 16000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022101, 200004002, 'Spectre Ext.', 2000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022102, 200004002, 'Spectre Ext.', 8000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022201, 200004004, 'MP7 Ext.', 7500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022202, 200004004, 'MP7 Ext.', 30000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021901, 100003114, 'M4A1 Elite', 0, 3900, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021902, 100003114, 'M4A1 Elite', 0, 390, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022301, 200004134, 'OA-93', 18000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022302, 200004134, 'OA-93', 72000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022401, 200004007, 'MP5K G.', 1000, 0, 100, 1, 1, 2, 0, 20, 0);
INSERT INTO "public"."shop" VALUES (10022402, 200004007, 'MP5K G.', 4000, 0, 500, 1, 1, 2, 0, 20, 0);
INSERT INTO "public"."shop" VALUES (10022501, 200004043, 'SS1-R5 Carbine ', 1000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000401, 601013001, 'P99&HAK', 8000, 0, 100, 1, 1, 2, 0, 30, 0);
INSERT INTO "public"."shop" VALUES (10022502, 200004043, 'SS1-R5 Carbine ', 4000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022601, 200004008, 'UMP45 Ext.', 1000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022602, 200004008, 'UMP45 Ext.', 4000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022801, 200004096, 'AKS74U Reload', 4500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022802, 200004096, 'AKS74U Reload', 18000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022901, 200004097, 'UMP45 Reload', 1500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10022902, 200004097, 'UMP45 Reload', 6000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023001, 200004098, 'Spectre Reload', 1500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023002, 200004098, 'Spectre Reload', 6000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023201, 200004100, 'MP5K Reload', 1500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023202, 200004100, 'MP5K Reload', 6000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023301, 200004011, 'P90 Ext.', 12000, 0, 100, 1, 1, 2, 6, 0, 3);
INSERT INTO "public"."shop" VALUES (10023302, 200004011, 'P90 Ext.', 48000, 0, 500, 1, 1, 2, 6, 0, 3);
INSERT INTO "public"."shop" VALUES (10023501, 200004107, 'MP9 Ext', 9000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023502, 200004107, 'MP9 Ext', 36000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023601, 200004013, 'Kriss S.V', 6000, 0, 100, 1, 1, 2, 0, 24, 0);
INSERT INTO "public"."shop" VALUES (10023602, 200004013, 'Kriss S.V', 24000, 0, 500, 1, 1, 2, 0, 24, 0);
INSERT INTO "public"."shop" VALUES (10023701, 200004001, 'MP5K Ext.', 2000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023702, 200004001, 'MP5K Ext.', 8000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022702, 200004010, 'P90 MC', 42000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024302, 200018009, 'Dual Micro Uzi Silencer', 10200, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024401, 200018011, 'Dual Micro Uzi Silencer Sl.', 3000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10020802, 100003094, 'SCAR-L Carbine', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020803, 100003094, 'SCAR-L Carbine', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020901, 100003095, 'SCAR-L Recon', 0, 1500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020902, 100003095, 'SCAR-L Recon', 0, 150, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020903, 100003095, 'SCAR-L Recon', 0, 900, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021003, 100003096, 'SCAR-L FC', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10021001, 100003096, 'SCAR-L FC', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024402, 200018011, 'Dual Micro Uzi Silencer Sl.', 12000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024501, 200018013, 'Dual Mini Uzi G', 3500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024502, 200018013, 'Dual Mini Uzi G', 14000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024601, 200004045, 'MP7 Ext. D ', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024602, 200004045, 'MP7 Ext. D ', 0, 730, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024603, 200004045, 'MP7 Ext. D ', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024701, 200004046, 'UMP45 Ext. D ', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024702, 200004046, 'UMP45 Ext. D ', 0, 300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024703, 200004046, 'UMP45 Ext. D ', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024801, 200004049, 'SS1-R5 Carbine Gold', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024802, 200004049, 'SS1-R5 Carbine Gold', 0, 380, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024803, 200004049, 'SS1-R5 Carbine Gold', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024901, 200004050, 'Kriss S.V E-Sport', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024902, 200004050, 'Kriss S.V E-Sport', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10024903, 200004050, 'Kriss S.V E-Sport', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025001, 200004054, 'Kriss S.V Vector ', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025002, 200004054, 'Kriss S.V Vector ', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025003, 200004054, 'Kriss S.V Vector ', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025101, 200004060, 'Kriss S.V IC', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025102, 200004060, 'Kriss S.V IC', 0, 2090, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025103, 200004060, 'Kriss S.V IC', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025201, 200004075, 'P90 Gold ', 3200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10025202, 200004075, 'P90 Gold ', 18400, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10025203, 200004075, 'P90 Gold ', 32000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10025301, 200004078, 'P90 PBTN ', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025302, 200004078, 'P90 PBTN ', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025303, 200004078, 'P90 PBTN ', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025401, 200004079, 'Kriss S.V PBTN ', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025402, 200004079, 'Kriss S.V PBTN ', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025403, 200004079, 'Kriss S.V PBTN ', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025501, 200004081, 'MP7 GRS', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025502, 200004081, 'MP7 GRS', 0, 730, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025503, 200004081, 'MP7 GRS', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025601, 200004082, 'P90 MC GRS', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025602, 200004082, 'P90 MC GRS', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025603, 200004082, 'P90 MC GRS', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025701, 200004083, 'Kriss S.V GRS', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025702, 200004083, 'Kriss S.V GRS', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025703, 200004083, 'Kriss S.V GRS', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025801, 200004085, 'P90 Newborn', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025802, 200004085, 'P90 Newborn', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025803, 200004085, 'P90 Newborn', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025901, 200004087, 'Kriss S.V GSL', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025902, 200004087, 'Kriss S.V GSL', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10025903, 200004087, 'Kriss S.V GSL', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026001, 200004089, 'P90 GSL', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026002, 200004089, 'P90 GSL', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026003, 200004089, 'P90 GSL', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023802, 200018004, 'Dual Uzi', 4000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023901, 200018005, 'Dual Mini Uzi', 1500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023902, 200018005, 'Dual Mini Uzi', 6000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024001, 200018006, 'Dual Micro Uzi', 2000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024002, 200018006, 'Dual Micro Uzi', 8000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024101, 200018007, 'Dual Uzi Silencer', 2250, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024102, 200018007, 'Dual Uzi Silencer', 9000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024201, 200018008, 'Dual Mini Uzi Silencer', 2500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024202, 200018008, 'Dual Mini Uzi Silencer', 10000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10024301, 200018009, 'Dual Micro Uzi Silencer', 2550, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026101, 200004103, 'Kriss S.V PBIC2013', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026102, 200004103, 'Kriss S.V PBIC2013', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026103, 200004103, 'Kriss S.V PBIC2013', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026201, 200004108, 'Kriss S.V Silence', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026202, 200004108, 'Kriss S.V Silence', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026203, 200004108, 'Kriss S.V Silence', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026301, 200004110, 'Kriss S.V Turkey', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026302, 200004110, 'Kriss S.V Turkey', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026501, 200004113, 'P90 M.C. LATIN3', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023102, 200004099, 'SS1-R5 Carbine Reload', 6000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023401, 200004106, 'PP-19 Bizon', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10023402, 200004106, 'PP-19 Bizon', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026502, 200004113, 'P90 M.C. LATIN3', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026503, 200004113, 'P90 M.C. LATIN3', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026601, 200004114, 'P90 Ext BR Camo', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026602, 200004114, 'P90 Ext BR Camo', 0, 1920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026603, 200004114, 'P90 Ext BR Camo', 0, 3200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026701, 200004115, 'Kriss S.V Sakura', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026703, 200004115, 'Kriss S.V Sakura', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026801, 200004116, 'Kriss S.V Serpent', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026802, 200004116, 'Kriss S.V Serpent', 0, 2050, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026803, 200004116, 'Kriss S.V Serpent', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026901, 200004118, 'P90 Serpent', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026902, 200004118, 'P90 Serpent', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026903, 200004118, 'P90 Serpent', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027001, 200004144, 'Kriss S.V W.O.E', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027002, 200004144, 'Kriss S.V W.O.E', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027003, 200004144, 'Kriss S.V W.O.E', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027101, 200004146, 'P90 Ext PBIC2014', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027102, 200004146, 'P90 Ext PBIC2014', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027103, 200004146, 'P90 Ext PBIC2014', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027301, 200004155, 'Kriss S.V G E-Sport', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027302, 200004155, 'Kriss S.V G E-Sport', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027303, 200004155, 'Kriss S.V G E-Sport', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027401, 200004157, 'Kriss S.V Toy', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027402, 200004157, 'Kriss S.V Toy', 0, 2050, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027403, 200004157, 'Kriss S.V Toy', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027501, 200004159, 'OA-93 D.', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027502, 200004159, 'OA-93 D.', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027503, 200004159, 'OA-93 D.', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027601, 200004161, 'MP9 Ext Gold', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027602, 200004161, 'MP9 Ext Gold', 0, 730, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027603, 200004161, 'MP9 Ext Gold', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027801, 200004163, 'P90 Ext. LATIN4', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027802, 200004163, 'P90 Ext. LATIN4', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027803, 200004163, 'P90 Ext. LATIN4', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027901, 200004164, 'MP9 Ext Especial de Natal', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027902, 200004164, 'MP9 Ext Especial de Natal', 0, 650, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027903, 200004164, 'MP9 Ext Especial de Natal', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028001, 200004165, 'OA-93 Especial de Natal', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028002, 200004165, 'OA-93 Especial de Natal', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028003, 200004165, 'OA-93 Especial de Natal', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028101, 200004167, 'PP-19 Bizon Especial de Natal', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028102, 200004167, 'PP-19 Bizon Especial de Natal', 0, 2310, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028103, 200004167, 'PP-19 Bizon Especial de Natal', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028201, 200004168, 'Kriss S.V Especial de Natal', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028202, 200004168, 'Kriss S.V Especial de Natal', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028203, 200004168, 'Kriss S.V Especial de Natal', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028301, 200004170, 'Kriss S.V Couple Breaker', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028302, 200004170, 'Kriss S.V Couple Breaker', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028303, 200004170, 'Kriss S.V Couple Breaker', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028401, 200004172, 'Kriss S.V ANC 2015', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028402, 200004172, 'Kriss S.V ANC 2015', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028403, 200004172, 'Kriss S.V ANC 2015', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028501, 200004174, 'P90 M.C Sheep', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028502, 200004174, 'P90 M.C Sheep', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028503, 200004174, 'P90 M.C Sheep', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028601, 200004175, 'Kriss S.V GRS2', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028602, 200004175, 'Kriss S.V GRS2', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028603, 200004175, 'Kriss S.V GRS2', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028701, 200004178, 'Kriss S.V Newborn 2015', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028702, 200004178, 'Kriss S.V Newborn 2015', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028703, 200004178, 'Kriss S.V Newborn 2015', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028801, 200004180, 'OA-93 GSL2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028802, 200004180, 'OA-93 GSL2015', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028803, 200004180, 'OA-93 GSL2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028901, 200004182, 'P90 Ext Silence GSL2015', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028902, 200004182, 'P90 Ext Silence GSL2015', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10028903, 200004182, 'P90 Ext Silence GSL2015', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029001, 200004237, 'Kriss S.V Halloween', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007802, 601002029, 'GL-06', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029002, 200004237, 'Kriss S.V Halloween', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029003, 200004237, 'Kriss S.V Halloween', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029101, 200004240, 'P90 M.C SPY', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029102, 200004240, 'P90 M.C SPY', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029103, 200004240, 'P90 M.C SPY', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029201, 200004241, 'P90 M.C Latin5', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029202, 200004241, 'P90 M.C Latin5', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029203, 200004241, 'P90 M.C Latin5', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029301, 200004242, 'Kriss S.V Obsidian', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029302, 200004242, 'Kriss S.V Obsidian', 0, 2070, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029303, 200004242, 'Kriss S.V Obsidian', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029401, 200004244, 'P90 M.C Spy-Deluxe', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029402, 200004244, 'P90 M.C Spy-Deluxe', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029403, 200004244, 'P90 M.C Spy-Deluxe', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029501, 200004245, 'Kriss S.V DFN', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029502, 200004245, 'Kriss S.V DFN', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029503, 200004245, 'Kriss S.V DFN', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026401, 200004112, 'P90 M.C Bloody', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029601, 200004247, 'OA-93 DFN', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029602, 200004247, 'OA-93 DFN', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029603, 200004247, 'OA-93 DFN', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029701, 200004249, 'Kriss S.V XMAS2015', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027202, 200004151, 'Kriss S.V PC Cafe', 16000, 500, 604800, 2, 1, 2, 0, 4, 2);
INSERT INTO "public"."shop" VALUES (10029702, 200004249, 'Kriss S.V XMAS2015', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029703, 200004249, 'Kriss S.V XMAS2015', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029801, 200004251, 'OA-93 XMAS2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029802, 200004251, 'OA-93 XMAS2015', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10029803, 200004251, 'OA-93 XMAS2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000801, 702001021, 'Keris', 4500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027703, 200004162, 'PP-19 Bizon Gold', 0, 3800, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10030001, 200004255, 'Kriss S.V GRS3', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030002, 200004255, 'Kriss S.V GRS3', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030003, 200004255, 'Kriss S.V GRS3', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030101, 200004258, 'Kriss S.V Beast', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030102, 200004258, 'Kriss S.V Beast', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030103, 200004258, 'Kriss S.V Beast', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030401, 200004263, 'Kriss S.V GSL2016', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030402, 200004263, 'Kriss S.V GSL2016', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030403, 200004263, 'Kriss S.V GSL2016', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030501, 200004265, 'Kriss S.V Midnigth2', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030502, 200004265, 'Kriss S.V Midnigth2', 0, 2300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030503, 200004265, 'Kriss S.V Midnigth2', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030601, 200004267, 'Kriss S.V Skeleton', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030202, 200004260, 'Kriss S.V PBGC', 0, 2130, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10030301, 200004262, 'P90 PBGC', 0, 320, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10030303, 200004262, 'P90 PBGC', 0, 3200, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10030302, 200004262, 'P90 PBGC', 0, 1920, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10030602, 200004267, 'Kriss S.V Skeleton', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030603, 200004267, 'Kriss S.V Skeleton', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030701, 200004269, 'P90 Ext Skeleton', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030702, 200004269, 'P90 Ext Skeleton', 0, 2140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030703, 200004269, 'P90 Ext Skeleton', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030901, 200004185, 'Kriss S.V Ongame', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030902, 200004185, 'Kriss S.V Ongame', 0, 2350, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030903, 200004185, 'Kriss S.V Ongame', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031001, 200004187, 'P90 Ext Ongame', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031002, 200004187, 'P90 Ext Ongame', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031003, 200004187, 'P90 Ext Ongame', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031101, 200004188, 'Kriss S.V Redemption', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031102, 200004188, 'Kriss S.V Redemption', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031103, 200004188, 'Kriss S.V Redemption', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031201, 200004190, 'P90 Ext Redemption', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031202, 200004190, 'P90 Ext Redemption', 0, 1980, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031203, 200004190, 'P90 Ext Redemption', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031502, 200004196, 'Kriss S.V Harimau', 0, 2090, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031503, 200004196, 'Kriss S.V Harimau', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031601, 200004198, 'OA-93 Independência', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031602, 200004198, 'OA-93 Independência', 0, 2650, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031603, 200004198, 'OA-93 Independência', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031701, 200004200, 'P90 M.C Brasil', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031702, 200004200, 'P90 M.C Brasil', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031703, 200004200, 'P90 M.C Brasil', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031801, 200004201, 'Kriss S.V Red', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031802, 200004201, 'Kriss S.V Red', 0, 2300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031803, 200004201, 'Kriss S.V Red', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031901, 200004203, 'OA-93 PBST2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031902, 200004203, 'OA-93 PBST2015', 0, 2800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031903, 200004203, 'OA-93 PBST2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032001, 200004205, 'Kriss S.V PBNC2015', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032002, 200004205, 'Kriss S.V PBNC2015', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032003, 200004205, 'Kriss S.V PBNC2015', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032101, 200004207, 'Kriss S.V PBTC2015', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032102, 200004207, 'Kriss S.V PBTC2015', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032103, 200004207, 'Kriss S.V PBTC2015', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032201, 200004209, 'Kriss S.V Mech', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032202, 200004209, 'Kriss S.V Mech', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032203, 200004209, 'Kriss S.V Mech', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032301, 200004210, 'P90 Mech', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032302, 200004210, 'P90 Mech', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032303, 200004210, 'P90 Mech', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032401, 200004212, 'Kriss S.V DarkDays', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032402, 200004212, 'Kriss S.V DarkDays', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032403, 200004212, 'Kriss S.V DarkDays', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032501, 200004214, 'OA-93 PBNC2015 U.S.', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032502, 200004214, 'OA-93 PBNC2015 U.S.', 0, 2800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032503, 200004214, 'OA-93 PBNC2015 U.S.', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032601, 200004216, 'Kriss S.V PBIC2015', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032602, 200004216, 'Kriss S.V PBIC2015', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032603, 200004216, 'Kriss S.V PBIC2015', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032701, 200004218, 'P90 Ext PBIC2015', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032702, 200004218, 'P90 Ext PBIC2015', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032703, 200004218, 'P90 Ext PBIC2015', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10032801, 200004219, 'P90 M.C Gold', 3200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10032802, 200004219, 'P90 M.C Gold', 22400, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10032803, 200004219, 'P90 M.C Gold', 32000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10029902, 200004253, 'Kriss S.V Monkey', 0, 2100, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10031402, 200004195, 'P90 M.C. Rose', 0, 1000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031403, 200004195, 'P90 M.C. Rose', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031501, 200004196, 'Kriss S.V Harimau', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10031401, 200004195, 'P90 M.C. Rose', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033001, 200004221, 'Kriss S.V Sheep', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033002, 200004221, 'Kriss S.V Sheep', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033003, 200004221, 'Kriss S.V Sheep', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033101, 200004223, 'Kriss S.V Basketball', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033102, 200004223, 'Kriss S.V Basketball', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033103, 200004223, 'Kriss S.V Basketball', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033201, 200004225, 'OA-93 Basketball', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033202, 200004225, 'OA-93 Basketball', 0, 2800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033203, 200004225, 'OA-93 Basketball', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033301, 200004227, 'P90 Basketball', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033302, 200004227, 'P90 Basketball', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033303, 200004227, 'P90 Basketball', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033401, 200004228, 'OA-93 Medical', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033402, 200004228, 'OA-93 Medical', 0, 2800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10033403, 200004228, 'OA-93 Medical', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033501, 200004230, 'P90 Ext Medical', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033502, 200004230, 'P90 Ext Medical', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033503, 200004230, 'P90 Ext Medical', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033601, 200004231, 'MP9 Ext. D.', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033602, 200004231, 'MP9 Ext. D.', 0, 1050, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033603, 200004231, 'MP9 Ext. D.', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000802, 702001021, 'Keris', 18000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033801, 200004234, 'P90 M.C Camo Soldier', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033802, 200004234, 'P90 M.C Camo Soldier', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033803, 200004234, 'P90 M.C Camo Soldier', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033901, 200004235, 'Kriss S.V Steam', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033902, 200004235, 'Kriss S.V Steam', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033903, 200004235, 'Kriss S.V Steam', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034001, 200004272, 'P90 Ext. Dragon', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034002, 200004272, 'P90 Ext. Dragon', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034003, 200004272, 'P90 Ext. Dragon', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034101, 200004273, 'OA-93 PBWC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034102, 200004273, 'OA-93 PBWC2016', 0, 2800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034103, 200004273, 'OA-93 PBWC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034201, 200004275, 'Kriss S.V PBWC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034202, 200004275, 'Kriss S.V PBWC2016', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034203, 200004275, 'Kriss S.V PBWC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034301, 200004277, 'P90 Ext. PBWC2016', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034302, 200004277, 'P90 Ext. PBWC2016', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034303, 200004277, 'P90 Ext. PBWC2016', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034401, 200004278, 'Kriss S.V Mummy', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034402, 200004278, 'Kriss S.V Mummy', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034403, 200004278, 'Kriss S.V Mummy', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034501, 200004280, 'Kriss S.V ID 1stAnni', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034502, 200004280, 'Kriss S.V ID 1stAnni', 0, 2240, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034503, 200004280, 'Kriss S.V ID 1stAnni', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034601, 200004282, 'P90 Ext. 1stAnni', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034602, 200004282, 'P90 Ext. 1stAnni', 0, 2090, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034603, 200004282, 'P90 Ext. 1stAnni', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034701, 200004283, 'Kriss S.V Strike', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034702, 200004283, 'Kriss S.V Strike', 0, 2350, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034703, 200004283, 'Kriss S.V Strike', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034801, 200004285, 'P90 Ext. Silence Strike', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034802, 200004285, 'P90 Ext. Silence Strike', 0, 2140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034803, 200004285, 'P90 Ext. Silence Strike', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034901, 200004286, 'Kriss S.V Demonic', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034902, 200004286, 'Kriss S.V Demonic', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10034903, 200004286, 'Kriss S.V Demonic', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035001, 200004288, 'P90 Ext. Silence Demonic', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035002, 200004288, 'P90 Ext. Silence Demonic', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035003, 200004288, 'P90 Ext. Silence Demonic', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035101, 200004289, 'Kriss S.V Dolphin', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035102, 200004289, 'Kriss S.V Dolphin', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035103, 200004289, 'Kriss S.V Dolphin', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035201, 200004291, 'P90 Ext Dolphin', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035202, 200004291, 'P90 Ext Dolphin', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035203, 200004291, 'P90 Ext Dolphin', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035301, 200004292, 'OA-93 Blue Diamond', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035302, 200004292, 'OA-93 Blue Diamond', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035303, 200004292, 'OA-93 Blue Diamond', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035401, 200004294, 'P90 Ext Lebaran2016', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035402, 200004294, 'P90 Ext Lebaran2016', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035403, 200004294, 'P90 Ext Lebaran2016', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035501, 200004295, 'Kriss S.V Lebaran2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035503, 200004295, 'Kriss S.V Lebaran2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035801, 200004300, 'OA-93 Woody', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035802, 200004300, 'OA-93 Woody', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035803, 200004300, 'OA-93 Woody', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035901, 200004302, 'OA-93 Newborn2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035902, 200004302, 'OA-93 Newborn2016', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035903, 200004302, 'OA-93 Newborn2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036001, 200004304, 'Kriss S.V Puzzle', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036002, 200004304, 'Kriss S.V Puzzle', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036003, 200004304, 'Kriss S.V Puzzle', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030803, 200004270, 'Kriss S.V E-Sport2', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10030801, 200004270, 'Kriss S.V E-Sport2', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10036101, 200004306, 'P90 Ext. Puzzle', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036102, 200004306, 'P90 Ext. Puzzle', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036103, 200004306, 'P90 Ext. Puzzle', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036201, 200004121, 'Kriss S.V TH 1st Anniversary', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036202, 200004121, 'Kriss S.V TH 1st Anniversary', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036203, 200004121, 'Kriss S.V TH 1st Anniversary', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036302, 200004308, 'PP-19 Bizon Russian Deluxe', 0, 2310, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10036303, 200004308, 'PP-19 Bizon Russian Deluxe', 0, 3800, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10036401, 200004309, 'OA-93 Liberty', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035701, 200004298, 'Kriss S.V Alien', 0, 320, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10035702, 200004298, 'Kriss S.V Alien', 0, 1920, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10035602, 200004297, 'P90 Ext. Alien', 0, 1920, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10036402, 200004309, 'OA-93 Liberty', 0, 2480, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036403, 200004309, 'OA-93 Liberty', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036501, 200004311, 'P90 Ext. Liberty', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036502, 200004311, 'P90 Ext. Liberty', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036503, 200004311, 'P90 Ext. Liberty', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036601, 200004312, 'Kriss S.V PBIC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036602, 200004312, 'Kriss S.V PBIC2016', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036603, 200004312, 'Kriss S.V PBIC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033702, 200004232, 'OA-93 Cobra', 0, 2800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10033703, 200004232, 'OA-93 Cobra', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10036701, 200004314, 'OA-93 PBIC2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036702, 200004314, 'OA-93 PBIC2016', 0, 2450, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036703, 200004314, 'OA-93 PBIC2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036801, 200004316, 'Kriss S.V PBTC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036802, 200004316, 'Kriss S.V PBTC2016', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036803, 200004316, 'Kriss S.V PBTC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036901, 200004318, 'Kriss S.V Dark Steel', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036902, 200004318, 'Kriss S.V Dark Steel', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10036903, 200004318, 'Kriss S.V Dark Steel', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037001, 200004320, 'P90 Ext. Dark Steel', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037002, 200004320, 'P90 Ext. Dark Steel', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037003, 200004320, 'P90 Ext. Dark Steel', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037101, 200004321, 'Kriss S.V PBNC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037102, 200004321, 'Kriss S.V PBNC2016', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037103, 200004321, 'Kriss S.V PBNC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037201, 200004323, 'Kriss S.V PBST2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037202, 200004323, 'Kriss S.V PBST2016', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037203, 200004323, 'Kriss S.V PBST2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037501, 200004328, 'OA-93 Halloween 2016', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037502, 200004328, 'OA-93 Halloween 2016', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037503, 200004328, 'OA-93 Halloween 2016', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037601, 200004330, 'Kriss S.V Gorgeous', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037602, 200004330, 'Kriss S.V Gorgeous', 0, 2090, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037603, 200004330, 'Kriss S.V Gorgeous', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037701, 200004332, 'OA-93 Gorgeous', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037702, 200004332, 'OA-93 Gorgeous', 0, 2420, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037703, 200004332, 'OA-93 Gorgeous', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037801, 200004307, 'PP-19 Bizon Russian Normal', 0, 380, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10037802, 200004307, 'PP-19 Bizon Russian Normal', 0, 2340, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10037803, 200004307, 'PP-19 Bizon Russian Normal', 0, 3800, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10037901, 200004123, 'Kriss S.V R', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037902, 200004123, 'Kriss S.V R', 0, 2300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037903, 200004123, 'Kriss S.V R', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038001, 200004126, 'Kriss S.V Inferno', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038002, 200004126, 'Kriss S.V Inferno', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038003, 200004126, 'Kriss S.V Inferno', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038101, 200004128, 'P90 Inferno', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038102, 200004128, 'P90 Inferno', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038103, 200004128, 'P90 Inferno', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038201, 200004129, 'P90 Ext PBNC5', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038202, 200004129, 'P90 Ext PBNC5', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038203, 200004129, 'P90 Ext PBNC5', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038301, 200004130, 'Kriss S.V GSL2014', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038302, 200004130, 'Kriss S.V GSL2014', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038303, 200004130, 'Kriss S.V GSL2014', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038401, 200004132, 'Kriss S.V Midnight', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038402, 200004132, 'Kriss S.V Midnight', 0, 2130, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038403, 200004132, 'Kriss S.V Midnight', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038801, 200004142, 'Kriss S.V Champion', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038802, 200004142, 'Kriss S.V Champion', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038803, 200004142, 'Kriss S.V Champion', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10038901, 200004005, 'Kriss S.V Cupido', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10037303, 200004325, 'Kriss S.V SUPREME', 0, 3500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10037401, 200004327, 'P90 Ext. SUPREME', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10037403, 200004327, 'P90 Ext. SUPREME', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10037301, 200004325, 'Kriss S.V SUPREME', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10038501, 200004136, 'OA-93 Gold', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038903, 200004005, 'Kriss S.V Cupido', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039001, 200004014, 'MP5K Silver', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039002, 200004014, 'MP5K Silver', 0, 730, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039003, 200004014, 'MP5K Silver', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039101, 200004017, 'P90 Cupido', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039103, 200004017, 'P90 Cupido', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039201, 200004020, 'Spectre Silver', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039202, 200004020, 'Spectre Silver', 0, 380, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039203, 200004020, 'Spectre Silver', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039301, 200004021, 'K-1 Silver', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039302, 200004021, 'K-1 Silver', 0, 3150, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039303, 200004021, 'K-1 Silver', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039401, 200004023, 'UMP45 Sl.', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039402, 200004023, 'UMP45 Sl.', 0, 380, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039403, 200004023, 'UMP45 Sl.', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039601, 200004027, 'P90 MC Camoflage', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039602, 200004027, 'P90 MC Camoflage', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039603, 200004027, 'P90 MC Camoflage', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039701, 200004029, 'P90 Ext D', 2600, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039702, 200004029, 'P90 Ext D', 14700, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039703, 200004029, 'P90 Ext D', 26000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039102, 200004017, 'P90 Cupido', 60000, 1920, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10038601, 200004138, 'P90 Brazuca', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038602, 200004138, 'P90 Brazuca', 0, 1920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038603, 200004138, 'P90 Brazuca', 0, 3200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038702, 200004139, 'Kriss S.V Brazuca', 0, 1890, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038703, 200004139, 'Kriss S.V Brazuca', 0, 3200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039801, 200004030, 'Kriss S.V D', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039802, 200004030, 'Kriss S.V D', 0, 1840, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10039803, 200004030, 'Kriss S.V D', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040101, 200004038, 'MP7 Camoflage', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040102, 200004038, 'MP7 Camoflage', 0, 730, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040103, 200004038, 'MP7 Camoflage', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040201, 200004039, 'Kriss S.V Black', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040202, 200004039, 'Kriss S.V Black', 0, 1890, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040203, 200004039, 'Kriss S.V Black', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040501, 300005029, 'VSK94', 7500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040502, 300005029, 'VSK94', 30000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040601, 300005072, 'Walther WA2000', 12000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040602, 300005072, 'Walther WA2000', 48000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10040701, 300005030, 'Cheytac M200', 15000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040702, 300005030, 'Cheytac M200', 60000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042001, 300005059, 'PSG1 Reload', 4000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042002, 300005059, 'PSG1 Reload', 16000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042201, 300005005, 'L115A1', 9000, 0, 100, 1, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (10041302, 300005089, 'L115A1 PC Cafe', 16000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042202, 300005005, 'L115A1', 36000, 0, 500, 1, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (10042301, 300005006, 'Dragunov Gold', 1500, 0, 100, 1, 1, 2, 0, 14, 0);
INSERT INTO "public"."shop" VALUES (10042302, 300005006, 'Dragunov Gold', 6000, 0, 500, 1, 1, 2, 0, 14, 0);
INSERT INTO "public"."shop" VALUES (10042401, 300005001, 'Dragunov', 1000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042402, 300005001, 'Dragunov', 4000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042501, 300005109, 'L115A1 Harimau', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042502, 300005109, 'L115A1 Harimau', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042503, 300005109, 'L115A1 Harimau', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10041602, 300005123, 'Tactilite T2', 64000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040802, 300005018, 'M4 SPR Lvl-1', 36000, 0, 500, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10039501, 200004026, 'Kriss S.V Gold', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039502, 200004026, 'Kriss S.V Gold', 0, 1920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039503, 200004026, 'Kriss S.V Gold', 0, 3200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042703, 300005009, 'PSG-1 Silver', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042801, 300005010, 'Dragunov Silver', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042802, 300005010, 'Dragunov Silver', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042803, 300005010, 'Dragunov Silver', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042901, 300005011, 'Dragunov CS.', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042902, 300005011, 'Dragunov CS.', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042903, 300005011, 'Dragunov CS.', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043001, 300005014, 'Dragunov Gold D.', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043002, 300005014, 'Dragunov Gold D.', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043003, 300005014, 'Dragunov Gold D.', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043101, 300005015, 'L115A1 Gold', 3100, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043102, 300005015, 'L115A1 Gold', 18600, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043103, 300005015, 'L115A1 Gold', 31000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043201, 300005017, 'L115A1 D', 3100, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043202, 300005017, 'L115A1 D', 18600, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043203, 300005017, 'L115A1 D', 31000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043301, 300005019, 'M4 SRP Lvl-2', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043302, 300005019, 'M4 SRP Lvl-2', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10041402, 300005021, 'Rangemaster .338', 44000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040901, 300005002, 'PSG-1', 2500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040902, 300005002, 'PSG-1', 10000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041001, 300005034, 'DSR-1', 10000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041002, 300005034, 'DSR-1', 25000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041101, 300005157, 'AS 50', 6000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041102, 300005157, 'AS 50', 24000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041201, 300005035, 'SVU', 4500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041202, 300005035, 'SVU', 18000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040401, 300005068, 'XM2010', 8920, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040402, 300005068, 'XM2010', 35680, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039901, 200004032, 'P90 M.C D', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039903, 200004032, 'P90 M.C D', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040001, 200004037, 'MP7 Silver', 0, 150, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040002, 200004037, 'MP7 Silver', 0, 730, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040003, 200004037, 'MP7 Silver', 0, 1500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040301, 200004041, 'MP5K Silver D ', 0, 150, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040302, 200004041, 'MP5K Silver D ', 0, 730, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040303, 200004041, 'MP5K Silver D ', 0, 1500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041501, 300005012, 'Dragunov CG.', 1250, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041502, 300005012, 'Dragunov CG.', 5000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041701, 300005007, 'PSG-1 S.', 3500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041702, 300005007, 'PSG-1 S.', 14000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041801, 300005024, 'PSG-1 Gold', 3000, 0, 100, 1, 1, 2, 0, 16, 0);
INSERT INTO "public"."shop" VALUES (10041802, 300005024, 'PSG-1 Gold', 12000, 0, 500, 1, 1, 2, 0, 16, 0);
INSERT INTO "public"."shop" VALUES (10042601, 300005008, 'SSG-69 Silver', 0, 100, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042602, 300005008, 'SSG-69 Silver', 0, 600, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042603, 300005008, 'SSG-69 Silver', 0, 1000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042701, 300005009, 'PSG-1 Silver', 0, 100, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042702, 300005009, 'PSG-1 Silver', 0, 600, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043303, 300005019, 'M4 SRP Lvl-2', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043501, 300005022, 'Rangemaster 7.62', 2000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043502, 300005022, 'Rangemaster 7.62', 12000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043503, 300005022, 'Rangemaster 7.62', 20000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043601, 300005023, 'Rangemaster 7.62 STBY', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043602, 300005023, 'Rangemaster 7.62 STBY', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043603, 300005023, 'Rangemaster 7.62 STBY', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10041902, 300005145, 'PGM Hecate2', 76000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043701, 300005026, 'L115A1 Black', 3100, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043702, 300005026, 'L115A1 Black', 18600, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043703, 300005026, 'L115A1 Black', 31000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043801, 300005028, 'Dragunov D', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043802, 300005028, 'Dragunov D', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043803, 300005028, 'Dragunov D', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043901, 300005031, 'Winchester M70', 1500, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043902, 300005031, 'Winchester M70', 9000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10043903, 300005031, 'Winchester M70', 15000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10044001, 300005033, 'L115A1 E-Sport', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044002, 300005033, 'L115A1 E-Sport', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044003, 300005033, 'L115A1 E-Sport', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044101, 300005036, 'L115A1 SE', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044102, 300005036, 'L115A1 SE', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044103, 300005036, 'L115A1 SE', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044201, 300005050, 'L115A1 PBTN', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044202, 300005050, 'L115A1 PBTN', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044203, 300005050, 'L115A1 PBTN', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044301, 300005052, 'Cheytac M200 GRS', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044302, 300005052, 'Cheytac M200 GRS', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044303, 300005052, 'Cheytac M200 GRS', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044401, 300005055, 'Cheytac M200 GSL', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044402, 300005055, 'Cheytac M200 GSL', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044403, 300005055, 'Cheytac M200 GSL', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044601, 300005064, 'L115A1 LATIN3', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044602, 300005064, 'L115A1 LATIN3', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044603, 300005064, 'L115A1 LATIN3', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044701, 300005065, 'L115A1 BR Camo', 0, 310, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10044702, 300005065, 'L115A1 BR Camo', 0, 1860, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10044703, 300005065, 'L115A1 BR Camo', 0, 3100, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10044801, 300005071, 'Cheytac M200 TH 1st Anniversary', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044802, 300005071, 'Cheytac M200 TH 1st Anniversary', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044803, 300005071, 'Cheytac M200 TH 1st Anniversary', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044901, 300005073, 'Cheytac M200 R', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044902, 300005073, 'Cheytac M200 R', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044903, 300005073, 'Cheytac M200 R', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045001, 300005075, 'PSG1 Elite', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045002, 300005075, 'PSG1 Elite', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045003, 300005075, 'PSG1 Elite', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045101, 300005076, 'Dragunov Elite', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045102, 300005076, 'Dragunov Elite', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045103, 300005076, 'Dragunov Elite', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045201, 300005077, 'SVU Elite', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045202, 300005077, 'SVU Elite', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10043403, 300005020, 'M4 SRP Lvl-3', 0, 3000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10043402, 300005020, 'M4 SRP Lvl-3', 0, 1800, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10045203, 300005077, 'SVU Elite', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045301, 300005078, 'VSK94 Elite', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045302, 300005078, 'VSK94 Elite', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045303, 300005078, 'VSK94 Elite', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045401, 300005079, 'Cheytac M200 Inferno', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045402, 300005079, 'Cheytac M200 Inferno', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045403, 300005079, 'Cheytac M200 Inferno', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045501, 300005080, 'Cheytac M200 PBNC5', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045502, 300005080, 'Cheytac M200 PBNC5', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045503, 300005080, 'Cheytac M200 PBNC5', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045601, 300005081, 'L115A1 GSL2014', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045602, 300005081, 'L115A1 GSL2014', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045603, 300005081, 'L115A1 GSL2014', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045901, 300005084, 'Cheytac M200 Champion', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045902, 300005084, 'Cheytac M200 Champion', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045903, 300005084, 'Cheytac M200 Champion', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046001, 300005085, 'Cheytac M200 W.O.E', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046002, 300005085, 'Cheytac M200 W.O.E', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046003, 300005085, 'Cheytac M200 W.O.E', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046101, 300005110, 'Cheytac M200 Brazil', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046102, 300005110, 'Cheytac M200 Brazil', 0, 1400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046103, 300005110, 'Cheytac M200 Brazil', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046201, 300005111, 'Cheytac M200 PBST2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046202, 300005111, 'Cheytac M200 PBST2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046203, 300005111, 'Cheytac M200 PBST2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046301, 300005112, 'Cheytac M200 4Game', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046302, 300005112, 'Cheytac M200 4Game', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046303, 300005112, 'Cheytac M200 4Game', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046401, 300005113, 'Cheytac M200 4Game SE', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046402, 300005113, 'Cheytac M200 4Game SE', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046403, 300005113, 'Cheytac M200 4Game SE', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046501, 300005114, 'Cheytac M200 PBNC2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046502, 300005114, 'Cheytac M200 PBNC2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046503, 300005114, 'Cheytac M200 PBNC2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046601, 300005115, 'Cheytac M200 PBTC2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046602, 300005115, 'Cheytac M200 PBTC2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046603, 300005115, 'Cheytac M200 PBTC2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046701, 300005116, 'SVU PBTC2015', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045802, 300005083, 'Cheytac M200 Brazuca', 0, 2580, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10046702, 300005116, 'SVU PBTC2015', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046703, 300005116, 'SVU PBTC2015', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046901, 300005118, 'Cheytac M200 DarkDays', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046902, 300005118, 'Cheytac M200 DarkDays', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046903, 300005118, 'Cheytac M200 DarkDays', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047001, 300005119, 'XM2010 PBNC2015US', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047002, 300005119, 'XM2010 PBNC2015US', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047003, 300005119, 'XM2010 PBNC2015US', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047101, 300005120, 'Cheytac M200 PBIC2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047102, 300005120, 'Cheytac M200 PBIC2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047103, 300005120, 'Cheytac M200 PBIC2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047201, 300005121, 'Cheytac M200 Gold', 4300, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047202, 300005121, 'Cheytac M200 Gold', 25800, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047203, 300005121, 'Cheytac M200 Gold', 43000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047401, 300005124, 'Cheytac M200 Sheep', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047402, 300005124, 'Cheytac M200 Sheep', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047403, 300005124, 'Cheytac M200 Sheep', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047501, 300005125, 'L115A1 Basketball', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047502, 300005125, 'L115A1 Basketball', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047503, 300005125, 'L115A1 Basketball', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047601, 300005126, 'Cheytac M200 Medical', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10047602, 300005126, 'Cheytac M200 Medical', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047603, 300005126, 'Cheytac M200 Medical', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007803, 601002029, 'GL-06', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10045803, 300005083, 'Cheytac M200 Brazuca', 0, 4300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047901, 300005130, 'Cheytac M200 Steam', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047902, 300005130, 'Cheytac M200 Steam', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047903, 300005130, 'Cheytac M200 Steam', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048001, 300005131, 'Cheytac M200 Halloween', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048002, 300005131, 'Cheytac M200 Halloween', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048003, 300005131, 'Cheytac M200 Halloween', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048201, 300005133, 'DSR-1 SPY', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048202, 300005133, 'DSR-1 SPY', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048203, 300005133, 'DSR-1 SPY', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048301, 300005134, 'Cheytac M200 Latin5', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048302, 300005134, 'Cheytac M200 Latin5', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048303, 300005134, 'Cheytac M200 Latin5', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048401, 300005135, 'Cheytac M200 Obsidian', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048402, 300005135, 'Cheytac M200 Obsidian', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048403, 300005135, 'Cheytac M200 Obsidian', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048501, 300005136, 'DSR-1 Spy-Deluxe', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048502, 300005136, 'DSR-1 Spy-Deluxe', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047802, 300005128, 'Rangermaster .338 Camo Soldier', 0, 1800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047803, 300005128, 'Rangermaster .338 Camo Soldier', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10048503, 300005136, 'DSR-1 Spy-Deluxe', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048601, 300005137, 'Cheytac M200 DFN', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048602, 300005137, 'Cheytac M200 DFN', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048102, 300005132, 'Tactilite T2 G.', 0, 2700, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10048103, 300005132, 'Tactilite T2 G.', 0, 4500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10046801, 300005117, 'L115A1 Mech', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046802, 300005117, 'L115A1 Mech', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10046803, 300005117, 'L115A1 Mech', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048603, 300005137, 'Cheytac M200 DFN', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048701, 300005138, 'Cheytac M200 XMAS2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048702, 300005138, 'Cheytac M200 XMAS2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048703, 300005138, 'Cheytac M200 XMAS2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047302, 300005122, 'Cheytac M200 VeraCruz', 0, 2580, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10047303, 300005122, 'Cheytac M200 VeraCruz', 0, 4300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10048801, 300005139, 'Tactilite T2 XMAS2015', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048802, 300005139, 'Tactilite T2 XMAS2015', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048803, 300005139, 'Tactilite T2 XMAS2015', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049101, 300005142, 'Cheytac M200 Arena Deluxe', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049102, 300005142, 'Cheytac M200 Arena Deluxe', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049103, 300005142, 'Cheytac M200 Arena Deluxe', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049301, 300005144, 'Cheytac M200 Silence', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049302, 300005144, 'Cheytac M200 Silence', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049303, 300005144, 'Cheytac M200 Silence', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049501, 300005147, 'Cheytac M200 Cupid', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049503, 300005147, 'Cheytac M200 Cupid', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049601, 300005148, 'Cheytac M200 Sakura', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049603, 300005148, 'Cheytac M200 Sakura', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047703, 300005127, 'L115A1 Cobra', 0, 3100, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10049401, 300005146, 'PGM-Hecate2 G.', 0, 460, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10049402, 300005146, 'PGM-Hecate2 G.', 0, 2760, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10049403, 300005146, 'PGM-Hecate2 G.', 0, 4600, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10047702, 300005127, 'L115A1 Cobra', 0, 1860, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10049701, 300005149, 'Cheytac M200 Serpent', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049702, 300005149, 'Cheytac M200 Serpent', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049703, 300005149, 'Cheytac M200 Serpent', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049801, 300005150, 'Cheytac M200 GRS3', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049802, 300005150, 'Cheytac M200 GRS3', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049803, 300005150, 'Cheytac M200 GRS3', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049901, 300005151, 'Cheytac M200 Beast', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049902, 300005151, 'Cheytac M200 Beast', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10049903, 300005151, 'Cheytac M200 Beast', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050101, 300005153, 'Cheytac M200 GSL2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050102, 300005153, 'Cheytac M200 GSL2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050103, 300005153, 'Cheytac M200 GSL2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050201, 300005154, 'Tactilite T2 GSL2016		', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050202, 300005154, 'Tactilite T2 GSL2016', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050203, 300005154, 'Tactilite T2 GSL2016', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050401, 300005156, 'Cheytac M200 Tiger-Deluxe', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050402, 300005156, 'Cheytac M200 Tiger-Deluxe', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050403, 300005156, 'Cheytac M200 Tiger-Deluxe', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050501, 300005158, 'Cheytac M200 Midnight2', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050502, 300005158, 'Cheytac M200 Midnight2', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050503, 300005158, 'Cheytac M200 Midnight2', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050701, 300005160, 'Cheytac M200 Skeleton', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050702, 300005160, 'Cheytac M200 Skeleton', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050703, 300005160, 'Cheytac M200 Skeleton', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050901, 300005162, 'Tactilite T2 Dragon', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050902, 300005162, 'Tactilite T2 Dragon', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050903, 300005162, 'Tactilite T2 Dragon', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051001, 300005163, 'Tactilite T2 PBWC2016', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051002, 300005163, 'Tactilite T2 PBWC2016', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051003, 300005163, 'Tactilite T2 PBWC2016', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051101, 300005164, 'AS 50 D.', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051102, 300005164, 'AS 50 D.', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051103, 300005164, 'AS 50 D.', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051201, 300005165, 'Cheytac M200 ID 1stAnni', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051202, 300005165, 'Cheytac M200 ID 1stAnni', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051203, 300005165, 'Cheytac M200 ID 1stAnni', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051301, 300005166, 'Cheytac M200 Strike', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051302, 300005166, 'Cheytac M200 Strike', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051303, 300005166, 'Cheytac M200 Strike', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051401, 300005167, 'Cheytac M200 Demonic', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051402, 300005167, 'Cheytac M200 Demonic', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051403, 300005167, 'Cheytac M200 Demonic', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048902, 300005140, 'Cheytac M200 Monkey', 0, 2580, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10051501, 300005168, 'Cheytac M200 Dolphin', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051502, 300005168, 'Cheytac M200 Dolphin', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051503, 300005168, 'Cheytac M200 Dolphin', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051601, 300005169, 'L115A1 Dolphin', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051602, 300005169, 'L115A1 Dolphin', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051603, 300005169, 'L115A1 Dolphin', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051701, 300005170, 'Cheytac M200 Blue Diamond', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051702, 300005170, 'Cheytac M200 Blue Diamond', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051703, 300005170, 'Cheytac M200 Blue Diamond', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051801, 300005171, 'Tactilite T2 Blue Diamond', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051802, 300005171, 'Tactilite T2 Blue Diamond', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051803, 300005171, 'Tactilite T2 Blue Diamond', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051901, 300005172, 'Cheytac M200 Lebaran2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051902, 300005172, 'Cheytac M200 Lebaran2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10051903, 300005172, 'Cheytac M200 Lebaran2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050303, 300005155, 'Cheytac M200 Tiger-Normal', 60000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10050302, 300005155, 'Cheytac M200 Tiger-Normal', 30000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10049002, 300005141, 'Cheytac M200 Arena Normal', 30000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10050301, 300005155, 'Cheytac M200 Tiger-Normal', 15000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10052201, 300005175, 'Cheytac M200 Woody', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052202, 300005175, 'Cheytac M200 Woody', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052203, 300005175, 'Cheytac M200 Woody', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052301, 300005176, 'Tactilite T2 Newborn2016', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050602, 300005159, 'AS 50 G.', 0, 1800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10050603, 300005159, 'AS 50 G.', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10052302, 300005176, 'Tactilite T2 Newborn2016', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052303, 300005176, 'Tactilite T2 Newborn2016', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052401, 300005177, 'Tactilite T2 Puzzle', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052402, 300005177, 'Tactilite T2 Puzzle', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052403, 300005177, 'Tactilite T2 Puzzle', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052601, 300005179, 'Dragunov Russian Deluxe', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052602, 300005179, 'Dragunov Russian Deluxe', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10049202, 300005143, 'Cheytac M200 Vera Cruz 2016', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10049203, 300005143, 'Cheytac M200 Vera Cruz 2016', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052603, 300005179, 'Dragunov Russian Deluxe', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052701, 300005180, 'Tactilite T2 Liberty', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052702, 300005180, 'Tactilite T2 Liberty', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052703, 300005180, 'Tactilite T2 Liberty', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052801, 300005181, 'Cheytac M200 PBIC2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050001, 300005152, 'Cheytac M200 PBGC', 0, 430, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052802, 300005181, 'Cheytac M200 PBIC2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052803, 300005181, 'Cheytac M200 PBIC2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052901, 300005182, 'Tactilite T2 PBIC2016', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052902, 300005182, 'Tactilite T2 PBIC2016', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052903, 300005182, 'Tactilite T2 PBIC2016', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053001, 300005183, 'Cheytac M200 PBTC2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053002, 300005183, 'Cheytac M200 PBTC2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053003, 300005183, 'Cheytac M200 PBTC2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053101, 300005184, 'AS-50 PBTC2016', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053102, 300005184, 'AS-50 PBTC2016', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053103, 300005184, 'AS-50 PBTC2016', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053201, 300005185, 'Cheytac M200 Dark Steel', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053202, 300005185, 'Cheytac M200 Dark Steel', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053203, 300005185, 'Cheytac M200 Dark Steel', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053301, 300005186, 'Cheytac M200 PBNC2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053302, 300005186, 'Cheytac M200 PBNC2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053303, 300005186, 'Cheytac M200 PBNC2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053401, 300005187, 'Cheytac M200 PBST2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053402, 300005187, 'Cheytac M200 PBST2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053403, 300005187, 'Cheytac M200 PBST2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053601, 300005189, 'Cheytac M200 Halloween 2016', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053602, 300005189, 'Cheytac M200 Halloween 2016', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053603, 300005189, 'Cheytac M200 Halloween 2016', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053701, 300005190, 'Cheytac M200 Azerbaijan', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053703, 300005190, 'Cheytac M200 Azerbaijan', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053801, 300005086, 'Dragunov W.O.E', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053802, 300005086, 'Dragunov W.O.E', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053803, 300005086, 'Dragunov W.O.E', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053901, 300005087, 'Cheytac M200 PBIC2014', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053902, 300005087, 'Cheytac M200 PBIC2014', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10053903, 300005087, 'Cheytac M200 PBIC2014', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054001, 300005090, 'Cheytac M200 Merdeka (Tiger)', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054002, 300005090, 'Cheytac M200 Merdeka (Tiger)', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054003, 300005090, 'Cheytac M200 Merdeka (Tiger)', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054101, 300005091, 'Cheytac M200 G E-Sport', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054102, 300005091, 'Cheytac M200 G E-Sport', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054103, 300005091, 'Cheytac M200 G E-Sport', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054201, 300005092, 'L115A1 Toy', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054202, 300005092, 'L115A1 Toy', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054203, 300005092, 'L115A1 Toy', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054301, 300005093, 'VSK94 Gold', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052502, 300005178, 'Dragunov Russian Normal', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052503, 300005178, 'Dragunov Russian Normal', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10053503, 300005188, 'Cheytac M200 SUPREME', 0, 4300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10054302, 300005093, 'VSK94 Gold', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10050803, 300005161, 'Tactilite T2 E-Sports2', 0, 4500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10050801, 300005161, 'Tactilite T2 E-Sports2', 0, 450, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10054303, 300005093, 'VSK94 Gold', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054401, 300005094, 'SVU Gold', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054402, 300005094, 'SVU Gold', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054403, 300005094, 'SVU Gold', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054501, 300005095, 'DSR-1 Gold', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054502, 300005095, 'DSR-1 Gold', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054503, 300005095, 'DSR-1 Gold', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054601, 300005096, 'Cheytac M200 LATIN4', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054602, 300005096, 'Cheytac M200 LATIN4', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054603, 300005096, 'Cheytac M200 LATIN4', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054801, 300005098, 'DSR-1 D.', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054802, 300005098, 'DSR-1 D.', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054803, 300005098, 'DSR-1 D.', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054901, 300005099, 'Cheytac M200 CoupleBreaker', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054902, 300005099, 'Cheytac M200 CoupleBreaker', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054903, 300005099, 'Cheytac M200 CoupleBreaker', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055001, 300005100, 'Cheytac M200 GRS2', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002701, 803007006, 'C-5 D', 0, 100, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10055002, 300005100, 'Cheytac M200 GRS2', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055003, 300005100, 'Cheytac M200 GRS2', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10052101, 300005174, 'L115A1 Alien', 0, 310, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052102, 300005174, 'L115A1 Alien', 0, 1860, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052103, 300005174, 'L115A1 Alien', 0, 3100, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052002, 300005173, 'Cheytac M200 Alien', 0, 2580, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10055101, 300005101, 'L115A1 Newborn 2015', 0, 310, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055102, 300005101, 'L115A1 Newborn 2015', 0, 1860, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055103, 300005101, 'L115A1 Newborn 2015', 0, 3100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055201, 300005102, 'Cheytac M200 GSL2015', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055202, 300005102, 'Cheytac M200 GSL2015', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055203, 300005102, 'Cheytac M200 GSL2015', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055301, 300005104, 'Cheytac M200 Ongame', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055302, 300005104, 'Cheytac M200 Ongame', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055303, 300005104, 'Cheytac M200 Ongame', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055401, 300005105, 'Cheytac M200 Redemption', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055402, 300005105, 'Cheytac M200 Redemption', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055403, 300005105, 'Cheytac M200 Redemption', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055901, 400006004, '870MCS W.', 5000, 0, 100, 1, 1, 2, 0, 35, 0);
INSERT INTO "public"."shop" VALUES (10054703, 300005097, 'Cheytac M200 Cangaceiro', 0, 4300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10054701, 300005097, 'Cheytac M200 Cangaceiro', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10055902, 400006004, '870MCS W.', 20000, 0, 500, 1, 1, 2, 0, 35, 0);
INSERT INTO "public"."shop" VALUES (10056101, 400006005, 'M1887  ', 16000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10056102, 400006005, 'M1887  ', 64000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10056301, 400006047, 'Cerberus', 20000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056302, 400006047, 'Cerberus', 80000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056401, 400006003, 'SPAS-15', 16000, 0, 100, 1, 1, 2, 0, 37, 0);
INSERT INTO "public"."shop" VALUES (10056402, 400006003, 'SPAS-15', 64000, 0, 500, 1, 1, 2, 0, 37, 0);
INSERT INTO "public"."shop" VALUES (10056501, 400006017, 'M1887 D ', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056502, 400006017, 'M1887 D ', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056503, 400006017, 'M1887 D ', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056601, 400006018, 'SPAS-15 MSC ', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056602, 400006018, 'SPAS-15 MSC ', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056002, 400006043, 'Remington ETA', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10056603, 400006018, 'SPAS-15 MSC ', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056801, 400006021, 'M1887 SL', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056802, 400006021, 'M1887 SL', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056803, 400006021, 'M1887 SL', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056901, 400006026, 'M1887 W GRS', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056701, 400006019, 'JackHammer ', 5000, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056702, 400006019, 'JackHammer ', 30000, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055802, 400006020, 'Kel-Tec KSG-15', 64000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056902, 400006026, 'M1887 W GRS', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056903, 400006026, 'M1887 W GRS', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057101, 400006032, 'SPAS-15 Elite', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057102, 400006032, 'SPAS-15 Elite', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057103, 400006032, 'SPAS-15 Elite', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057201, 400006033, 'M1887 W TH 1st Anniversary', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057202, 400006033, 'M1887 W TH 1st Anniversary', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057203, 400006033, 'M1887 W TH 1st Anniversary', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057301, 400006034, 'M1887 R', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057302, 400006034, 'M1887 R', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057303, 400006034, 'M1887 R', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057401, 400006035, 'M1887 PBNC5', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057402, 400006035, 'M1887 PBNC5', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057403, 400006035, 'M1887 PBNC5', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057501, 400006036, 'Kel-Tec KSG 15 GSL2014', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057502, 400006036, 'Kel-Tec KSG 15 GSL2014', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057503, 400006036, 'Kel-Tec KSG 15 GSL2014', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055702, 300005108, 'Cheytac M200 Lionflame', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055703, 300005108, 'Cheytac M200 Lionflame', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055602, 300005107, 'Dragunov Rose', 0, 1000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055603, 300005107, 'Dragunov Rose', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055601, 300005107, 'Dragunov Rose', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057701, 400006038, 'M1887 PBIC2014', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057702, 400006038, 'M1887 PBIC2014', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057703, 400006038, 'M1887 PBIC2014', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057801, 400006040, 'SPAS-15 NonLogo PBSC2013', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057802, 400006040, 'SPAS-15 NonLogo PBSC2013', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057803, 400006040, 'SPAS-15 NonLogo PBSC2013', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057901, 400006041, 'M1887 Lion-Heart', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057902, 400006041, 'M1887 Lion-Heart', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057903, 400006041, 'M1887 Lion-Heart', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058101, 400006044, 'Remington ETA G.', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058102, 400006044, 'Remington ETA G.', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058103, 400006044, 'Remington ETA G.', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058201, 400006046, 'UTS-15 D', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058202, 400006046, 'UTS-15 D', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058203, 400006046, 'UTS-15 D', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058301, 400006048, 'UTS-15 G.', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058302, 400006048, 'UTS-15 G.', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058303, 400006048, 'UTS-15 G.', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058401, 400006049, 'M1887 GSL2015', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058402, 400006049, 'M1887 GSL2015', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056201, 400006039, 'UTS-15', 9000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10056202, 400006039, 'UTS-15', 36000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10058403, 400006049, 'M1887 GSL2015', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057601, 400006037, 'M1887 Brazuca', 0, 550, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10057602, 400006037, 'M1887 Brazuca', 0, 3300, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10057603, 400006037, 'M1887 Brazuca', 0, 5500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10058503, 400006051, 'WaterGun', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058701, 400006053, 'M1887 PBNC2015', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058702, 400006053, 'M1887 PBNC2015', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058703, 400006053, 'M1887 PBNC2015', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058801, 400006054, 'SPAS-15 PBNC2015', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058802, 400006054, 'SPAS-15 PBNC2015', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058803, 400006054, 'SPAS-15 PBNC2015', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002702, 803007006, 'C-5 D', 0, 400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10058901, 400006055, 'M1887 PBTC2015', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058902, 400006055, 'M1887 PBTC2015', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058903, 400006055, 'M1887 PBTC2015', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059001, 400006056, 'M1887 Mech', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059002, 400006056, 'M1887 Mech', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10056703, 400006019, 'JackHammer ', 50000, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059003, 400006056, 'M1887 Mech', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059101, 400006057, 'SPAS-15 MSC PBNC2015 U.S.', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059102, 400006057, 'SPAS-15 MSC PBNC2015 U.S.', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059103, 400006057, 'SPAS-15 MSC PBNC2015 U.S.', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059201, 400006058, 'M1887 PBIC2015', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059202, 400006058, 'M1887 PBIC2015', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059203, 400006058, 'M1887 PBIC2015', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058002, 400006042, 'Zombie Slayer', 0, 2700, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10058003, 400006042, 'Zombie Slayer', 0, 4500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10058501, 400006051, 'WaterGun', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058502, 400006051, 'WaterGun', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059301, 400006059, 'M1887 Gold', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059302, 400006059, 'M1887 Gold', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059303, 400006059, 'M1887 Gold', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059401, 400006060, 'M1887 Medical', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10059402, 400006060, 'M1887 Medical', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059403, 400006060, 'M1887 Medical', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059501, 400006061, 'M1887 Steam', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059502, 400006061, 'M1887 Steam', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059503, 400006061, 'M1887 Steam', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059601, 400006062, 'M1887 Obsidian', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059602, 400006062, 'M1887 Obsidian', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059603, 400006062, 'M1887 Obsidian', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059701, 400006063, 'M1887 Arena Normal', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059702, 400006063, 'M1887 Arena Normal', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059703, 400006063, 'M1887 Arena Normal', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059801, 400006064, 'M1887 Arena Deluxe', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059802, 400006064, 'M1887 Arena Deluxe', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059803, 400006064, 'M1887 Arena Deluxe', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059901, 400006065, 'M1887 Cupid', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10059903, 400006065, 'M1887 Cupid', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060001, 400006066, 'M1887 GRS3', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060002, 400006066, 'M1887 GRS3', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060003, 400006066, 'M1887 GRS3', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060101, 400006067, 'M1887 Beast', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060102, 400006067, 'M1887 Beast', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060103, 400006067, 'M1887 Beast', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060301, 400006069, 'M1887 Skeleton', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060302, 400006069, 'M1887 Skeleton', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060303, 400006069, 'M1887 Skeleton', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060401, 400006070, 'M1887 Dragon', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060402, 400006070, 'M1887 Dragon', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060403, 400006070, 'M1887 Dragon', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060501, 400006071, 'M1887 ID 1stAnni', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060502, 400006071, 'M1887 ID 1stAnni', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060503, 400006071, 'M1887 ID 1stAnni', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060601, 400006072, 'M1887 Dolphin', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060602, 400006072, 'M1887 Dolphin', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060603, 400006072, 'M1887 Dolphin', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060701, 400006073, 'SPAS-15 Blue Diamond', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060702, 400006073, 'SPAS-15 Blue Diamond', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060703, 400006073, 'SPAS-15 Blue Diamond', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060801, 400006074, 'M1887 Lebaran2016', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060802, 400006074, 'M1887 Lebaran2016', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060803, 400006074, 'M1887 Lebaran2016', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060901, 400006075, 'M1887 Woody', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060902, 400006075, 'M1887 Woody', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060903, 400006075, 'M1887 Woody', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061001, 400006076, 'M1887 Newborn2016', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061002, 400006076, 'M1887 Newborn2016', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061003, 400006076, 'M1887 Newborn2016', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061101, 400006077, 'M1887 Liberty', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061102, 400006077, 'M1887 Liberty', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061103, 400006077, 'M1887 Liberty', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061201, 400006078, 'M1887 PBIC2016', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061202, 400006078, 'M1887 PBIC2016', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061203, 400006078, 'M1887 PBIC2016', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061301, 400006079, 'M1887 PBTC2016', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061302, 400006079, 'M1887 PBTC2016', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061303, 400006079, 'M1887 PBTC2016', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061401, 400006080, 'M1887 Dark Steel', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061402, 400006080, 'M1887 Dark Steel', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061403, 400006080, 'M1887 Dark Steel', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10058602, 400006052, 'M1887 Summer', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061501, 400006081, 'M1887 PBNC2016', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061502, 400006081, 'M1887 PBNC2016', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061503, 400006081, 'M1887 PBNC2016', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061701, 400006083, 'M1887 Gorgeous', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061702, 400006083, 'M1887 Gorgeous', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061703, 400006083, 'M1887 Gorgeous', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061801, 400006084, 'Cerberus Gorgeous', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061802, 400006084, 'Cerberus Gorgeous', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061803, 400006084, 'Cerberus Gorgeous', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061901, 400006006, 'SPAS-15 SL', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061902, 400006006, 'SPAS-15 SL', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061903, 400006006, 'SPAS-15 SL', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062001, 400006010, 'M1887 W. ', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062002, 400006010, 'M1887 W. ', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062003, 400006010, 'M1887 W. ', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062101, 400006011, '870MCS W. D ', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062102, 400006011, '870MCS W. D ', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10060202, 400006068, 'M1887 PBGC', 0, 3300, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10062103, 400006011, '870MCS W. D ', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062201, 400006012, 'SPAS-15 D ', 3200, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10062202, 400006012, 'SPAS-15 D ', 19200, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10062203, 400006012, 'SPAS-15 D ', 32000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10062301, 400006014, '870MCS SI D ', 0, 120, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062302, 400006014, '870MCS SI D ', 0, 720, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062303, 400006014, '870MCS SI D ', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062401, 400006015, '870MCS D ', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062402, 400006015, '870MCS D ', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062403, 400006015, '870MCS D ', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062501, 400006016, 'SPAS-15 SI D ', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062502, 400006016, 'SPAS-15 SI D ', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062503, 400006016, 'SPAS-15 SI D ', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062601, 500010004, 'L86 LSW', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062602, 500010004, 'L86 LSW', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062701, 500010011, 'Ultimax 100', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062702, 500010011, 'Ultimax 100', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062801, 500010001, 'Mk 46 Ext.', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062802, 500010001, 'Mk 46 Ext.', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062901, 500010002, 'Mk 46 Silver', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10062902, 500010002, 'Mk 46 Silver', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063001, 500010003, 'RPD', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063002, 500010003, 'RPD', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063101, 500010009, 'L86 LSW XMAS', 6000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063102, 500010009, 'L86 LSW XMAS', 24000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063201, 500010012, 'Ultimax 100 G.', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063202, 500010012, 'Ultimax 100 G.', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063203, 500010012, 'Ultimax 100 G.', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063301, 500010013, 'Ultimax 100 Madness', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063302, 500010013, 'Ultimax 100 Madness', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063303, 500010013, 'Ultimax 100 Madness', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063401, 500010014, 'Ultimax 100 Mummy', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063402, 500010014, 'Ultimax 100 Mummy', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063403, 500010014, 'Ultimax 100 Mummy', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10061603, 400006082, 'M1887 SUPREME', 0, 5500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065301, 100003394, 'AUG A3 HALLOWEEN2017', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065302, 100003394, 'AUG A3 HALLOWEEN2017', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065303, 100003394, 'AUG A3 HALLOWEEN2017', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065401, 100003395, 'SC 2010 HALLOWEEN2017', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065402, 100003395, 'SC 2010 HALLOWEEN2017', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065403, 100003395, 'SC 2010 HALLOWEEN2017', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065501, 200004498, 'OA93 HALLOWEEN2017', 0, 350, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065502, 200004498, 'OA93 HALLOWEEN2017', 0, 1400, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065503, 200004498, 'OA93 HALLOWEEN2017', 0, 3500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065601, 200004500, 'P90 EXT HALLOWEEN2017', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065602, 200004500, 'P90 EXT HALLOWEEN2017', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065603, 200004500, 'P90 EXT HALLOWEEN2017', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065701, 300005256, 'CHEYTAC M200 HALLOWEEN2017', 0, 280, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065702, 300005256, 'CHEYTAC M200 HALLOWEEN2017', 0, 1120, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065703, 300005256, 'CHEYTAC M200 HALLOWEEN2017', 0, 2800, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065801, 100003431, 'AUG HBAR PANDORA', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065802, 100003431, 'AUG HBAR PANDORA', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065803, 100003431, 'AUG HBAR PANDORA', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065902, 100003451, 'AUG  A3 M1LGR4U', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20000302, 601002005, 'D-Eagle Silver', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000402, 601013001, 'P99&HAK', 32000, 0, 500, 1, 1, 2, 0, 30, 0);
INSERT INTO "public"."shop" VALUES (10063502, 100003454, 'ASSAULT_AUG_A3_PBWC2018', 0, 1200, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063503, 100003454, 'ASSAULT_AUG_A3_PBWC2018', 0, 3000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063601, 100003455, 'ASSAULT_SC_2010_PBWC2018', 0, 300, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064901, 200004522, 'OA93 FIREDRAGON', 0, 350, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064902, 200004522, 'OA93 FIREDRAGON', 0, 1400, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064903, 200004522, 'OA93 FIREDRAGON', 0, 3500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065001, 300005261, 'TACTILITE T2 FIREDRAGON', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065002, 300005261, 'TACTILITE T2 FIREDRAGON', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065003, 300005261, 'TACTILITE T2 FIREDRAGON', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065101, 400006120, 'CERBERUS FIREDRAGON', 0, 350, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065102, 400006120, 'CERBERUS FIREDRAGON', 0, 1400, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065103, 400006120, 'CERBERUS FIREDRAGON', 0, 3500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065201, 100003399, 'AUG A3 FIREDRAGON', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064802, 200004521, 'P90 EXT FIREDRAGON', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064803, 200004521, 'P90 EXT FIREDRAGON', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10063602, 100003455, 'ASSAULT_SC_2010_PBWC2018', 0, 1200, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063603, 100003455, 'ASSAULT_SC_2010_PBWC2018', 0, 3000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063701, 200004607, 'SMG_OA_93_PBWC2018', 0, 300, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063702, 200004607, 'SMG_OA_93_PBWC2018', 0, 1200, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063703, 200004607, 'SMG_OA_93_PBWC2018', 0, 3000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063801, 200004609, 'SMG_KRISSSUPERV_PBWC2018', 0, 300, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063803, 200004609, 'SMG_KRISSSUPERV_PBWC2018', 0, 3000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063901, 300005304, 'SNIPER_CHEYTAC_M200_PBWC2018', 0, 450, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063903, 300005304, 'SNIPER_CHEYTAC_M200_PBWC2018', 0, 1800, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063904, 300005304, 'SNIPER_CHEYTAC_M200_PBWC2018', 0, 4500, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064001, 300005305, 'SNIPER_TACTILITE_T2_PBWC2018', 0, 450, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064002, 300005305, 'SNIPER_TACTILITE_T2_PBWC2018', 0, 1800, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064003, 300005305, 'SNIPER_TACTILITE_T2_PBWC2018', 0, 4500, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064101, 400006146, 'SHOTGUN M1887 PBWC2018', 0, 350, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064103, 400006146, 'SHOTGUN M1887 PBWC2018', 0, 3500, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10064102, 400006146, 'ASSAULT_SC_2010_PBWC2018', 0, 1400, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000501, 601013007, 'P99&HAK Reload', 9000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000701, 601014001, 'Dual Handgun', 9000, 0, 100, 1, 1, 2, 0, 32, 0);
INSERT INTO "public"."shop" VALUES (20000702, 601014001, 'Dual Handgun', 36000, 0, 500, 1, 1, 2, 0, 32, 0);
INSERT INTO "public"."shop" VALUES (20000901, 601002007, 'C. Python', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000902, 601002007, 'C. Python', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001001, 601014006, 'Dual D-Eagle D', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001002, 601014006, 'Dual D-Eagle D', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001101, 601014007, 'Dual HK45', 16000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001102, 601014007, 'Dual HK45', 64000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001301, 601002011, 'Glock 18', 15000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10064203, 100003449, 'AUG A3 DIGITAL', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064301, 100003450, 'AK 47 DIGITAL', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064302, 100003450, 'AK 47 DIGITAL', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064303, 100003450, 'AK 47 DIGITAL', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064401, 200004598, 'KRISSSUPERV DIGITAL', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064402, 200004598, 'KRISSSUPERV DIGITAL', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064501, 300005300, 'CHEYTAC M200 DIGITAL', 0, 380, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064503, 300005300, 'CHEYTAC M200 DIGITAL', 0, 3800, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064601, 400006144, 'M1887 DIGITAL', 0, 280, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064602, 400006144, 'M1887 DIGITAL', 0, 1120, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064603, 400006144, 'M1887 DIGITAL', 0, 2800, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20001302, 601002011, 'Glock 18', 60000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000602, 601002017, 'C. Python G', 64000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000601, 601002017, 'C. Python G', 16000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001401, 601002002, 'MK 23 Ext.', 9000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001402, 601002002, 'MK 23 Ext.', 36000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001501, 601002094, 'U22 Neos', 15000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001502, 601002094, 'U22 Neos', 60000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001601, 601002022, 'Colt 45', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001602, 601002022, 'Colt 45', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001901, 601002024, 'Kriss Vector SDP', 18000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001902, 601002024, 'Kriss Vector SDP', 72000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002001, 601002001, 'Desert Eagle', 9000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20002002, 601002001, 'Desert Eagle', 36000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20002101, 601002057, 'D-Eagle Ongame', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002102, 601002057, 'D-Eagle Ongame', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002103, 601002057, 'D-Eagle Ongame', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002401, 601002060, 'C. Python Brazil', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002402, 601002060, 'C. Python Brazil', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002403, 601002060, 'C. Python Brazil', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002501, 601002061, 'Glock 18 PBST2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002502, 601002061, 'Glock 18 PBST2015', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002503, 601002061, 'Glock 18 PBST2015', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002601, 601002062, 'Glock 18 4Game', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002602, 601002062, 'Glock 18 4Game', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002603, 601002062, 'Glock 18 4Game', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002701, 601002063, 'Glock 18 4Game SE', 0, 260, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002702, 601002063, 'Glock 18 4Game SE', 0, 1560, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002703, 601002063, 'Glock 18 4Game SE', 0, 2600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002801, 601002064, 'D-Eagle Lebaran2015', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000102, 601002014, 'RB 454 SS5M', 52000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000201, 601002015, 'RB 454 SS8M', 15000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000202, 601002015, 'RB 454 SS8M', 60000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001701, 601014017, 'Scorpion Vz.61', 19000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001702, 601014017, 'Scorpion Vz.61', 76000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001801, 601002013, 'RB 454 SS2M', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001802, 601002013, 'RB 454 SS2M', 48000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20001201, 601014008, 'Dual Handgun', 13000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20001202, 601014008, 'Dual Handgun', 52000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20000801, 601014002, 'Dual D-Eagle', 8500, 0, 100, 1, 1, 2, 0, 32, 2);
INSERT INTO "public"."shop" VALUES (20000802, 601014002, 'Dual D-Eagle', 34000, 0, 500, 1, 1, 2, 0, 32, 2);
INSERT INTO "public"."shop" VALUES (20002802, 601002064, 'D-Eagle Lebaran2015', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002803, 601002064, 'D-Eagle Lebaran2015', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002901, 601002067, 'C. Python PBNC2015', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002902, 601002067, 'C. Python PBNC2015', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002903, 601002067, 'C. Python PBNC2015', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003001, 601002068, 'R.B Mech', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003002, 601002068, 'R.B Mech', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003003, 601002068, 'R.B Mech', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003101, 601002069, 'Kriss Vector SDP DarkDays', 0, 190, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10066003, 100003452, 'SC 2010 M1LGR4U', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066101, 200004600, 'KRISSSUPERV M1LGR4U', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066102, 200004600, 'KRISSSUPERV M1LGR4U', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066103, 200004600, 'KRISSSUPERV M1LGR4U', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066202, 200004601, 'KRISSSUPERV M1LGR4U DUMMY', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066203, 200004601, 'KRISSSUPERV M1LGR4U DUMMY', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066301, 200004602, 'P90 M1LGR4U', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066302, 200004602, 'P90 M1LGR4U', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066303, 200004602, 'P90 M1LGR4U', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066401, 300005301, 'TACTILITE T2 M1LGR4U', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066402, 300005301, 'TACTILITE T2 M1LGR4U', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066403, 300005301, 'TACTILITE T2 M1LGR4U', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066501, 300005302, 'CHEYTAC M200 M1LGR4U', 0, 450, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066502, 300005302, 'CHEYTAC M200 M1LGR4U', 0, 1800, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066503, 300005302, 'CHEYTAC M200 M1LGR4U', 0, 4500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066001, 100003452, 'SC 2010 M1LGR4U', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066002, 100003452, 'SC 2010 M1LGR4U', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20003102, 601002069, 'Kriss Vector SDP DarkDays', 0, 1140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003103, 601002069, 'Kriss Vector SDP DarkDays', 0, 1900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003301, 601002071, 'Glock 18 G.', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003302, 601002071, 'Glock 18 G.', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003303, 601002071, 'Glock 18 G.', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003601, 601002074, 'Kriss Vector SDP Camo Soldier', 0, 190, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003602, 601002074, 'Kriss Vector SDP Camo Soldier', 0, 1140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003603, 601002074, 'Kriss Vector SDP Camo Soldier', 0, 1900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003701, 601002075, 'MK.23 SPY', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003702, 601002075, 'MK.23 SPY', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003703, 601002075, 'MK.23 SPY', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003801, 601002076, 'C. Python Latin5', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003802, 601002076, 'C. Python Latin5', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003803, 601002076, 'C. Python Latin5', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003901, 601002077, 'MK.23 Spy-Deluxe', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003902, 601002077, 'MK.23 Spy-Deluxe', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003903, 601002077, 'MK.23 Spy-Deluxe', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004001, 601002079, 'C. Python Arena Normal', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004002, 601002079, 'C. Python Arena Normal', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004003, 601002079, 'C. Python Arena Normal', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002302, 601002059, 'C. Python Rose', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002303, 601002059, 'C. Python Rose', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000902, 1104003009, 'No alvo', 1, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004101, 601002080, 'C. Python Arena Deluxe', 0, 230, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004102, 601002080, 'C. Python Arena Deluxe', 0, 1380, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004103, 601002080, 'C. Python Arena Deluxe', 0, 2300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004301, 601002082, 'C. Python Sakura', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004303, 601002082, 'C. Python Sakura', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004401, 601002083, 'C. Python Beast', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004402, 601002083, 'C. Python Beast', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004403, 601002083, 'C. Python Beast', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004501, 601002084, 'C. Python GSL2016', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004502, 601002084, 'C. Python GSL2016', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004503, 601002084, 'C. Python GSL2016', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004601, 601002085, 'Desert Eagle Tiger-Normal', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004602, 601002085, 'Desert Eagle Tiger-Normal', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004603, 601002085, 'Desert Eagle Tiger-Normal', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004701, 601002086, 'Desert Eagle Tiger-Deluxe', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004702, 601002086, 'Desert Eagle Tiger-Deluxe', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004703, 601002086, 'Desert Eagle Tiger-Deluxe', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004801, 601002087, 'C. Python PBWC2016', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004802, 601002087, 'C. Python PBWC2016', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004803, 601002087, 'C. Python PBWC2016', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004901, 601002088, 'Glock 18 Mummy', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004902, 601002088, 'Glock 18 Mummy', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004903, 601002088, 'Glock 18 Mummy', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005001, 601002089, 'MK.23 Blue Diamond', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005002, 601002089, 'MK.23 Blue Diamond', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005003, 601002089, 'MK.23 Blue Diamond', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20002201, 601002058, 'C. Python Summer', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20005101, 601002028, 'M79', 0, 190, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005102, 601002028, 'M79', 0, 1140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005103, 601002028, 'M79', 0, 1900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005301, 601002092, 'C. Python Newborn2016', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005302, 601002092, 'C. Python Newborn2016', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005303, 601002092, 'C. Python Newborn2016', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005401, 601002093, 'Kriss Vector SDP Puzzle', 0, 190, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005402, 601002093, 'Kriss Vector SDP Puzzle', 0, 1140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005403, 601002093, 'Kriss Vector SDP Puzzle', 0, 1900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20004201, 601002081, 'R.B 454 SS8M+S Vera Cruz 2016', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20004202, 601002081, 'R.B 454 SS8M+S Vera Cruz 2016', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20004203, 601002081, 'R.B 454 SS8M+S Vera Cruz 2016', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20005501, 601002095, 'U22 Neos S.', 0, 280, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005502, 601002095, 'U22 Neos S.', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005503, 601002095, 'U22 Neos S.', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005601, 601002096, 'U22 Neos G.', 0, 280, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005602, 601002096, 'U22 Neos G.', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005603, 601002096, 'U22 Neos G.', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005701, 601002097, 'C. Python PBIC2016', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005702, 601002097, 'C. Python PBIC2016', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005703, 601002097, 'C. Python PBIC2016', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005801, 601002098, 'C. Python Dark Steel', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005802, 601002098, 'C. Python Dark Steel', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005803, 601002098, 'C. Python Dark Steel', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005901, 601002099, 'R.B 454 SS8M+S PBIC2016', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005902, 601002099, 'R.B 454 SS8M+S PBIC2016', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003503, 601002073, 'R.B 454 SS8M+S Cobra', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20003502, 601002073, 'R.B 454 SS8M+S Cobra', 0, 1800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30008002, 702015008, 'Kunai', 0, 2700, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20005903, 601002099, 'R.B 454 SS8M+S PBIC2016', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006201, 601014004, 'Dual D-Eagle G.', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006202, 601014004, 'Dual D-Eagle G.', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006203, 601014004, 'Dual D-Eagle G.', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006301, 601014011, 'Dual D-Eagle GRS', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006302, 601014011, 'Dual D-Eagle GRS', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006303, 601014011, 'Dual D-Eagle GRS', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006401, 601014012, 'Dual HK45 Halloween', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006402, 601014012, 'Dual HK45 Halloween', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006403, 601014012, 'Dual HK45 Halloween', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006501, 601014015, 'Dual D-Eagle BR Camo', 0, 180, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20006502, 601014015, 'Dual D-Eagle BR Camo', 0, 1080, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20006503, 601014015, 'Dual D-Eagle BR Camo', 0, 1800, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20006601, 601014016, 'Dual D-Eagle G E-Sport', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006602, 601014016, 'Dual D-Eagle G E-Sport', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006603, 601014016, 'Dual D-Eagle G E-Sport', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006801, 601014019, 'Dual D-Eagle Lebaran2016', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006802, 601014019, 'Dual D-Eagle Lebaran2016', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006803, 601014019, 'Dual D-Eagle Lebaran2016', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006901, 601014020, 'Scorpion Vz.61 Woody', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006003, 601002100, 'C. Python SUPREME', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20006902, 601014020, 'Scorpion Vz.61 Woody', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006903, 601014020, 'Scorpion Vz.61 Woody', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007301, 601002019, 'Mk 23 Ext. D', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007302, 601002019, 'Mk 23 Ext. D', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007303, 601002019, 'Mk 23 Ext. D', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007401, 601002021, 'Glock 18 D', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007402, 601002021, 'Glock 18 D', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007403, 601002021, 'Glock 18 D', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007601, 601002026, 'HK69', 0, 190, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007602, 601002026, 'HK69', 0, 1140, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007603, 601002026, 'HK69', 0, 1900, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007701, 601002027, 'MK23 SI', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007702, 601002027, 'MK23 SI', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007703, 601002027, 'MK23 SI', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007801, 601002029, 'GL-06', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007901, 601002034, 'R.B 454 SS8M+S PBSC2013', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007902, 601002034, 'R.B 454 SS8M+S PBSC2013', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007903, 601002034, 'R.B 454 SS8M+S PBSC2013', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008001, 601002035, 'MK.23 Reload', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008002, 601002035, 'MK.23 Reload', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008003, 601002035, 'MK.23 Reload', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008101, 601002036, 'Desert Eagle Reload', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008102, 601002036, 'Desert Eagle Reload', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008103, 601002036, 'Desert Eagle Reload', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000101, 803007004, 'C-5', 3500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008201, 601002039, 'Glock 18 Azerbaijan', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008202, 601002039, 'Glock 18 Azerbaijan', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20005203, 601002091, 'MK.23 Alien', 0, 1000, 2592000, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20007102, 601002016, 'RB 454 SS8M+S', 0, 1800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007103, 601002016, 'RB 454 SS8M+S', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20003202, 601002070, 'R.B 454 SS8M+S PBIC2015', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007101, 601002016, 'RB 454 SS8M+S', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20003203, 601002070, 'R.B 454 SS8M+S PBIC2015', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008203, 601002039, 'Glock 18 Azerbaijan', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008301, 601002040, 'C. Python PBNC5', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008302, 601002040, 'C. Python PBNC5', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008303, 601002040, 'C. Python PBNC5', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008401, 601002047, 'Glock 18 BR Camo', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008402, 601002047, 'Glock 18 BR Camo', 0, 1500, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008403, 601002047, 'Glock 18 BR Camo', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008601, 601002050, 'R.B 454 SS8M NonLogo PBSC2013', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006103, 601013008, 'C. Python Cutlass', 0, 2000, 2592000, 2, 1, 2, 0, 1, 0);
INSERT INTO "public"."shop" VALUES (20006102, 601013008, 'C. Python Cutlass', 0, 1200, 604800, 2, 1, 2, 0, 1, 0);
INSERT INTO "public"."shop" VALUES (20008602, 601002050, 'R.B 454 SS8M NonLogo PBSC2013', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008603, 601002050, 'R.B 454 SS8M NonLogo PBSC2013', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008701, 601002052, 'C. Python Toy', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008702, 601002052, 'C. Python Toy', 0, 1200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008703, 601002052, 'C. Python Toy', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008801, 601002054, 'GL-06 ANC 2015', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008802, 601002054, 'GL-06 ANC 2015', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008803, 601002054, 'GL-06 ANC 2015', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20009101, 601034003, 'BOW GOLD', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009102, 601034003, 'BOW GOLD', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009103, 601034003, 'BOW GOLD', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009201, 601034005, 'BOW BLACK', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009202, 601034005, 'BOW BLACK', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20008902, 601002148, 'COLTPYTHON PBWC2018', 0, 800, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008903, 601002148, 'COLTPYTHON PBWC2018', 0, 2000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20009203, 601034005, 'BOW BLACK', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30000201, 702001007, 'Mini Axe', 8600, 0, 100, 1, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (30000202, 702001007, 'Mini Axe', 34400, 0, 500, 1, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (30000301, 702001024, 'Alcaçuz', 3000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20006703, 601014018, 'Scorpion Vz.61 G.', 0, 4000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30000302, 702001024, 'Alcaçuz', 12000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000401, 702001017, 'Fang Blade', 16000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30000402, 702001017, 'Fang Blade', 64000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30000501, 702015001, 'Dual Knife ', 3000, 0, 100, 1, 1, 2, 0, 26, 0);
INSERT INTO "public"."shop" VALUES (30000502, 702015001, 'Dual Knife ', 12000, 0, 500, 1, 1, 2, 0, 26, 0);
INSERT INTO "public"."shop" VALUES (30000601, 702015003, 'Faca de Osso', 7860, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30000602, 702015003, 'Faca de Osso', 31440, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30000701, 702001004, 'Amok Kukri', 9000, 0, 100, 1, 1, 2, 0, 28, 0);
INSERT INTO "public"."shop" VALUES (30000702, 702001004, 'Amok Kukri', 36000, 0, 500, 1, 1, 2, 0, 28, 0);
INSERT INTO "public"."shop" VALUES (30000901, 702001012, 'Mini Axe D', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000902, 702001012, 'Mini Axe D', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000903, 702001012, 'Mini Axe D', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001001, 702001014, 'Machete de Combate', 2500, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007201, 601002018, 'C. Python G D', 2000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007202, 601002018, 'C. Python G D', 12000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007002, 601002012, 'C. Python D', 12000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20007203, 601002018, 'C. Python G D', 20000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007001, 601002012, 'C. Python D', 2000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001002, 702001014, 'Machete de Combate', 15000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001003, 702001014, 'Machete de Combate', 25000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001101, 702001018, 'Ballistic Knife', 0, 280, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001102, 702001018, 'Ballistic Knife', 0, 1120, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001103, 702001018, 'Ballistic Knife', 0, 2800, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001201, 702001023, 'Keris S.', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001202, 702001023, 'Keris S.', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001203, 702001023, 'Keris S.', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001401, 702001041, 'Espada Árabe', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001402, 702001041, 'Espada Árabe', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001403, 702001041, 'Espada Árabe', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001501, 702001043, 'Machete de Combate Gold', 2800, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001502, 702001043, 'Machete de Combate Gold', 16800, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001503, 702001043, 'Machete de Combate Gold', 28000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30001601, 702001044, 'Machete de Combate PBSC2013', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001602, 702001044, 'Machete de Combate PBSC2013', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001603, 702001044, 'Machete de Combate PBSC2013', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001703, 702001046, 'Amok Kukri Turkey', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001801, 702001047, 'Keris XMAS', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001802, 702001047, 'Keris XMAS', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001803, 702001047, 'Keris XMAS', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001901, 702001049, 'Espada Árabe E-Sport', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001902, 702001049, 'Espada Árabe E-Sport', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001903, 702001049, 'Espada Árabe E-Sport', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002001, 702001050, 'Fang Blade PBNC5', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002002, 702001050, 'Fang Blade PBNC5', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002003, 702001050, 'Fang Blade PBNC5', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002101, 702001051, 'Fang Blade GSL2014', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002102, 702001051, 'Fang Blade GSL2014', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002103, 702001051, 'Fang Blade GSL2014', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008502, 601002049, 'C. Python Brazuca', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008503, 601002049, 'C. Python Brazuca', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30002201, 702001052, 'Fang Blade Brazuca', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30002202, 702001052, 'Fang Blade Brazuca', 0, 1800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30002301, 702001057, 'Fang Blade Inferno', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002302, 702001057, 'Fang Blade Inferno', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002303, 702001057, 'Fang Blade Inferno', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002401, 702001058, 'Chinese Cleaver', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002402, 702001058, 'Chinese Cleaver', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002403, 702001058, 'Chinese Cleaver', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002501, 702001059, 'Machete de Combate White', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002502, 702001059, 'Machete de Combate White', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002503, 702001059, 'Machete de Combate White', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002701, 702001065, 'Keris G E-Sport', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002702, 702001065, 'Keris G E-Sport', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002703, 702001065, 'Keris G E-Sport', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002801, 702001066, 'Death Scythe', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002802, 702001066, 'Death Scythe', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002803, 702001066, 'Death Scythe', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002901, 702001067, 'Fang Blade LATIN4', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002902, 702001067, 'Fang Blade LATIN4', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002903, 702001067, 'Fang Blade LATIN4', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003001, 702001069, 'Ice Fork', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30001701, 702001046, 'Amok Kukri Turkey', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20009003, 601002134, 'COLTPYTHON FIREDRAGON', 0, 2000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30003002, 702001069, 'Ice Fork', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003003, 702001069, 'Ice Fork', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003201, 702001071, 'Goat Hammer', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003202, 702001071, 'Goat Hammer', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003203, 702001071, 'Goat Hammer', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003301, 702001073, 'Cutelo ANC 2015', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003302, 702001073, 'Cutelo ANC 2015', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003303, 702001073, 'Cutelo ANC 2015', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003401, 702001077, 'Fang Blade Newborn 2015', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003402, 702001077, 'Fang Blade Newborn 2015', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003403, 702001077, 'Fang Blade Newborn 2015', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003501, 702001079, 'Fang Blade Ongame', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003502, 702001079, 'Fang Blade Ongame', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003503, 702001079, 'Fang Blade Ongame', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003701, 702001082, 'Espada Árabe Midnight', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003702, 702001082, 'Espada Árabe Midnight', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003703, 702001082, 'Espada Árabe Midnight', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004001, 702001093, 'Machete de Combate Brazil', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004002, 702001093, 'Machete de Combate Brazil', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004003, 702001093, 'Machete de Combate Brazil', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003602, 702001080, 'Field Shovel Royal', 0, 1260, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30003603, 702001080, 'Field Shovel Royal', 0, 2100, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30001301, 702001025, 'Field Shovel', 0, 210, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (30001302, 702001025, 'Field Shovel', 0, 1260, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (30001303, 702001025, 'Field Shovel', 0, 2100, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (30004101, 702001094, 'Fang Blade PBST2015', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004102, 702001094, 'Fang Blade PBST2015', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004103, 702001094, 'Fang Blade PBST2015', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004201, 702001095, 'Machete de Combate 4Game', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004202, 702001095, 'Machete de Combate 4Game', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004203, 702001095, 'Machete de Combate 4Game', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004301, 702001096, 'Machete de Combate 4Game SE', 0, 280, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004302, 702001096, 'Machete de Combate 4Game SE', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004303, 702001096, 'Machete de Combate 4Game SE', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004401, 702001097, 'Hair Dryer Indonesia', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004402, 702001097, 'Hair Dryer Indonesia', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004403, 702001097, 'Hair Dryer Indonesia', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004501, 702001098, 'Hair Dryer', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004502, 702001098, 'Hair Dryer', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004503, 702001098, 'Hair Dryer', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004601, 702001101, 'Fang Blade PBNC2015', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004602, 702001101, 'Fang Blade PBNC2015', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004603, 702001101, 'Fang Blade PBNC2015', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004801, 702001104, 'Keris PBIC2015', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004802, 702001104, 'Keris PBIC2015', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004803, 702001104, 'Keris PBIC2015', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005101, 702001110, 'Ballistic Knife Spy', 0, 280, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005102, 702001110, 'Ballistic Knife Spy', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005103, 702001110, 'Ballistic Knife Spy', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005201, 702001113, 'Fang Blade Latin5', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005202, 702001113, 'Fang Blade Latin5', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005203, 702001113, 'Fang Blade Latin5', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005301, 702001114, 'Ballistic Knife Spy-Deluxe', 0, 280, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30000102, 702023002, 'Black Knuckles ', 10000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30005302, 702001114, 'Ballistic Knife Spy-Deluxe', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005303, 702001114, 'Ballistic Knife Spy-Deluxe', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005401, 702001119, 'Machete de Combate DFN', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005402, 702001119, 'Machete de Combate DFN', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005403, 702001119, 'Machete de Combate DFN', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005601, 702001131, 'Fang Blade GSL2016', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005602, 702001131, 'Fang Blade GSL2016', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005603, 702001131, 'Fang Blade GSL2016', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005701, 702001132, 'Fang Blade Tiger-Normal', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005702, 702001132, 'Fang Blade Tiger-Normal', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005703, 702001132, 'Fang Blade Tiger-Normal', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005801, 702001133, 'Fang Blade Tiger-Deluxe', 0, 320, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005802, 702001133, 'Fang Blade Tiger-Deluxe', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005803, 702001133, 'Fang Blade Tiger-Deluxe', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005901, 702001136, 'Fang Blade Dragon', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005902, 702001136, 'Fang Blade Dragon', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005903, 702001136, 'Fang Blade Dragon', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006001, 702001137, 'Amok Kukri PBWC2016', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006002, 702001137, 'Amok Kukri PBWC2016', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006003, 702001137, 'Amok Kukri PBWC2016', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005002, 702001108, 'Fang Blade Cobra', 0, 1800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30005003, 702001108, 'Fang Blade Cobra', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30003103, 702001070, 'Machete de Combate Cangaceiro', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30003101, 702001070, 'Machete de Combate Cangaceiro', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30006101, 702001138, 'Machete de Combate PBWC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006102, 702001138, 'Machete de Combate PBWC2016', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006103, 702001138, 'Machete de Combate PBWC2016', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30002603, 702001064, 'Badminton Racket', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30006201, 702001139, 'Amok Kukri Mummy', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006202, 702001139, 'Amok Kukri Mummy', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006203, 702001139, 'Amok Kukri Mummy', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006301, 702001140, 'Mini Axe Poison', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006302, 702001140, 'Mini Axe Poison', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006303, 702001140, 'Mini Axe Poison', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006401, 702001143, 'Amok Kukri Poison', 0, 230, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006402, 702001143, 'Amok Kukri Poison', 0, 1380, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006403, 702001143, 'Amok Kukri Poison', 0, 2300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006501, 702001144, 'Keris ID 1stAnni', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006502, 702001144, 'Keris ID 1stAnni', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006503, 702001144, 'Keris ID 1stAnni', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000102, 803007004, 'C-5', 14000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30006601, 702001145, 'Machete de Combate Strike', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006602, 702001145, 'Machete de Combate Strike', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006603, 702001145, 'Machete de Combate Strike', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006701, 702001146, 'Death Scythe Demonic', 0, 280, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30005502, 702001120, 'Monkey Hammer', 0, 2100, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30003902, 702001084, 'Machete de Combate Rose', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003903, 702001084, 'Machete de Combate Rose', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006802, 702001147, 'Karambit', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30006803, 702001147, 'Karambit', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30006901, 702001148, 'Ladle Lebaran2016', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006902, 702001148, 'Ladle Lebaran2016', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006903, 702001148, 'Ladle Lebaran2016', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007101, 702001150, 'Machete de Combate Newborn2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007102, 702001150, 'Machete de Combate Newborn2016', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007103, 702001150, 'Machete de Combate Newborn2016', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007401, 702001155, 'Machete de Combate PBIC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007402, 702001155, 'Machete de Combate PBIC2016', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007403, 702001155, 'Machete de Combate PBIC2016', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007501, 702001159, 'Fang Blade Dark Steel', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007502, 702001159, 'Fang Blade Dark Steel', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007503, 702001159, 'Fang Blade Dark Steel', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007601, 702001160, 'Espada Árabe PBNC2016', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007602, 702001160, 'Espada Árabe PBNC2016', 0, 2100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007603, 702001160, 'Espada Árabe PBNC2016', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30004902, 702001106, 'Machete de Combate VeraCruz', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30007801, 702001162, 'Halloween Hammer', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007802, 702001162, 'Halloween Hammer', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007803, 702001162, 'Halloween Hammer', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007901, 702015007, 'Faca de Osso GRS2', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007902, 702015007, 'Faca de Osso GRS2', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007903, 702015007, 'Faca de Osso GRS2', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008101, 702015009, 'Faca de Osso PBNC2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008102, 702015009, 'Faca de Osso PBNC2015', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008103, 702015009, 'Faca de Osso PBNC2015', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008201, 702015010, 'Faca de Osso Camo Soldier', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008202, 702015010, 'Faca de Osso Camo Soldier', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007002, 702001149, 'Fang Blade Alien', 0, 1800, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30008001, 702015008, 'Kunai', 0, 450, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30008003, 702015008, 'Kunai', 0, 4500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30008401, 702015012, 'Kunai Serpent', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008402, 702015012, 'Kunai Serpent', 0, 2700, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008403, 702015012, 'Kunai Serpent', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008501, 702015013, 'Faca de Osso Skeleton', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008502, 702015013, 'Faca de Osso Skeleton', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008503, 702015013, 'Faca de Osso Skeleton', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008701, 702015015, 'Dual Sword TH', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008702, 702015015, 'Dual Sword TH', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008703, 702015015, 'Dual Sword TH', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008801, 702023003, 'Brass Knuckles ', 0, 50, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003802, 702001083, 'Nunchaku', 0, 1380, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30003803, 702001083, 'Nunchaku', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30008802, 702023003, 'Brass Knuckles ', 0, 300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008803, 702023003, 'Brass Knuckles ', 0, 500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008901, 702023004, 'Silver Knuckles ', 0, 50, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007202, 702001151, 'Ballistic Knife Russian Normal', 0, 1680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007203, 702001151, 'Ballistic Knife Russian Normal', 0, 2800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007301, 702001153, 'Ballistic Knife Russian Deluxe', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007201, 702001151, 'Ballistic Knife Russian Normal', 0, 280, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30007303, 702001153, 'Ballistic Knife Russian Deluxe', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007302, 702001153, 'Ballistic Knife Russian Deluxe', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008902, 702023004, 'Silver Knuckles ', 0, 300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008903, 702023004, 'Silver Knuckles ', 0, 500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009001, 702023005, 'Pumpkin knuckles', 0, 50, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009002, 702023005, 'Pumpkin knuckles', 0, 300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009003, 702023005, 'Pumpkin knuckles', 0, 500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009101, 702023006, 'Spiked Knuckle ', 0, 50, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009102, 702023006, 'Spiked Knuckle ', 0, 300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009103, 702023006, 'Spiked Knuckle ', 0, 500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009201, 702023007, 'Ballock Knuckle', 0, 50, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009203, 702023007, 'Ballock Knuckle', 0, 500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009301, 702023009, 'Garena Knuckles', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009302, 702023009, 'Garena Knuckles', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009303, 702023009, 'Garena Knuckles', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009401, 702001122, 'Butterfly Knife', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30009402, 702001122, 'Butterfly Knife', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30009403, 702001122, 'Butterfly Knife', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30009501, 702023010, 'Zombie Knuckle', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009502, 702023010, 'Zombie Knuckle', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009503, 702023010, 'Zombie Knuckle', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009601, 702001123, 'Fang Blade Arena Normal', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009602, 702001123, 'Fang Blade Arena Normal', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30007703, 702001161, 'Fang Blade SUPREME', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30009603, 702001123, 'Fang Blade Arena Normal', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009701, 702001124, 'Fang Blade Arena Deluxe', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009702, 702001124, 'Fang Blade Arena Deluxe', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009703, 702001124, 'Fang Blade Arena Deluxe', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009801, 702001127, 'Fang Blade Sakura', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009803, 702001127, 'Fang Blade Sakura', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009901, 702001129, 'Keris Beast', 0, 210, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009902, 702001129, 'Keris Beast', 0, 1260, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30009903, 702001129, 'Keris Beast', 0, 2100, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30010101, 702001009, 'M-7 Gold', 1000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010102, 702001009, 'M-7 Gold', 4500, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010103, 702001009, 'M-7 Gold', 10000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010201, 702001011, 'Amok Kukri D', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010202, 702001011, 'Amok Kukri D', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010203, 702001011, 'Amok Kukri D', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010301, 702001242, 'KNIFE_KUKRI_PBWC2018KNIFE', 0, 200, 86400, 2, 1, 1, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (30006703, 702001146, 'Death Scythe Demonic', 0, 2800, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30010302, 702001242, 'KNIFE_KUKRI_PBWC2018KNIFE', 0, 800, 604800, 2, 1, 1, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (30010303, 702001242, 'KNIFE_KUKRI_PBWC2018KNIFE', 0, 2000, 2592000, 2, 1, 1, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (40000201, 803007008, 'K-413 granada', 2500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40000202, 803007008, 'K-413 granada', 10000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40000301, 803007020, 'Granada de açúcar', 3000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000302, 803007020, 'Granada de açúcar', 12000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000502, 803007027, 'M-14 Mine', 4000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000601, 803007039, 'SepakTakraw Grenade', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000602, 803007039, 'SepakTakraw Grenade', 0, 100, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000603, 803007039, 'SepakTakraw Grenade', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000701, 803007045, 'PB Chocolate', 0, 100, 86400, 2, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (40000702, 803007045, 'PB Chocolate', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000703, 803007045, 'PB Chocolate', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000801, 803007047, 'K-413 Redemption', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000802, 803007047, 'K-413 Redemption', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000803, 803007047, 'K-413 Redemption', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000901, 803007049, 'K-413 4Game', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000902, 803007049, 'K-413 4Game', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008302, 702015011, 'Dual Knife Vera Cruz 2016', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40000903, 803007049, 'K-413 4Game', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001001, 803007050, 'K-413 4Game SE', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30010603, 702015026, 'BONEKNIFE M1LGR4U', 0, 3500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010701, 702001232, 'KARAMBIT M1LGR4U', 0, 370, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010702, 702001232, 'KARAMBIT M1LGR4U', 0, 1480, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010703, 702001232, 'KARAMBIT M1LGR4U', 0, 3700, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010602, 702015026, 'BONEKNIFE M1LGR4U', 0, 1400, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40001002, 803007050, 'K-413 4Game SE', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001003, 803007050, 'K-413 4Game SE', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001101, 803007054, 'K-413 Tiger-Normal', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001102, 803007054, 'K-413 Tiger-Normal', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001103, 803007054, 'K-413 Tiger-Normal', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001201, 803007055, 'K-413 Tiger-Deluxe', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001202, 803007055, 'K-413 Tiger-Deluxe', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30006801, 702001147, 'kambit', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40001203, 803007055, 'K-413 Tiger-Deluxe', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40000402, 803007026, 'Decoy Bomb', 0, 1100, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (40000501, 803007027, 'M-14 Mine', 1000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001301, 803007057, 'Mummy Grenade', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001302, 803007057, 'Mummy Grenade', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001303, 803007057, 'Mummy Grenade', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001501, 803007063, 'K-413 Puzzle', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001502, 803007063, 'K-413 Puzzle', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001503, 803007063, 'K-413 Puzzle', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001601, 803007064, 'K-413 Russian Normal', 0, 100, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30010002, 702001130, 'Fang Blade PBGC', 0, 1800, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30008603, 702015014, 'Faca de Osso E-Sports2', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30008601, 702015014, 'Faca de Osso E-Sports2', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40001602, 803007064, 'K-413 Russian Normal', 0, 600, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001603, 803007064, 'K-413 Russian Normal', 0, 1000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001702, 803007065, 'K-413 Russian Deluxe', 0, 600, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001703, 803007065, 'K-413 Russian Deluxe', 0, 1000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001801, 803007018, 'K-413 G', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001802, 803007018, 'K-413 G', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001803, 803007018, 'K-413 G', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001901, 803007028, 'K-479', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001902, 803007028, 'K-479', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001903, 803007028, 'K-479', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002001, 803007033, 'Soccer Grenade', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002002, 803007033, 'Soccer Grenade', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002003, 803007033, 'Soccer Grenade', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002101, 803007066, 'Bola de Futebol 2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002102, 803007066, 'Bola de Futebol 2016', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002103, 803007066, 'Bola de Futebol 2016', 0, 2500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002301, 803007044, 'C-5 ANC 2015', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002302, 803007044, 'C-5 ANC 2015', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002303, 803007044, 'C-5 ANC 2015', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002401, 803007067, 'C-5 PBIC2016', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002402, 803007067, 'C-5 PBIC2016', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002403, 803007067, 'C-5 PBIC2016', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002501, 803007068, 'C-5 PBNC2016', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002502, 803007068, 'C-5 PBNC2016', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002503, 803007068, 'C-5 PBNC2016', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002601, 803007056, 'C-5 PBWC2016', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002602, 803007056, 'C-5 PBWC2016', 0, 900, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002603, 803007056, 'C-5 PBWC2016', 0, 1500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002703, 803007006, 'C-5 D', 0, 1000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40002801, 803007009, 'Granada de Chocolate', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002802, 803007009, 'Granada de Chocolate', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002803, 803007009, 'Granada de Chocolate', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002901, 803007042, 'Granada de Ovelha', 0, 180, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30010403, 702015025, 'DUALKNIFE M9 DIGITAL', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40002902, 803007042, 'Granada de Ovelha', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40002903, 803007042, 'Granada de Ovelha', 0, 1800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003001, 803007052, 'Snowman Grenade', 0, 120, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003002, 803007052, 'Snowman Grenade', 0, 1080, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003003, 803007052, 'Snowman Grenade', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003201, 803007035, 'M-14 Mine D', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003202, 803007035, 'M-14 Mine D', 0, 1500, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003203, 803007035, 'M-14 Mine D', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003301, 803007036, 'K-413 Traditional', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003302, 803007036, 'K-413 Traditional', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003303, 803007036, 'K-413 Traditional', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003501, 803007038, 'ShuttleCock Grenade', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003502, 803007038, 'ShuttleCock Grenade', 0, 600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003503, 803007038, 'ShuttleCock Grenade', 0, 1000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000101, 904007005, 'WP Smoke', 6000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000102, 904007005, 'WP Smoke', 28000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000301, 904007013, 'FlashBang Plus', 120, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40001401, 803007062, 'K-400 Alien', 0, 100, 86400, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (50000302, 904007013, 'FlashBang Plus', 480, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000303, 904007013, 'FlashBang Plus', 1200, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40003703, 803007077, 'K 400 M1LGR4U', 0, 2000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40003101, 803007040, 'M18A1 Claymore', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40003702, 803007077, 'K 400 M1LGR4U', 0, 800, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40003102, 803007040, 'M18A1 Claymore', 0, 720, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40003103, 803007040, 'M18A1 Claymore', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000501, 904007015, 'Chocolate Medical Kit', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000502, 904007015, 'Chocolate Medical Kit', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000503, 904007015, 'Chocolate Medical Kit', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000601, 904007021, 'Medical Kit Lotus', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000602, 904007021, 'Medical Kit Lotus', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000701, 904007025, 'Medical Kit Opor Ayam', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003602, 803007079, 'THROWING_C5_PBWC2018', 0, 400, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003603, 803007079, 'THROWING_C5_PBWC2018', 0, 1000, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003401, 803007037, 'K-413 PC Cafe', 4000, 0, 100, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003402, 803007037, 'K-413 PC Cafe', 16000, 0, 500, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000702, 904007025, 'Medical Kit Opor Ayam', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000703, 904007025, 'Medical Kit Opor Ayam', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000801, 904007029, 'Medical Kit PBNC5', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000802, 904007029, 'Medical Kit PBNC5', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000803, 904007029, 'Medical Kit PBNC5', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000901, 904007032, 'Medical Kit Lotus2014', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000902, 904007032, 'Medical Kit Lotus2014', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000903, 904007032, 'Medical Kit Lotus2014', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50001101, 904007051, 'Medical Kit PBNC2015', 0, 360, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50001102, 904007051, 'Medical Kit PBNC2015', 0, 2160, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50001103, 904007051, 'Medical Kit PBNC2015', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000101, 1001001034, 'Rica', 4000, 0, 50, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000202, 904007011, 'Medical Kit', 80000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000401, 904007014, 'Halloween Medical Kit', 0, 360, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000402, 904007014, 'Halloween Medical Kit', 0, 2160, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000403, 904007014, 'Halloween Medical Kit', 0, 3600, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001202, 904007059, 'Smoke Pink', 0, 800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001203, 904007059, 'Smoke Pink', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001301, 904007060, 'Smoke Blue', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001302, 904007060, 'Smoke Blue', 0, 800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001303, 904007060, 'Smoke Blue', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001401, 904007061, 'Smoke Yellow', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001402, 904007061, 'Smoke Yellow', 0, 800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50000603, 904007021, 'Medical Kit Lotus', 0, 3600, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50001201, 904007059, 'Smoke Pink', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000102, 1001001034, 'Rica', 18000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000103, 1001001034, 'Rica', 32000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000201, 1001002004, 'Keen Eyes', 9000, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000202, 1001002004, 'Keen Eyes', 15000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000203, 1001002004, 'Keen Eyes', 68000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000301, 1001002033, 'Chou', 4000, 0, 50, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000302, 1001002033, 'Chou', 18000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000303, 1001002033, 'Chou', 32000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60000401, 1001001003, 'Tarantula', 9000, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000402, 1001001003, 'Tarantula', 15000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000403, 1001001003, 'Tarantula', 68000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001001, 1001002047, 'Keen Eyes - Garena (20%Exp)', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001002, 1001002047, 'Keen Eyes - Garena (20%Exp)', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001003, 1001002047, 'Keen Eyes - Garena (20%Exp)', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001101, 1001001049, 'Tarantula - Garena(20%Exp)', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001102, 1001001049, 'Tarantula - Garena(20%Exp)', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001103, 1001001049, 'Tarantula - Garena(20%Exp)', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001201, 1001002051, 'Hide Kopassus [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001202, 1001002051, 'Hide Kopassus [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001203, 1001002051, 'Hide Kopassus [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001401, 1001002053, 'Hide Cup [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001402, 1001002053, 'Hide Cup [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001403, 1001002053, 'Hide Cup [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001501, 1001001054, 'World Tarantula [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001502, 1001001054, 'World Tarantula [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001503, 1001001054, 'World Tarantula [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001601, 1001001055, 'Viper Shadow [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001602, 1001001055, 'Viper Shadow [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001603, 1001001055, 'Viper Shadow [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001701, 1001002056, 'Hide Recon [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001702, 1001002056, 'Hide Recon [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001703, 1001002056, 'Hide Recon [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001801, 1001002062, 'Acid Paul Infectado', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001802, 1001002062, 'Acid Paul Infectado', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001803, 1001002062, 'Acid Paul Infectado', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000601, 1001002008, 'Leopard (+20% EXP)', 5500, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000602, 1001002008, 'Leopard (+20% EXP)', 24750, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001303, 1001002052, 'Leopard Bope', 0, 7000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000503, 1001001007, 'D-Fox (+20% EXP)', 44000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001302, 1001002052, 'Leopard Bope', 0, 4200, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000502, 1001001007, 'D-Fox (+20% EXP)', 24750, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000603, 1001002008, 'Leopard (+20% EXP)', 44000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000901, 1001002018, 'Reinforced Combo Hide (+30% Gold) [R]', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000902, 1001002018, 'Reinforced Combo Hide (+30% Gold) [R]', 0, 1600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000903, 1001002018, 'Reinforced Combo Hide (+30% Gold) [R]', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001901, 1001002063, 'Kin Eyes Infectada', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001902, 1001002063, 'Kin Eyes Infectada', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001903, 1001002063, 'Kin Eyes Infectada', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002001, 1001002064, 'Hide Infectada', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002002, 1001002064, 'Hide Infectada', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002003, 1001002064, 'Hide Infectada', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002101, 1001002065, 'Leopard Infectado', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002102, 1001002065, 'Leopard Infectado', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002103, 1001002065, 'Leopard Infectado', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002201, 1001002067, 'Hide Strike [R]', 0, 500, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002202, 1001002067, 'Hide Strike [R]', 0, 3000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002203, 1001002067, 'Hide Strike [R]', 0, 5000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002301, 1001001068, 'Viper Kopassus [R]', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002302, 1001001068, 'Viper Kopassus [R]', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002303, 1001001068, 'Viper Kopassus [R]', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003203, 1001001465, 'Bella_PinkChoco [R]', 0, 5500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003101, 1001002462, 'Chou_MintChoco [R]', 0, 550, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003102, 1001002462, 'Chou_MintChoco [R]', 0, 2200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003103, 1001002462, 'Chou_MintChoco [R]', 0, 5500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70000101, 1102003002, 'Normal Headgear', 2000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000102, 1102003002, 'Normal Headgear', 9000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000201, 1102003003, 'Reinforced Headgear', 0, 170, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003202, 1001001465, 'Bella_PinkChoco [R]', 0, 2200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70000301, 1105003004, 'Chapéu de Cowboy', 0, 170, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000302, 1105003004, 'Chapéu de Cowboy', 0, 680, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000303, 1105003004, 'Chapéu de Cowboy', 0, 1700, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000401, 1105003009, 'Boné Pirocóptero', 2400, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000402, 1105003009, 'Boné Pirocóptero', 9600, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000501, 1105003001, 'Gorro do Papai Noel', 2000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000502, 1105003001, 'Gorro do Papai Noel', 8000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000602, 1103003006, 'Boina Negra', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000603, 1103003006, 'Boina Negra', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000701, 1103003007, 'Boina Che-Vermelha', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000702, 1103003007, 'Boina Che-Vermelha', 0, 920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (50001003, 904007043, 'Medical Kit Kurma', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (50001002, 904007043, 'Medical Kit Kurma', 0, 1400, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (70000703, 1103003007, 'Boina Che-Vermelha', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000801, 1103003008, 'Yellow Star Beret', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000802, 1103003008, 'Yellow Star Beret', 0, 920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000803, 1103003008, 'Yellow Star Beret', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000901, 1103003009, 'Cross Knife Beret', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000902, 1103003009, 'Cross Knife Beret', 0, 920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70000903, 1103003009, 'Cross Knife Beret', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (60002502, 1006003044, 'Raptor Mercury Dino (Reinforced Raptor)', 4200, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002503, 1006003044, 'Raptor Mercury Dino (Reinforced Raptor)', 7000, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002601, 1006003045, 'Sting Mars Dino (Reinforced Sting)', 700, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002602, 1006003045, 'Sting Mars Dino (Reinforced Sting)', 4200, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002603, 1006003045, 'Sting Mars Dino (Reinforced Sting)', 7000, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002701, 1006003046, 'Acid Vulcan Dino (Reinforced Acid)', 700, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002702, 1006003046, 'Acid Vulcan Dino (Reinforced Acid)', 4200, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002703, 1006003046, 'Acid Vulcan Dino (Reinforced Acid)', 7000, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002802, 1001001015, 'Reinforced Combo D-Fox (+20% EXP) [R]', 0, 1350, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002803, 1001001015, 'Reinforced Combo D-Fox (+20% EXP) [R]', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002901, 1001002016, 'Reinforced Combo Leopard (+20% EXP) [R]', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002902, 1001002016, 'Reinforced Combo Leopard (+20% EXP) [R]', 0, 1350, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002903, 1001002016, 'Reinforced Combo Leopard (+20% EXP) [R]', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003001, 1001001017, 'Reinforced Combo Viper Red (+30% Gold) [R]', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003002, 1001001017, 'Reinforced Combo Viper Red (+30% Gold) [R]', 0, 1600, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003003, 1001001017, 'Reinforced Combo Viper Red (+30% Gold) [R]', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003501, 1001002035, 'Reinforced Chou [R]', 0, 220, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003502, 1001002035, 'Reinforced Chou [R]', 0, 880, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003503, 1001002035, 'Reinforced Chou [R]', 0, 2200, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003601, 1001001036, 'Reinforced Bella [R]', 0, 220, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003602, 1001001036, 'Reinforced Bella [R]', 0, 880, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003603, 1001001036, 'Reinforced Bella [R]', 0, 2200, 2592000, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000703, 1001002009, 'Hide (+30% Gold)', 30000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003302, 1001001069, 'Bella FBI [R]', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003303, 1001001069, 'Bella FBI [R]', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003401, 1001002144, 'Chou FBI [R]', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003402, 1001002144, 'Chou FBI [R]', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003403, 1001002144, 'Chou FBI [R]', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60000702, 1001002009, 'Hide (+30% Gold)', 24750, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002402, 1006003032, 'Elite Dino', 0, 4800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000801, 1001001010, 'Viper Red (+30% Gold)', 5500, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002403, 1006003032, 'Elite Dino', 0, 8000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002401, 1006003032, 'Elite Dino', 0, 800, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003701, 1001001415, 'Bella HalloweenNurse [R]', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003702, 1001001415, 'Bella HalloweenNurse [R]', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003703, 1001001415, 'Bella HalloweenNurse [R]', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003801, 1001002418, 'Chou HalloweenNurse [R]', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003802, 1001002418, 'Chou HalloweenNurse [R]', 0, 1600, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003803, 1001002418, 'Chou HalloweenNurse [R]', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70001001, 1103003010, 'PBTN Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001002, 1103003010, 'PBTN Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001003, 1103003010, 'PBTN Beret', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001101, 1103003011, 'PB Black Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001102, 1103003011, 'PB Black Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001103, 1103003011, 'PB Black Beret', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001202, 1103003012, 'Boina da Turkia', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001203, 1103003012, 'Boina da Turkia', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001302, 1103003013, 'Boina Kopassus', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001303, 1103003013, 'Boina Kopassus', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001401, 1103003014, 'Boina Skull', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001402, 1103003014, 'Boina Skull', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001403, 1103003014, 'Boina Skull', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001501, 1103003015, 'PBNC5 Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001502, 1103003015, 'PBNC5 Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001503, 1103003015, 'PBNC5 Beret', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001601, 1103003016, 'Boina E-General', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001602, 1103003016, 'Boina E-General', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001603, 1103003016, 'Boina E-General', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70000203, 1102003003, 'Reinforced Headgear', 0, 1700, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001703, 1103003017, 'Boina Brasil', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70000601, 1103003006, 'Boina Negra', 0, 250, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70001701, 1103003017, 'Boina Brasil', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70001702, 1103003017, 'Boina Brasil', 0, 920, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70001201, 1103003012, 'Boina da Turkia', 0, 100000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001301, 1103003013, 'Boina Kopassus', 0, 100000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002101, 1102003008, 'Super Headgear', 0, 350, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002102, 1102003008, 'Super Headgear', 0, 1400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002103, 1102003008, 'Super Headgear', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002201, 1102003009, 'Anel de Anjo', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70002202, 1102003009, 'Anel de Anjo', 0, 920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70002203, 1102003009, 'Anel de Anjo', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70002301, 1105003002, 'ChineseHat', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002302, 1105003002, 'ChineseHat', 0, 1800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002303, 1105003002, 'ChineseHat', 0, 3000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002401, 1105003003, 'Bandana Indonesia', 0, 240, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002402, 1105003003, 'Bandana Indonesia', 0, 1440, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002403, 1105003003, 'Bandana Indonesia', 0, 2400, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002501, 1105003005, 'Bandana (GW)', 0, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002502, 1105003005, 'Bandana (GW)', 0, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002503, 1105003005, 'Bandana (GW)', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002601, 1105003006, 'Fes Hat', 0, 240, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002602, 1105003006, 'Fes Hat', 0, 1440, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002701, 1105003007, 'ChineseHat2', 0, 240, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002702, 1105003007, 'ChineseHat2', 0, 1440, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002703, 1105003007, 'ChineseHat2', 0, 2400, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002801, 1105003008, 'Chapéu Kopassus', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002802, 1105003008, 'Chapéu Kopassus', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002803, 1105003008, 'Chapéu Kopassus', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002902, 1105003010, 'Chapéu Cangaceiro', 0, 2280, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002903, 1105003010, 'Chapéu Cangaceiro', 0, 3800, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003001, 1105003011, 'Soldier Day Hat(Paper Hat)', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003002, 1105003011, 'Soldier Day Hat(Paper Hat)', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003003, 1105003011, 'Soldier Day Hat(Paper Hat)', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003101, 1105003012, 'Chapéu da Independência', 0, 420, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003102, 1105003012, 'Chapéu da Independência', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003103, 1105003012, 'Chapéu da Independência', 0, 4200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003201, 1105003013, 'Chapéu Camo Soldier', 0, 470, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003202, 1105003013, 'Chapéu Camo Soldier', 0, 2820, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003203, 1105003013, 'Chapéu Camo Soldier', 0, 4700, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003301, 1105003014, 'Chapéu de Cowboy (GM)', 0, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003302, 1105003014, 'Chapéu de Cowboy (GM)', 0, 0, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003303, 1105003014, 'Chapéu de Cowboy (GM)', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003501, 1105003016, 'Máscara do Macaco', 0, 470, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003502, 1105003016, 'Máscara do Macaco', 0, 2820, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003503, 1105003016, 'Máscara do Macaco', 0, 4700, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003601, 1103003002, 'Sniper Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003602, 1103003002, 'Sniper Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003701, 1103003003, 'Shoting Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003702, 1103003003, 'Shoting Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003801, 1103003004, 'SMG Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003802, 1103003004, 'SMG Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003901, 1103003005, 'Shotgun Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003902, 1103003005, 'Shotgun Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000101, 1104003001, 'Máscara branca', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000201, 1104003002, 'Máscara preta', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000301, 1104003003, 'Camuflagem Tigre Russo', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000401, 1104003004, 'Camuflagem Naval', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000501, 1104003005, 'Camuflagem Francesa', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000601, 1104003006, 'Máscara de Fogo', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000701, 1104003007, 'Máscara duas cores', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80000801, 1104003008, 'Hockey Mask', 2500, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70001902, 1102003006, 'Capacete Rastreamento', 0, 600, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70001903, 1102003006, 'Capacete Rastreamento', 0, 1500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80000903, 1104003009, 'No alvo', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003402, 1103003001, 'Assault Beret', 0, 60000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003403, 1103003001, 'Assault Beret', 0, 100000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001001, 1104003010, 'Abóbora de Halloween', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001102, 1104003011, 'Pink Death Mask', 0, 1000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001102, 1104003011, 'Pink Death Mask', 0, 1000, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001103, 1104003011, 'Pink Death Mask', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001201, 1104003012, 'Golden Face Mask', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001202, 1104003012, 'Golden Face Mask', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001203, 1104003012, 'Golden Face Mask', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001301, 1104003013, 'Crânio Mask', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001302, 1104003013, 'Crânio Mask', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001303, 1104003013, 'Crânio Mask', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001401, 1104003014, 'Palhaço Assassino Mask', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001402, 1104003014, 'Palhaço Assassino Mask', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001403, 1104003014, 'Palhaço Assassino Mask', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80001501, 1104003015, 'Alienígina Azul Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001601, 1104003016, 'Alienígina Vermelho Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001701, 1104003017, 'Máscara Templária Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001801, 1104003018, 'Jason Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80001901, 1104003019, 'Panda Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002901, 1105003010, 'Chapéu Cangaceiro', 0, 380, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002603, 1105003006, 'Fes Hat', 0, 2400, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002001, 1104003020, 'Máscara de Páscoa Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002101, 1104003021, 'Death Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002201, 1104003022, 'Máscara Argentina', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002301, 1104003023, 'Máscara Brasil', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002401, 1104003024, 'Máscara Inglaterra', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002501, 1104003025, 'Máscara França', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002601, 1104003026, 'Máscara Alemanha', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002701, 1104003027, 'Máscara Itália', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002801, 1104003028, 'Máscara Japão', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80002901, 1104003029, 'Máscara África do Sul', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003001, 1104003030, 'Máscara Coréia', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003101, 1104003031, 'Máscara Espanha', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003201, 1104003032, 'Tigre Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003301, 1104003033, 'Jester_BW Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003401, 1104003034, 'Wrestling Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003501, 1104003035, 'Máscara Russia', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003601, 1104003036, 'Ukraine Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003701, 1104003037, 'Belorus Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003801, 1104003038, 'Kazahstan Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80003901, 1104003039, 'Máscara Demônio Vermelho', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004001, 1104003040, 'Besiktas FC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004101, 1104003041, 'Bursapor FC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004201, 1104003042, 'Fenerbahce FC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004301, 1104003043, 'Galatasaray FC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004401, 1104003044, 'Trabzonspor FC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004501, 1104003045, 'Máscara Crânio Frágil', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004701, 1104003047, 'Latin Bolivia', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80004801, 1104003048, 'Latin Cayman', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005001, 1104003050, 'Latin Colombia', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005101, 1104003051, 'Latin Costarica', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005201, 1104003052, 'Latin Honduras', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005301, 1104003053, 'Latin Jamaica', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005401, 1104003054, 'Latin Mexico', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005501, 1104003055, 'Latin Nicaragua', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005601, 1104003056, 'Latin Panama', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005701, 1104003057, 'Latin Paraguay', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005801, 1104003058, 'Latin Dominican', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80005901, 1104003059, 'Latin Equador', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006001, 1104003060, 'Latin FR Guyana', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006101, 1104003061, 'Latin Guatemala', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006201, 1104003062, 'Latin Guyana', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006301, 1104003063, 'Latin Haiti', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006401, 1104003064, 'Latin Peru', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006501, 1104003065, 'Latin Puertorico', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006601, 1104003066, 'Latin Suriname', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006701, 1104003067, 'Latin Trinidad', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80006801, 1104003068, 'Latin Uruguay', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70004003, 1103003031, 'Beret FireDragon', 0, 2300, 2592000, 2, 1, 1, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70004002, 1103003031, 'Beret FireDragon', 0, 920, 604800, 2, 1, 1, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (80006901, 1104003069, 'Latin Venezuela', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007001, 1104003070, 'Latin Argentina', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007101, 1104003071, 'Crânio de Dinossauro', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007201, 1104003072, 'Raptr Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007301, 1104003073, 'Canada Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007401, 1104003074, 'Máscara Inglaterra', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007501, 1104003075, 'Máscara EUA', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007601, 1104003076, 'Indonesia Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007701, 1104003077, 'Máscara PBTN', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80007801, 1104003078, 'Máscara Chinesa Vermelha', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003703, 1103003003, 'Shoting Beret', 0, 5000, 2592000, 2, 1, 1, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (70003803, 1103003004, 'SMG Beret', 0, 5000, 2592000, 2, 1, 1, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (70003903, 1103003005, 'Shotgun Beret', 0, 5000, 2592000, 2, 1, 1, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (80007901, 1104003079, 'Red Eyes Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008301, 1104003099, 'Trex Headgear', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008501, 1104003101, 'Frail Skull Gold Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008601, 1104003107, 'Máscara PBIC2012', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008701, 1104003113, 'Gatotkaca Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008801, 1104003114, 'Blue tiger mask set of Russian army', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008901, 1104003115, 'Mask set of Korea marine corps', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009001, 1104003116, 'Desert mask set of France army', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009101, 1104003117, 'Gatotkaca Gold Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009201, 1104003118, 'PBSC Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009401, 1104003121, 'Garena Gold Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009501, 1104003122, 'Garena Red Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70002002, 1102003007, 'Capacete Avançado Plus', 0, 920, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80009601, 1104003123, 'Garena White Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009701, 1104003124, 'Black Snake Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009801, 1104003125, 'Egg Tarantula Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009901, 1104003126, 'GSL Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010001, 1104003127, 'Egg RedBulls Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010101, 1104003128, 'Máscara PBNC4', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010201, 1104003129, 'Máscara PBIC2013', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010301, 1104003131, 'Máscara de Ovelha', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010401, 1104003132, 'Máscara de Zumbi', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010501, 1104003134, 'LATIN3 Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010601, 1104003135, 'LATIN3 Premium Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010701, 1104003136, 'Unicorn Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010801, 1104003137, 'TH 1st Anniversary Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80010901, 1104003142, 'WC 2014 Argentina Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011001, 1104003143, 'WC 2014 Brazil Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011201, 1104003145, 'WC 2014 Colombia Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011301, 1104003146, 'WC 2014 Equador Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011401, 1104003147, 'WC 2014 England Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011501, 1104003148, 'WC 2014 France Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011601, 1104003149, 'WC 2014 Germany Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011701, 1104003150, 'WC 2014 Italy Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011801, 1104003151, 'WC 2014 Japan Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80011901, 1104003152, 'WC 2014 Korea Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012001, 1104003153, 'WC 2014 Spain Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012101, 1104003154, 'WC 2014 U.S.A Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012201, 1104003155, 'WC 2014 Uruguay Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012301, 1104003156, 'WC 2014 Honduras Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012401, 1104003157, 'WC 2014 Mexico Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012501, 1104003158, 'WC 2014 CostaRica Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012601, 1104003159, 'GSL 2014 Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012701, 1104003160, 'WC 2014 Greece Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012801, 1104003161, 'WC 2014 Netherlands Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80012901, 1104003162, 'WC 2014 Belgium Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013001, 1104003163, 'WC 2014 Bosnia and Herzegovina Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013101, 1104003164, 'WC 2014 Switzerland Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013201, 1104003165, 'WC 2014 Croatia Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013301, 1104003166, 'WC 2014 Portugal Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013401, 1104003167, 'WC 2014 Ghana Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013501, 1104003168, 'WC 2014 Nigeria Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013601, 1104003169, 'WC 2014 Algeria Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013701, 1104003170, 'WC 2014 Cameroon Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013801, 1104003171, 'WC 2014 Cote d''Ivoire Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80013901, 1104003172, 'WC 2014 Iran Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014001, 1104003173, 'WC 2014 Australia Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014101, 1104003174, 'WC 2014 Russia Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014201, 1104003176, 'Egg KeenEyes Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014301, 1104003176, 'Egg AcidPol Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014401, 1104003177, 'Mask Midnight', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014501, 1104003178, 'Brazuca Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014601, 1104003179, 'Indonesia Mask (GW)', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014701, 1104003180, 'Máscara Inferno', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014801, 1104003181, 'Máscara Inferno Premium', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80014901, 1104003182, 'Máscara PBIC2014', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015001, 1104003183, 'Máscara PBSC2013 NonLogo', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015101, 1104003186, 'Máscara Midnight', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015201, 1104003187, 'Máscara Latin4', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015301, 1104003188, 'Máscara Latin4 Premium', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015401, 1104003189, 'Máscara GRS2', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015501, 1104003190, 'Máscara GSL2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015601, 1104003191, 'Máscara Ongame', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015701, 1104003192, 'Máscara Ongame Premium', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015801, 1104003193, 'Máscara D-Fox Egg', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80015901, 1104003194, 'Máscara Viper Egg', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016001, 1104003195, 'Máscara Songkran2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016201, 1104003197, 'Máscara Harimau', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016301, 1104003199, 'Máscara 4Game', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016401, 1104003200, 'Máscara 4Game SE', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016501, 1104003201, 'Máscara Madness', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016601, 1104003202, 'Máscara Madness Premium', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016701, 1104003204, 'Máscara PBTC2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016801, 1104003205, 'Meia-Máscara PBTC2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016901, 1104003206, 'Máscara Mech', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017001, 1104003209, 'Meia-Máscara PBIC2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017101, 1104003210, 'Máscara PBIC2015', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017201, 1104003211, 'Máscara Red Cross', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017301, 1104003213, 'Máscara Cobra', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017401, 1104003214, 'Máscara Halloween', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017601, 1104003216, 'Máscara Latin5 PREMIUM', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008001, 1104003096, 'Smile Cartoon Mask Set (Troll Meme)', 0, 600, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (80011101, 1104003144, 'WC 2014 Chile Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80008101, 1104003097, 'Angry Cartoon Mask Set (Respect Meme)', 0, 600, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (80008401, 1104003100, 'Trojan Mask', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80017701, 1104003217, 'Máscara Latin5', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017801, 1104003218, 'Máscara Obsidian', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80017901, 1104003219, 'Máscara Spy-Deluxe', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018001, 1104003220, 'Máscara DFN', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018101, 1104003222, 'Máscara Arena-Normal', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018201, 1104003223, 'Máscara Arena-Deluxe', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018301, 1104003224, 'Máscara do Cupido', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018401, 1104003225, 'Máscara Serpent', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018501, 1104003226, 'Máscara Songkran2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018601, 1104003227, 'Máscara GRS3', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018701, 1104003228, 'Máscara PBGC', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018801, 1104003229, 'Máscara GSL2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80018901, 1104003230, 'Máscara Tiger Deluxe', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019001, 1104003231, 'Máscara Midnight2', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019101, 1104003232, 'Máscara Skeleton', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019201, 1104003233, 'Máscara E-Sports2', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019301, 1104003234, 'Máscara Mummy', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019401, 1104003235, 'ID 1stAnni Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019501, 1104003236, 'Demonic Mask', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019601, 1104003237, 'Máscara Blue Diamond', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019701, 1104003238, 'Mask Puzzle', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019801, 1104003241, 'Máscara Liberty', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80019901, 1104003242, 'Máscara Básica PBIC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020001, 1104003243, 'Máscara Premium PBIC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020101, 1104003244, 'Máscara PBTC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020201, 1104003245, 'Máscara PBST2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020301, 1104003246, 'Meia-Máscara PBTC2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020401, 1104003247, 'Máscara Furious', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020501, 1104003248, 'Máscara Clown BR', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020601, 1104003249, 'Meia-Máscara Skull', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020701, 1104003250, 'Máscara Chain', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020801, 1104003251, 'Máscara Phantom', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80020901, 1104003252, 'Máscara Halloween 2016', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80021001, 1104003253, 'Máscara NightHunter', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80021101, 1104003254, 'Máscara Eagle17', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80021201, 1104003256, 'Máscara Canary17', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000100, 1200002000, '130% EXP UP [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000101, 1300002001, '130% EXP UP', 0, 300, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000103, 1300002030, '130% EXP UP', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000200, 1200003000, '150% EXP UP [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000201, 1300003001, '150% EXP UP', 0, 500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000202, 1300003007, '150% EXP UP', 0, 2000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000203, 1300003030, '150% EXP UP', 0, 5000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000300, 1200004000, '130% Point UP [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000301, 1300004001, '130% Point UP', 0, 300, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000302, 1300004007, '130% Point UP', 0, 1200, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000303, 1300004030, '130% Point UP', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000400, 1200006000, 'Nick Color[E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000500, 1200007000, 'Quick Respawn 30% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000501, 1300007001, 'Quick Respawn 30%', 1000, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000502, 1300007007, 'Quick Respawn 30%', 1500, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000503, 1300007030, 'Quick Respawn 30%', 3000, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000600, 1200008000, 'Extended Magazine [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000601, 1300008001, 'Extended Magazine', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000602, 1300008007, 'Extended Magazine', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000603, 1300008030, 'Extended Magazine', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000700, 1200009000, 'Fake Rank [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000800, 1200010000, 'Apelido temporário 5D [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000801, 1300010001, 'Apelido temporário 5D', 0, 500, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000802, 1300010007, 'Apelido temporário 5D', 0, 3000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000803, 1300010030, 'Apelido temporário 5D', 0, 5000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000900, 1200011000, 'Fee Move, Free Pass [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000901, 1300011001, 'Fee Move, Free Pass', 0, 100, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000902, 1300011007, 'Fee Move, Free Pass', 0, 400, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000903, 1300011030, 'Fee Move, Free Pass', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001000, 1200014000, 'Color Change Crosshair [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001001, 1300014001, 'Color Change Crosshair', 800, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001002, 1300014007, 'Color Change Crosshair', 3600, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001003, 1300014030, 'Color Change Crosshair', 8000, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001100, 1200017000, 'Quick Change Weapon [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001101, 1300026001, 'Quick Change Weapon', 0, 450, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001102, 1300026007, 'Quick Change Weapon', 0, 1800, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001103, 1300026030, 'Quick Change Weapon', 0, 4500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001200, 1200026000, 'Quick Change Reload [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001201, 1300027001, 'Quick Change Reload', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001202, 1300027007, 'Quick Change Reload', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90000403, 1300006030, 'Nick Color', 0, 0, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90000401, 1300006001, 'Nick Color', 0, 0, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90000402, 1300006007, 'Nick Color', 0, 0, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90001203, 1300027030, 'Quick Change Reload', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001400, 1200028000, 'Invincible +1 Sec. [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001401, 1300029001, 'Invincible +1 Sec.', 0, 150, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001402, 1300029007, 'Invincible +1 Sec.', 0, 600, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001403, 1300029030, 'Invincible +1 Sec.', 0, 1500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001500, 1200029000, '5% Defense Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001501, 1300030001, '5% Defense Up', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001502, 1300030007, '5% Defense Up', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001503, 1300030030, '5% Defense Up', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001600, 1200030000, 'Damage Up, Accuracy Down [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001601, 1300031001, 'Damage Up, Accuracy Down', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001602, 1300031007, 'Damage Up, Accuracy Down', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001603, 1300031030, 'Damage Up, Accuracy Down', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001700, 1200031000, 'Munição Hollow Point [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001701, 1300032001, 'Munição Hollow Point', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001702, 1300032007, 'Munição Hollow Point', 0, 1000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001703, 1300032030, 'Munição Hollow Point', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001801, 1300033001, 'FlashBang Protection', 0, 150, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001802, 1300033007, 'FlashBang Protection', 0, 900, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001803, 1300033030, 'FlashBang Protection', 0, 1500, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001900, 1200033000, 'C4 Speed Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001901, 1300034001, 'C4 Speed Up', 0, 600, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001902, 1300034007, 'C4 Speed Up', 0, 3600, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001903, 1300034030, 'C4 Speed Up', 0, 6000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002000, 1200034000, 'Increase Grenade Slot +1 [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002001, 1300035001, 'Increase Grenade Slot +1', 0, 300, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002002, 1300035007, 'Increase Grenade Slot +1', 0, 1200, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002003, 1300035030, 'Increase Grenade Slot +1', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002100, 1200035000, 'Damage & Accuracy Up, Move Down [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002101, 1300036001, 'Damage & Accuracy Up, Move Down', 0, 500, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002102, 1300036007, 'Damage & Accuracy Up, Move Down', 0, 2000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002200, 1200036000, '200% EXP Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002201, 1300037001, '200% EXP Up', 0, 750, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002202, 1300037007, '200% EXP Up', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002203, 1300037030, '200% EXP Up', 0, 7500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002300, 1200037000, '200% Point Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002301, 1300038001, '200% Point Up', 0, 750, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002302, 1300038007, '200% Point Up', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002303, 1300038030, '200% Point Up', 0, 7500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002400, 1200038000, 'HP Up 5% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002401, 1300040001, 'HP Up 5%', 0, 250, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002402, 1300040007, 'HP Up 5%', 0, 1125, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002403, 1300040030, 'HP Up 5%', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002600, 1200044000, 'Quick Respawn 50% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002601, 1300064001, 'Quick Respawn 50%', 900, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002602, 1300064007, 'Quick Respawn 50%', 4050, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002603, 1300064030, 'Quick Respawn 50%', 9000, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002700, 1200064000, '90% Defense Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002800, 1200065000, 'Quick Respawn 20% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002801, 1300077001, 'Quick Respawn 20%', 500, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002802, 1300077007, 'Quick Respawn 20%', 2250, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002803, 1300077030, 'Quick Respawn 20%', 5000, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002900, 1200078000, 'Hollow Point Plus (Invisible) [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002901, 1300078001, 'Hollow Point Plus', 0, 750, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002902, 1300078007, 'Hollow Point Plus', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002903, 1300078030, 'Hollow Point Plus', 0, 7500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003000, 1200079000, '20% Defense Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003100, 1200080000, 'Quick Respawn 100% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003101, 1300080001, 'Quick Respawn 100%', 0, 400, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003102, 1300080007, 'Quick Respawn 100%', 0, 1600, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003103, 1300080030, 'Quick Respawn 100%', 0, 4000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003200, 1200119000, '150% Point Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003201, 1300119001, '150% Point Up', 0, 500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003202, 1300119007, '150% Point Up', 0, 2000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003203, 1300119030, '150% Point Up', 0, 5000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003302, 1300185007, 'Extended Magazine 10%', 0, 2400, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003303, 1300185030, 'Extended Magazine 10%', 0, 6000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003400, 1200242000, 'Increase Smoke Slot +1 [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003401, 1300242001, 'Increase Smoke Slot +1', 0, 300, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003402, 1300242007, 'Increase Smoke Slot +1', 0, 1200, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003403, 1300242030, 'Increase Smoke Slot +1', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003003, 1300079030, '20% Defense Up', 0, 6000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001302, 1300028007, 'MAX HP Up 10%', 0, 2000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003701, 1301048000, 'Reset Win / Losers', 0, 2500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003801, 1301049000, 'Reset Kill / Death', 0, 4500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90003901, 1301050000, 'Reset Dropouts', 0, 50000, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90004001, 1301051000, 'Change clan name', 25000, 0, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90004101, 1301052000, 'Change clan badge', 50000, 0, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90004201, 1301053000, 'Reset Clan Win / Losers', 0, 5000, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90004301, 1301055000, 'More 50 Members in Guild', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90004501, 1301085000, 'PB Inspector', 1000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90004601, 1301090000, 'Dual Uzi Supply Kit 1d', 0, 1955, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90004701, 1301097000, 'Famas G2 Supply Kit 1d', 0, 2125, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90004801, 1301098000, 'Dual Uzi Supply Kit 3d', 0, 2210, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90004901, 1301099000, 'Dual Uzi Supply Kit 7d', 0, 2380, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005001, 1301100000, 'Dual Uzi Supply Kit 30d', 0, 2635, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005101, 1301102000, 'Famas G2 Supply Kit 3d', 0, 2295, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005201, 1301103000, 'Famas G2 Supply Kit 7d', 0, 2550, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005301, 1301104000, 'Famas G2 Supply Kit 30d', 0, 2805, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003002, 1300079007, '20% Defense Up', 0, 3600, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002503, 1300044030, '10% Defense Up', 0, 5000, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90003300, 1200185000, 'Extended Magazine 10% [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003301, 1300185001, 'Extended Magazine 10%', 0, 600, 1, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (90003001, 1300079001, '20% Defense Up', 0, 600, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005501, 1301118000, 'Gold 30000', 0, 3000, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90005601, 1301120000, 'Random Box Gold Bomb', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005701, 1301121000, 'Random Box Gold Bomb Premium', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007601, 1301507000, 'Random Box of Masks', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007701, 1301527000, 'Random Box Gold', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007801, 1301587000, 'Random Box Xmas', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008001, 1301646000, 'Random Box Elite Pro', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008101, 1301647000, 'Random Box AK Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008301, 1301649000, 'Random Box G36C Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008401, 1301650000, 'Random Box M4A1 Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008501, 1301651000, 'Random Box PSG1 Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008601, 1301652000, 'Random Box SPAS-15 Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008701, 1301653000, 'Random Box SVU Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008801, 1301654000, 'Random Box VSK94 Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90008901, 1301663000, 'Random Box Every Day', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90003501, 1301045000, 'Random Box of Weapons 2', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000205, 1500000001, 'Point 1,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000305, 1500000002, 'Point 2,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000405, 1500000003, 'Point 3,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000505, 1500000004, 'Point 4,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000605, 1500000005, 'Point 5,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000705, 1500000006, 'Point 6,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000805, 1500000007, 'Point 7,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000905, 1500000008, 'Point 8,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001005, 1500000009, 'Point 9,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001105, 1500000010, 'Point 10,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001205, 1500000011, 'Point 11,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001305, 1500000012, 'Point 12,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001405, 1500000013, 'Point 13,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001505, 1500000014, 'Point 14,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001605, 1500000015, 'Point 15,000', 1, 0, 1, 1, 1, 2, 0, 0, 4);
INSERT INTO "public"."shop" VALUES (100001705, 1500000016, 'Point 16,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001805, 1500000017, 'Point 17,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100001905, 1500000018, 'Point 18,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002005, 1500000019, 'Point 19,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002105, 1500000020, 'Point 20,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002205, 1500000025, 'Point 25,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002305, 1500000030, 'Point 30,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002405, 1500000035, 'Point 35,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002505, 1500000040, 'Point 40,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002605, 1500000045, 'Point 45,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002705, 1500000050, 'Point 50,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100002905, 1500000200, 'Point 200,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003005, 1500000300, 'Point 300,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003105, 1500000500, 'Point 500,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003205, 1501000000, 'Point 1,000,00', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003305, 1503000000, 'Point 3,000,00', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003405, 1500000028, 'Point 28,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003505, 1500000032, 'Point 32,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003605, 1500000036, 'Point 36,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003705, 1500000060, 'Point 70,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003805, 1500000022, 'Point 22,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100003905, 1500000024, 'Point 24,000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100004005, 1500002003, 'Point 3,200', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100004201, 1500001000, 'Point 100', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100004301, 1500000055, 'Point 55000', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (110011230, 100003048, 'Aug A3 Black[Aug A3 Black Set]', 0, 18000, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (60000501, 1001001007, 'D-Fox (+20% EXP)', 5500, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (110011230, 601002021, 'Glock 18 D[Aug A3 Black Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110011230, 1104003079, 'Mask Reinforce Black[Aug A3 Black Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110011230, 1300044030, 'BulletProofVestPlus[Aug A3 Black Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110016430, 200004075, 'p90 G [p90 G Set]', 0, 12500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110016430, 1104003101, 'Mask Frail Skull Gold[p90 G Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110016430, 1300044030, 'BulletProofVestPlus[p90 G Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110016430, 1300080030, 'Shorten Respawn 100%[p90 G Set]', 0, 6789, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017530, 200004114, 'Skull Package - P90 BR Camo', 0, 11500, 2592000, 0, 1, 2, 5, 0, 1);
INSERT INTO "public"."shop" VALUES (110017530, 300005065, 'Skull Package - L115A1 BR Camo', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017530, 1001002052, 'Skull Package - Leopard Bope', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017530, 1103003014, 'Skull Package - Boina Skull', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017530, 1300027030, 'Skull Package - Recarregamento', 0, 0, 1, 0, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (110017730, 100003040, 'Kit Pro Player - AUG A3 D 30d', 0, 4567, 2592000, 0, 1, 2, 5, 0, 1);
INSERT INTO "public"."shop" VALUES (110017730, 601002012, 'Kit Pro Player - C. Python D', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017730, 1103003006, 'Kit Pro Player - Boina Negra', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017730, 1300027030, 'Kit Pro Player - Recarregamento', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110017730, 1300035030, 'Kit Pro Player - Explosivo extra', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110034330, 601002049, 'Kit Pro A - C. Python Brazuca', 0, 6666, 2592000, 0, 1, 2, 5, 0, 1);
INSERT INTO "public"."shop" VALUES (110034330, 1300026030, 'Kit Pro A - Troca rápida', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110034330, 1300044030, 'Kit Pro A - Colete 10%', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110034330, 1300078030, 'Kit Pro A - Hollow Point Plus', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110036830, 1001001295, 'Viper Red Special Force[Special Force Combo Set] [R]', 0, 55500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (1008, 1103003014, '', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100000105, 1508000000, 'Point 8,000,00', 1, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (110036830, 1001002294, 'Hide Special Force[Special Force Combo Set] [R]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110036830, 1500000100, '100k[Special Force Combo Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058230, 300005199, 'CheyTec M200 Beyond[Beyond Set]', 0, 20000, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110058230, 1001002067, 'Hide Strike[Beyond Set] [R]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058230, 1104003273, 'Mask New Generation[Beyond Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058230, 1300026030, 'Quick Change Weapon[Beyond Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058330, 1001001286, 'General Viper[General Combo Set] [R]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058330, 1001002287, 'General Hide[General Combo Set] [R]', 0, 55500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110058330, 1500000100, '100k[General Combo Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058430, 100003323, 'Aug A3 Pirate[Pirate Set]', 0, 16500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110058430, 1001001283, 'Pirate Tarantula [Pirate Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110058430, 1300044030, 'BulletProofVestPlus[Pirate Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064430, 100003249, 'Aug A3 S.[Golden Set]', 0, 16500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110064430, 601002114, 'Tec-9G[Golden Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (90010401, 1302266000, 'RandomBox OA-7 Box_TAM', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90005401, 1301108000, 'Random Box of Cheguevara', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90010501, 1302379000, 'RandomBox Premium Knife Box_TAM', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007901, 1301619000, 'Random Box Mix PBIC', 0, 2500, 5, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90006701, 1301241000, 'Random Box Demonic', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90009201, 1301852000, 'Random Box Character A', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90009301, 1301853000, 'Random Box Character B', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90009701, 1302014000, 'Random Box Woody A', 0, 2500, 5, 1, 1, 2, 5, 0, 2);
INSERT INTO "public"."shop" VALUES (90009801, 1302016000, 'Random Box Woody B', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90010001, 1301180000, 'RandomBox Sniper 7D_TAM', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90010101, 1301204000, 'RandomBox Platinum Box_TAM', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (110064430, 702001043, 'Combat Machet G[Golden Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064430, 1104003012, 'Golden Smile Mask[Golden Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064507, 100003040, 'Aug A3 D[Hot Star Set]', 0, 28000, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110064507, 601002068, 'HG_r.b454_ss28M_Mech[Hot Star Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064507, 1001001295, 'Hitman Viper Red[Hot Star Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064507, 1001002067, 'HideStrike[Hot Star Set] [R]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (90010201, 1301250000, 'RandomBox Premium AUG Box_TAM', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (110011230, 1500000100, 'Point 100,000[Aug A3 Black Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110064507, 1500000055, '55k Points [Hot Star Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067230, 100003340, 'Msbs Gold[Golden Warrior Set]', 0, 19500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110067230, 601002017, 'Python Gold[Golden Warrior Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067230, 1104003270, 'Mask Black Skull[Golden Warrior Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067230, 1300035030, 'Increased Grenade Slot[Golden Warrior Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067230, 1300242030, 'Special Weapon Slot[Golden Warrior Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067330, 100003295, 'Aug A3 DarkSteel[DarkSteel Assault Set]', 0, 18500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110067330, 601002098, 'Python DarkSteel[DarkSteel Assault Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067330, 702001159, 'FangBlade Steel[DarkSteel Assault Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110067330, 1102003006, 'Target Tracking HeadGearSet[DarkSteel Assault Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110068730, 601002049, 'Python Brazuca[Word Cup 2014 Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110068730, 702001052, 'FangBlade Brazuca[Word Cup 2014 Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110068730, 1001001054, 'WC 2014 Tarantula[Word Cup 2014 Set] [R]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110068730, 1001002053, 'WC 2014 Hide[Word Cup 2014 Set] [R]', 4321, 0, 2592000, 0, 1, 2, 0, 5, 1);
INSERT INTO "public"."shop" VALUES (110076030, 200004436, 'APC9 G. [Penetrator Set]', 0, 19500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110076030, 1104003294, 'MASK BOLT [Penetrator Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110076030, 1300027030, 'QUICK CHANGE MAGAZINE [Penetrator Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110076030, 1300170030, 'FULL METAL JACKET [Penetrator Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (10065901, 100003451, 'AUG  A3 M1LGR4U', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065903, 100003451, 'AUG  A3 M1LGR4U', 0, 4000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10066201, 200004601, 'KRISSSUPERV M1LGR4U DUMMY', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010601, 702015026, 'BONEKNIFE M1LGR4U', 0, 350, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (40003701, 803007077, 'K 400 M1LGR4U', 0, 200, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (110064430, 1300044030, 'BulletProofVestPlus[Golden Set]', 0, 0, 1, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (60000802, 1001001010, 'Viper Red (+30% Gold)', 24750, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002501, 1006003044, 'Raptor Mercury Dino (Reinforced Raptor)', 700, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60002801, 1001001015, 'Reinforced Combo D-Fox (+20% EXP) [R]', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000701, 1300009001, 'Fake Rank', 800, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90000702, 1300009007, 'Fake Rank', 3600, 0, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055801, 400006020, 'Kel-Tec KSG-15', 16000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10001101, 100003246, 'AK-12', 3000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (200004462, 200004461, 'OA93_Kemerde', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (601014025, 601014023, 'Scorpion_VZ61_Kemerde', 0, 1400, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006122, 400006118, 'Cerberus_Kemerde', 0, 1700, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (200004465, 200004464, 'MX4_Kemerde', 0, 800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006120, 400006118, 'Cerberus_Kemerde', 0, 500, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006121, 400006118, 'Cerberus_Kemerde', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (200004463, 200004461, 'OA93_Kemerde', 0, 1700, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (200004461, 200004461, 'OA93_Kemerde', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (200004464, 200004464, 'MX4_Kemerde', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (200004466, 200004464, 'MX4_Kemerde', 0, 1300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (300005241, 300005241, 'TacTilite_T2_Kemerde', 0, 750, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (300005243, 300005241, 'TacTilite_T2_Kemerde', 0, 1800, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (300005242, 300005241, 'TacTilite_T2_Kemerde', 0, 1350, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003375, 100003375, 'AUG_A3_Kermerde', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003376, 100003375, 'AUG_A3_Kermerde', 0, 1350, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003377, 100003375, 'AUG_A3_Kermerde', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003378, 100003376, 'PINDAD_SS2_V5_Kemerde', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (702001202, 702001202, 'Keris_Kemerde', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006118, 400006117, 'M1887_Kemerde', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (601014023, 601014023, 'Scorpion_VZ61_Kemerde', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (702001204, 702001202, 'Keris_Kemerde', 0, 1200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003379, 100003376, 'PINDAD_SS2_V5_Kemerde', 0, 1350, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003380, 100003376, 'PINDAD_SS2_V5_Kemerde', 0, 2000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (601014024, 601014023, 'Scorpion_VZ61_Kemerde', 0, 900, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006119, 400006117, 'M1887_Kemerde', 0, 1700, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (400006117, 400006117, 'M1887_Kemerde', 0, 500, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (702001203, 702001202, 'Keris_Kemerde', 0, 900, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (100003199, 100003199, 'AUG_A3_MEXICO', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031105, 100003201, 'AUG_A3_ECUADOR', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031101, 100003199, 'AUG_A3_MEXICO', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031102, 100003200, 'AUG_A3_BOLIVIA', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031104, 100003200, 'AUG_A3_BOLIVIA', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031107, 100003201, 'AUG_A3_ECUADOR', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031106, 100003201, 'AUG_A3_ECUADOR', 0, 800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031110, 100003202, 'AUG_A3_COLUMBIA', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031100, 100003199, 'AUG_A3_MEXICO', 0, 800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031108, 100003202, 'AUG_A3_COLUMBIA', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009603, 100003202, 'AUG A3 Colombia', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031117, 100003206, 'AUG_A3_PERU', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031118, 100003206, 'AUG_A3_PERU', 0, 800, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031119, 100003206, 'AUG_A3_PERU', 0, 1200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10017103, 100003288, 'bra', 0, 2100, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10063501, 100003454, 'ASSAULT_AUG_A3_PBWC2018', 0, 300, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10063802, 200004609, 'SMG_KRISSSUPERV_PBWC2018', 0, 1200, 604800, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20008901, 601002148, 'COLTPYTHON PBWC2018', 0, 200, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40003601, 803007079, 'THROWING_C5_PBWC2018', 0, 100, 86400, 2, 1, 1, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10027201, 200004151, 'Kriss S.V PC Cafe', 4000, 100, 86400, 2, 1, 2, 0, 4, 2);
INSERT INTO "public"."shop" VALUES (10041301, 300005089, 'L115A1 PC Cafe', 4000, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10035502, 200004295, 'Kriss S.V Lebaran2016', 0, 2300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002500, 1200040000, '10% Defense Up [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001301, 1300028001, 'MAX HP Up 10%', 0, 500, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031115, 100003205, 'AUG_A3_CHILE', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031114, 100003205, 'AUG_A3_CHILE', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031116, 100003205, 'AUG_A3_CHILE', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70003401, 1103003001, 'Assault Beret', 0, 10000, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10012902, 100003243, 'AUG A3 Monkey', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10012903, 100003243, 'AUG A3 Monkey', 0, 2400, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10012901, 100003243, 'AUG A3 Monkey', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10029903, 200004253, 'Kriss S.V Monkey', 0, 3500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (90009401, 1301854000, 'Random Box Camo Soldier', 0, 2500, 3, 1, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (110072630, 100003037, 'Aug A3 Gold[GM Selection Set]', 0, 13500, 2592000, 0, 1, 2, 0, 0, 1);
INSERT INTO "public"."shop" VALUES (110072630, 1104003251, 'Phantom Mask[GM Selection Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110072630, 803007026, 'Decoy Bomb[GM Selection Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (110072630, 702001051, 'FangBlade GSL 2014[GM Selection Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (10048901, 300005140, 'Cheytac M200 Monkey', 0, 430, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10048903, 300005140, 'Cheytac M200 Monkey', 0, 4300, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30005501, 702001120, 'Monkey Hammer', 0, 350, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10037302, 200004325, 'Kriss S.V SUPREME', 0, 2130, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10037402, 200004327, 'P90 Ext. SUPREME', 0, 1890, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10053501, 300005188, 'Cheytac M200 SUPREME', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10053502, 300005188, 'Cheytac M200 SUPREME', 0, 2580, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10061601, 400006082, 'M1887 SUPREME', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20006001, 601002100, 'C. Python SUPREME', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30007701, 702001161, 'Fang Blade SUPREME', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30005503, 702001120, 'Monkey Hammer', 0, 3500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10029901, 200004253, 'Kriss S.V Monkey', 0, 350, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10017101, 100003288, 'Groza Russian Normal', 0, 3500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10036301, 200004308, 'PP-19 Bizon Russian Deluxe', 0, 380, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052501, 300005178, 'Dragunov Russian Normal', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031103, 100003200, 'AUG_A3_BOLIVIA', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (40001701, 803007065, 'K-413 Russian Deluxe', 0, 100, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10008601, 100003192, 'AUG-A3 Rose', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003403, 904007010, 'Smoke Plus', 0, 700, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10008701, 100003193, 'AUG A3 LionFlame', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10055701, 300005108, 'Cheytac M200 Lionflame', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80016101, 1104003196, 'Máscara LionFlame', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10005903, 100003159, 'AUG A3 PBIC2014', 0, 4500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10003801, 100003120, 'AUG A3 PBIC2013', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30003901, 702001084, 'Machete de Combate Rose', 0, 150, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (50000201, 904007011, 'Medical Kit', 20000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018201, 100003299, 'AUG A3 SUPREME', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10061602, 400006082, 'M1887 SUPREME', 0, 3300, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003410, 100003304, 'Pindad SS2 V5 Mystic', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003411, 200004334, 'KrissSuperV Mystic', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003417, 400006085, 'M1887 Mystic', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003413, 200004334, 'KrissSuperV Mystic', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003418, 400006085, 'M1887 Mystic', 0, 2500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003419, 400006085, 'M1887 Mystic', 0, 3500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003420, 601002101, 'ColtPython Mystic', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003425, 702001164, 'FangBlade Mystic', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003428, 1104003262, 'Mask Mystic Blue', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (50001403, 904007061, 'Smoke Yellow', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20006002, 601002100, 'C. Python SUPREME', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30007702, 702001161, 'Fang Blade SUPREME', 0, 1800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20000502, 601013007, 'P99&HAK Reload', 36000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10048101, 300005132, 'Tactilite T2 G.', 0, 450, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041601, 300005123, 'Tactilite T2', 16000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20002301, 601002059, 'C. Python Rose', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003402, 904007010, 'Smoke Plus', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038504, 300005076, 'Dragunov Elite', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003508, 200004021, 'K1 Silver', 1500, 0, 2592000, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70003507, 200004021, 'K1 Silver', 500, 0, 604800, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038502, 200004136, 'OA-93 Gold', 0, 2480, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10038503, 200004136, 'OA-93 Gold', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70003404, 904007010, 'Smoke Plus', 0, 1200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70003506, 300005220, 'CheyTac M2000 CNPB T5', 0, 5000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003432, 100003352, 'AUG-A3 CNPB T5', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003434, 100003352, 'AUG-A3 CNPB T5', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003438, 200004412, ' P90 Ext. CNPB T5', 0, 150, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003500, 200004412, 'P90 Ext. CNPB T5', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003437, 100003353, 'SC-2010 CNPB T5', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003503, 300005220, 'CheyTac M2000 CNPB T5', 0, 4300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003506, 702001184, 'Karambit CNPB T5', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003435, 100003353, 'SC-2010 CNPB T5', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003427, 1104003262, 'Mask Mystic Blue', 0, 800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003405, 100003303, 'AUG A3 Mystic', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003406, 100003303, 'AUG A3 Mystic', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003407, 100003303, 'AUG A3 Mystc', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003408, 100003304, 'Pindad SS2 V5 Mystic', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003409, 100003304, 'Pindad SS2 V5 Mystic', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003412, 200004334, 'KrissSuperV Mystic', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003414, 300005191, 'Cheytac M2000 Mystic', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003415, 300005191, 'Cheytac M2000 Mystic', 0, 2000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003421, 601002101, 'ColtPython Mystic', 0, 800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003422, 601002101, 'ColtPython Mystic', 0, 1500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003423, 702001164, 'FangBlade Mystic', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003424, 702001164, 'FangBlade Mystic', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003426, 1104003262, 'Mask Mystic Blue', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003416, 300005191, 'Cheytac M2000 Mystic', 0, 3500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30007003, 702001149, 'Fang Blade Alien', 0, 3000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001403, 803007062, 'K-400 Alien', 0, 1000, 2592000, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10016301, 100003279, 'AUG A3 Alien', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10035601, 200004297, 'P90 Ext. Alien', 0, 320, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10035703, 200004298, 'Kriss S.V Alien', 0, 3200, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70003510, 100003312, 'AUG-A3 Latin6', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003511, 100003312, 'AUG-A3 Latin6', 0, 3500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003514, 200004339, 'Kriss SuperV Latin6', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003515, 200004341, 'P90 Ext Latin6', 0, 150, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10052001, 300005173, 'Cheytac M200 Alien', 0, 430, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20005201, 601002091, 'MK.23 Alien', 0, 100, 86400, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30007001, 702001149, 'Fang Blade Alien', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40001402, 803007062, 'K-400 Alien', 0, 600, 604800, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10016302, 100003279, 'AUG A3 Alien', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10035603, 200004297, 'P90 Ext. Alien', 0, 3200, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10052003, 300005173, 'Cheytac M200 Alien', 0, 4300, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20005202, 601002091, 'MK.23 Alien', 0, 600, 604800, 2, 1, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20002203, 601002058, 'C. Python Summer', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10055501, 300005106, 'L115A1 Summer', 0, 310, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10008401, 100003190, 'AUG A3 Summer', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003502, 300005220, 'CheyTac M2000 CNPB T5', 0, 400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (70003505, 702001184, 'Karambit CNPB T5', 0, 400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (70003436, 100003353, 'SC-2010 CNPB T5', 0, 400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (100558504, 100003408, 'AUG HBAR Gold', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (10008402, 100003190, 'AUG A3 Summer', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10031303, 200004191, 'Kriss S.V Summer', 0, 3500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10055503, 300005106, 'L115A1 Summer', 0, 3100, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10058601, 400006052, 'M1887 Summer', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20002202, 601002058, 'C. Python Summer', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10031301, 200004191, 'Kriss S.V Summer', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10008403, 100003190, 'AUG A3 Summer', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10031302, 200004191, 'Kriss S.V Summer', 0, 2130, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10055502, 300005106, 'L115A1 Summer', 0, 1860, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10058603, 400006052, 'M1887 Summer', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (80009301, 1104003119, 'PBTN DIGITAL MASK', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10041401, 300005021, 'Rangemaster .338', 11000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10039902, 200004032, 'P90 M.C D', 0, 1050, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10050601, 300005159, 'AS 50 G.', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000101, 601002014, 'RB 454 SS5M', 13000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20000301, 601002005, 'D-Eagle Silver', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10022701, 200004010, 'P90 MC', 10500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (20003201, 601002070, 'R.B 454 SS8M+S PBIC2015', 0, 300, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000701, 1001002009, 'Hide (+30% Gold)', 5500, 0, 50, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60001301, 1001002052, 'Leopard Bope', 0, 700, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60000803, 1001001010, 'Viper Red (+30% Gold)', 30000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030203, 200004260, 'Kriss S.V PBGC', 0, 3500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10000201, 100003013, 'G36C Ext.', 9000, 0, 100, 1, 1, 2, 0, 10, 0);
INSERT INTO "public"."shop" VALUES (30010003, 702001130, 'Fang Blade PBGC', 0, 3000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10014201, 100003257, 'AUG A3 PBGC', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10009803, 100003204, 'AUG A3 Argentina', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10030201, 200004260, 'Kriss S.V PBGC', 0, 350, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10050003, 300005152, 'Cheytac M200 PBGC', 0, 4300, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10060201, 400006068, 'M1887 PBGC', 0, 550, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30010001, 702001130, 'Fang Blade PBGC', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10014203, 100003257, 'AUG A3 PBGC', 0, 2400, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10050002, 300005152, 'Cheytac M200 PBGC', 0, 2580, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10060203, 400006068, 'M1887 PBGC', 0, 5500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10064801, 200004521, 'P90 EXT FIREDRAGON', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065203, 100003399, 'AUG A3 FIREDRAGON', 0, 3000, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009001, 601002134, 'COLTPYTHON FIREDRAGON', 0, 200, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20009002, 601002134, 'COLTPYTHON FIREDRAGON', 0, 800, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010501, 702001212, 'FANGBLADE FIREDRAGON', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010502, 702001212, 'FANGBLADE FIREDRAGON', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30010503, 702001212, 'FANGBLADE FIREDRAGON', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064702, 200004519, 'KRISSSUPERV FIREDRAGON', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20003501, 601002073, 'R.B 454 SS8M+S Cobra', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10053702, 300005190, 'Cheytac M200 Azerbaijan', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003517, 200004341, 'P90 Ext Latin6', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003516, 200004341, 'P90 Ext Latin6', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003521, 601002105, 'ColtPython Latin6', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003522, 601002105, 'ColtPython Latin6', 0, 800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003523, 601002105, 'ColtPython Latin6', 0, 1500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003524, 702001166, 'GH5007 Latin6', 0, 100, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003525, 702001166, 'GH5007 Latin6', 0, 600, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003526, 702001166, 'GH5007 Latin6', 0, 1000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031128, 200004416, 'KRISSSUPERV_LEBARAN2017', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70005001, 100003318, 'Aug A3 Hybridman', 0, 1500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005002, 100003318, 'Aug A3 Hybridman', 0, 4000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005003, 200004347, 'KrissSuperV Hybridman', 0, 300, 84600, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005006, 200004349, 'OA93 Hybridman', 0, 350, 84600, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005007, 200004349, 'OA93 Hybridman', 0, 1500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005008, 200004349, 'OA93 Hybridman', 0, 3500, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005009, 300005196, 'Cheytac M2000 Hybridman', 0, 500, 84600, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005010, 300005196, 'Cheytac M2000 Hybridman', 0, 5000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005011, 601002108, 'ColtPython Hybridman', 0, 200, 84600, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005013, 601002108, 'ColtPython Hybridman', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005014, 300005196, 'Cheytac M2000 Hybridman', 0, 2500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031121, 100003355, 'AUG_A3_LEBARAN2017', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031123, 100003356, 'SC_2010_LEBARAN2017', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031125, 100003356, 'SC_2010_LEBARAN2017', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031126, 200004416, 'KRISSSUPERV_LEBARAN2017', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10005603, 100003155, 'AUG A3 Brazuca', 0, 4000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (80004601, 1104003046, 'Latin Bahamas', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026303, 200004110, 'Kriss S.V Turkey', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10033701, 200004232, 'OA-93 Cobra', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70000202, 1102003003, 'Reinforced Headgear', 0, 680, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002501, 1300044001, '10% Defense Up', 0, 400, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (10019701, 100003052, 'FAMAS G2 M203', 0, 3200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020001, 100003064, 'Famas G2 Commando Gold', 0, 3500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031145, 100003106, 'Aug Italia', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10020801, 100003094, 'SCAR-L Carbine', 0, 2000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10041901, 300005145, 'PGM Hecate2', 19000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021002, 100003096, 'SCAR-L FC', 0, 100, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007101, 1301305000, 'Random Box GSL2016', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90009901, 1302017000, 'Random Box Halloween 2016', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (60003201, 1001001465, 'Bella_PinkChoco [R]', 0, 550, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031149, 1001001275, 'Bella WW2', 0, 1600, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031150, 1001001275, 'Bella WW2', 0, 5000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031151, 1001002278, 'Chou WW2', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031152, 1001002278, 'Chou WW2', 0, 1600, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031160, 1001001049, 'REBEL Famale GRS', 0, 350, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031161, 1001001049, 'REBEL Famale GRS', 0, 2200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031165, 1001002047, 'SWAT Famele GRS', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031154, 1001002311, 'Chou Invasion', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031155, 1001002311, 'Chou Invasion', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031156, 1001002311, 'Chou Invasion', 0, 2500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031159, 1001001320, 'Bella Invasion', 0, 2500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031173, 1103003022, 'Baret RussianDelux', 0, 930, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031168, 1103003021, 'Baret RussiaNormal', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031171, 1103003020, 'Baret Strik', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031166, 1103003021, 'Baret RussiaNormal', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031170, 1103003020, 'Baret Strik', 0, 930, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031169, 1103003020, 'Baret Strik', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003520, 300005193, 'CheyTac M2000 Latin6', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031174, 1103003022, 'Baret RussianDelux', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031167, 1103003021, 'Baret RussiaNormal', 0, 920, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031172, 1103003022, 'Baret RussianDelux', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30001702, 702001046, 'Amok Kukri Turkey', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30008203, 702015010, 'Faca de Osso Camo Soldier', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (110034330, 1102003003, 'Kit Pro A - Capacete avançado', 0, 0, 0, 0, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002502, 1300044007, '10% Defense Up', 0, 2000, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (10004302, 100003128, 'AUG A3 Azerbaijan', 0, 2400, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044501, 300005057, 'Cheytac M200 Bloody', 0, 430, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10044502, 300005057, 'Cheytac M200 Bloody', 0, 2580, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057001, 400006030, 'M1887 Bloody', 0, 550, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057003, 400006030, 'M1887 Bloody', 0, 5500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10009702, 100003203, 'AUG A3 Venezuela', 0, 1000, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90001800, 1200032000, 'FlashBang  Protection [E]', 0, 0, 0, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (30005001, 702001108, 'Fang Blade Cobra', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031205, 1001001013, 'ViperRed 120', 0, 4000, 2592000, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031204, 1001001013, 'ViperRed 120', 0, 1200, 604800, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031203, 1001001013, 'ViperRed 120', 0, 400, 86400, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031146, 100003106, 'Aug Italia', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031131, 200004418, 'P90_EXT_LEBARAN2017', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70002001, 1102003007, 'Capacete Avançado Plus', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031133, 300005222, 'TACTILITE_T2_LEBARAN2017', 0, 2700, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031134, 300005222, 'TACTILITE_T2_LEBARAN2017', 0, 4500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031135, 400006105, 'M1887_LEBARAN2017', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031136, 400006105, 'M1887_LEBARAN2017', 0, 3300, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031129, 200004418, 'P90_EXT_LEBARAN2017', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031137, 400006105, 'M1887_LEBARAN2017', 0, 5500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031138, 702001185, 'GH5007_LEBARAN2017', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031139, 702001185, 'GH5007_LEBARAN2017', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031140, 702001185, 'GH5007_LEBARAN2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031144, 300005268, 'Barret Black', 0, 1500, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031127, 200004416, 'KRISSSUPERV_LEBARAN2017', 0, 1900, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031130, 200004418, 'P90_EXT_LEBARAN2017', 0, 1900, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031147, 100003106, 'Aug Italia', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031124, 100003356, 'SC_2010_LEBARAN2017', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064701, 200004519, 'KRISSSUPERV FIREDRAGON', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064703, 200004519, 'KRISSSUPERV FIREDRAGON', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10065202, 100003399, 'AUG A3 FIREDRAGON', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031180, 200004639, 'KRISSSUPERV_ARCADE', 0, 1600, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031181, 200004641, 'OA93_ARCADE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031182, 200004641, 'OA93_ARCADE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70001803, 1103003018, 'Boina Vera Cruz 2016', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70003429, 601002081, 'Taurus 454SS Scope VeraCruz2016', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70005000, 100003318, 'Aug A3 Hybridman', 0, 300, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005005, 200004347, 'KrissSuperV Hybridman', 0, 3200, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70005012, 601002108, 'ColtPython Hybridman', 0, 750, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031242, 300005251, 'CHEYTAC_M200_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031240, 200004488, 'P90_EXT_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031241, 200004489, 'KRISSSUPERV_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031244, 400006119, 'M1887_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031243, 300005252, 'AS_50_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031239, 100003388, 'PINDAD_SS2_V5_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031245, 601002132, 'COLTPYTHON_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031246, 702001208, 'KUKRII_PBIC201', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031247, 803007076, 'C5_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031248, 100003389, 'K2C_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031238, 100003387, 'AUG_A3_PBIC2017', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10013703, 100003252, 'AK SOPMOD Sakura', 0, 2520, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026702, 200004115, 'Kriss S.V Sakura', 0, 2130, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (10049602, 300005148, 'Cheytac M200 Sakura', 0, 2580, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (20004302, 601002082, 'C. Python Sakura', 0, 1200, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (30009802, 702001127, 'Fang Blade Sakura', 0, 1800, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031250, 100003336, 'AUG_A3_SAMURAI', 0, 1000, 604800, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (10014801, 100003263, 'AUG A3 E-Sport2', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10014803, 100003263, 'AUG A3 E-Sport2', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10030802, 200004270, 'Kriss S.V E-Sport2', 0, 1740, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10050802, 300005161, 'Tactilite T2 E-Sports2', 0, 2700, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30008602, 702015014, 'Faca de Osso E-Sports2', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031210, 1301250000, 'Premium AUG Box', 0, 2500, 3, 1, 2, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031163, 1001002047, 'SWAT Famele GRS', 0, 350, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031164, 1001002047, 'SWAT Famele GRS', 0, 2200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031157, 1001001320, 'Bella Invasion', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031158, 1001001320, 'Bella Invasion', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031206, 1001002014, 'Hide 120', 0, 400, 86400, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031207, 1001002014, 'Hide 120', 0, 1200, 604800, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031208, 1001002014, 'Hide 120', 0, 4000, 2592000, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031200, 1001002027, 'Person Skin de 100 hp ct', 20000, 0, 500, 1, 1, 1, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031201, 1001001028, 'Person Skin de 100 hp tr', 10000, 0, 100, 1, 1, 1, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031202, 1001001028, 'Person Skin de  100 hp tr', 20000, 0, 500, 1, 1, 1, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031215, 100003429, 'SC_2010_NEVASCA', 0, 2400, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031217, 200004558, 'P90_EXT_NEVASCA', 0, 320, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031218, 200004558, 'P90_EXT_NEVASCA', 0, 1920, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031219, 200004558, 'P90_EXT_NEVASCA', 0, 3200, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031220, 300005284, 'L115A1_NEVASCA', 0, 310, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031221, 300005284, 'L115A1_NEVASCA', 0, 1860, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031222, 300005284, 'L115A1_NEVASCA', 0, 3100, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031224, 300005285, 'CHEYTAC_M200_NEVASCA', 0, 2580, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031225, 300005285, 'CHEYTAC_M200_NEVASCA', 0, 4300, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031226, 601002139, 'DESERTEAGLE_NEVASCA', 0, 100, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031227, 601002139, 'DESERTEAGLE_NEVASCA', 0, 600, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031213, 100003428, 'AUG_A3_NEVASCA', 0, 4000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031214, 100003429, 'SC_2010_NEVASCA', 0, 400, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031228, 601002139, 'DESERTEAGLE_NEVASCA', 0, 1100, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031229, 702001220, 'KARAMBIT_NEVASCA', 0, 200, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031230, 702001220, 'KARAMBIT_NEVASCA', 0, 800, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031231, 702001220, 'KARAMBIT_NEVASCA', 0, 1500, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031212, 100003428, 'AUG_A3_NEVASCA', 0, 2400, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031252, 200004385, 'KRISSSUPERV_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031253, 200004385, 'KRISSSUPERV_SAMURAI', 0, 1000, 604800, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031254, 200004385, 'KRISSSUPERV_SAMURAI', 0, 2000, 2592000, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031255, 300005210, 'TACTILITE_T2_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (70003504, 702001184, 'Karambit CNPB T5', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031237, 1103003028, 'BeretBlangkonKemerde', 0, 2500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031251, 100003336, 'AUG_A3_SAMURAI', 0, 2000, 2592000, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031249, 100003336, 'AUG_A3_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (30000101, 702023002, 'Black Knuckles ', 2500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30003801, 702001083, 'Nunchaku', 0, 230, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031256, 300005210, 'TACTILITE_T2_SAMURAI', 0, 1000, 604800, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031257, 300005210, 'TACTILITE_T2_SAMURAI', 0, 2000, 2592000, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031258, 601002115, 'GLOCK18_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031259, 601002115, 'GLOCK18_SAMURAI', 0, 1000, 604800, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031260, 601002115, 'GLOCK18_SAMURAI', 0, 2000, 2592000, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031261, 702015018, 'DUALKNIFE_DUAL_SWORD_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031262, 702015018, 'DUALKNIFE_DUAL_SWORD_SAMURAI', 0, 1000, 604800, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031263, 702015018, 'DUALKNIFE_DUAL_SWORD_SAMURAI', 0, 2000, 2592000, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (70003501, 300005220, 'CheyTac M2000 CNPB T5', 0, 500, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031314, 1103003027, 'BeretPBNC2017', 0, 2500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031235, 300005215, ' CHEYTAC_M200_COMIC', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031236, 702001181, 'KUKRII_COMIC', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031232, 100003345, 'AUG_A3_COMIC', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031234, 200004396, 'KRISSSUPERV_COMIC', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031177, 100003470, 'AUG_A3_ARCADE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031179, 200004639, 'KRISSSUPERV_ARCADE', 0, 900, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031183, 200004641, 'OA93_ARCADE', 0, 1700, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031184, 300005320, 'CHEYTAC_M200_ARCADE', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031185, 300005320, 'CHEYTAC_M200_ARCADE', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031186, 300005320, 'CHEYTAC_M200_ARCADE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031187, 300005321, 'TACTILITE_T2_ARCADE', 0, 400, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031188, 300005321, 'TACTILITE_T2_ARCADE', 0, 1300, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031189, 300005321, 'TACTILITE_T2_ARCADE', 0, 2100, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031190, 400006152, 'M1887_ARCADE', 0, 150, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031191, 400006152, 'M1887_ARCADE', 0, 900, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031192, 400006152, 'M1887_ARCADE', 0, 1800, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031193, 601014028, 'SCORPION_VZ61_ARCADE', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031194, 601014028, 'SCORPION_VZ61_ARCADE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031195, 601014028, 'SCORPION_VZ61_ARCADE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031196, 702001243, 'KNIFE_GH5007_ARCADE', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031198, 702001243, 'KNIFE_GH5007_ARCADE', 0, 1600, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031264, 100003358, 'AUG_A3_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031265, 200004420, 'P90_MC_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031266, 300005224, 'CHEYTAC_M200_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031267, 400006107, 'M1887_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031268, 601002120, 'COLTPYTHON_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031269, 702001187, 'GH5007_NAGI_DELUXE', 60000, 0, 604800, 2, 1, 2, 3, 2, 2);
INSERT INTO "public"."shop" VALUES (1002, 1104003079, '[FOR SET VISIBLE]Mask Reinforce Black[Aug A3 Black Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90002701, 1300065001, '90% Defense Up', 0, 900000, 604800, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031315, 200004419, ' P90_MC_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031316, 300005223, 'CHEYTAC_M200_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031317, 400006106, 'M1887_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031318, 601002119, 'COLTPYTHON_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031319, 702001186, 'GH5007_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031252, 200004385, 'KRISSSUPERV_SAMURAI', 0, 200, 86400, 2, 1, 2, 4, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031270, 100003382, 'AUG_A3_AGUILA', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031271, 100003383, 'SC_2010_AGUILA', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031272, 200004474, 'OA93_AGUILA', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031273, 300005248, 'CHEYTAC_M200_AGUILA', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031274, 702001205, 'GH5007_AGUILA', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031320, 100003357, 'AUG_A3_NAGI_BASIC', 60000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (70003509, 100003312, 'AUG-A3 Latin6', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003512, 200004339, 'Kriss SuperV Latin6', 0, 350, 84600, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003513, 200004339, 'Kriss SuperV Latin6', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031345, 100003283, 'AUG_A3_PUZZLE', 50000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10044503, 300005057, 'Cheytac M200 Bloody', 0, 4300, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10057002, 400006030, 'M1887 Bloody', 0, 3300, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031122, 100003355, 'AUG_A3_LEBARAN2017', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1039, 702001052, '[FOR SET VISIBLE]FangBlade Brazuca[Word Cup 2014 Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031132, 300005222, 'TACTILITE_T2_LEBARAN2017', 0, 450, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70002003, 1102003007, 'Capacete Avançado Plus', 0, 2300, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031352, 1103003003, 'BeretRifle', 0, 0, 0, 0, 0, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031354, 1103003005, 'BeretHandgun', 0, 0, 0, 0, 0, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031350, 1103003001, 'BeretAssault', 0, 0, 0, 0, 0, 0, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70001901, 1102003006, 'Capacete Rastreamento', 0, 150, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018701, 100003010, 'M4A1 Camoflage with Silencer', 0, 2000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031120, 100003355, 'AUG_A3_LEBARAN2017', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031346, 200004304, 'KRISSSUPERV_PUZZLE', 50000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031347, 200004306, 'P90_EXT_PUZZLE', 50000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031348, 300005177, 'TACTILITE_T2_PUZZLE', 50000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031349, 803007063, 'GRENADE_K_413_PUZZLE', 50000, 0, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031281, 100003372, 'SC_2010_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031279, 100003371, 'PINDAD_SS2_V5_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031282, 100003372, 'SC_2010_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031283, 100003372, 'SC_2010_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031284, 200004452, 'KRISSSUPERV_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031308, 702001198, 'KERIS_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031309, 702001198, 'KERIS_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031310, 702001198, 'KERIS_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031313, 702015019, 'DUALKNIFE_BONEKNIFE_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031276, 100003370, 'AUG_A3_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031277, 100003370, 'AUG_A3_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90002703, 1300065030, '90% Defense Up', 0, 100000000, 1, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10013501, 100003250, 'AUG A3 Cupido', 0, 4000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031374, 200004623, 'P90 EXT WHITTERABIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031375, 200004623, 'P90 EXT WHITTERABIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031377, 100003460, 'SC-2010 WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031419, 702015021, 'DUALKNIFE_DUAL_BONEKNIFE_MILITARY', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031408, 200004485, 'P90_EXT_MILITARY', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031409, 200004485, 'P90_EXT_MILITARY', 0, 1920, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031410, 200004485, 'P90_EXT_MILITARY', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031411, 200004486, 'OA93_MILITARY', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031412, 200004486, 'OA93_MILITARY', 0, 2500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031355, 100003463, 'AUG A3 PALADIN', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031402, 100003386, 'AUG_A3_MILITARY ', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031356, 100003463, 'AUG A3 PALADIN', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031414, 300005250, 'TACTILITE_T2_MILITARY', 0, 450, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031357, 100003463, 'AUG A3 PALADIN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031358, 200004626, 'KRISS SV PALADIN', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031322, 100003437, 'AUG_A3_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031323, 100003437, 'AUG_A3_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031325, 100003438, 'ASSAULT_SC_2010_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031326, 100003438, 'ASSAULT_SC_2010_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031327, 200004571, 'P90_EXT_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031328, 200004571, 'P90_EXT_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031329, 200004571, 'P90_EXT_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031330, 200004572, 'OA93_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031331, 200004572, 'OA93_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031332, 200004572, 'OA93_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031334, 200004574, 'KRISSSUPERV_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031335, 200004574, 'KRISSSUPERV_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031336, 300005289, 'TACTILITE_T2_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031337, 300005289, 'TACTILITE_T2_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031338, 300005289, 'TACTILITE_T2_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031339, 300005290, 'CHEYTAC_M200_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031340, 300005290, 'CHEYTAC_M200_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031341, 300005290, 'CHEYTAC_M200_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031342, 702001223, 'KARAMBIT_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031343, 702001223, 'KARAMBIT_GRSV', 0, 1000, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031344, 702001223, 'KARAMBIT_GRSV', 0, 2000, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031391, 1001002353, 'Hide_Vacance17', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90009001, 1301664000, 'Random Box Everyday Login Plus', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031392, 1001002353, 'Hide_Vacance17', 0, 1600, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031393, 1001002353, 'Hide_Vacance17', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031394, 1001001356, 'REBEL_Viper_Vacance17', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031395, 1001001356, 'REBEL_Viper_Vacance17', 0, 1600, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031396, 1001001356, 'REBEL_Viper_Vacance17', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031397, 100003245, 'AUG_A3_ARENA_DELUXE', 60000, 0, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031398, 300005142, 'CHEYTAC_M200_ARENA_DELUXE', 60000, 0, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031359, 200004626, 'KRISS SV PALADIN', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031415, 300005250, 'TACTILITE_T2_MILITARY', 0, 2700, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031416, 300005250, 'TACTILITE_T2_MILITARY', 0, 4500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (60003301, 1001001069, 'Bella FBI [R]', 0, 400, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031360, 200004626, 'KRISS SV PALADIN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031361, 200004628, 'OA-93 PALADIN', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031399, 400006064, 'M1887_ARENA_DELUXE', 60000, 0, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031400, 601002080, 'COLTPYTHON_ARENA_DELUXE', 60000, 0, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031401, 702001124, 'FANGBLADE_ARENA_DELUXE', 60000, 0, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031362, 200004628, 'OA-93 PALADIN', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031363, 200004628, 'OA-93 PALADIN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031364, 300005315, 'CHEYTAC PALADIN', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031365, 300005315, 'CHEYTAC PALADIN', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031367, 702001240, 'KNIFE_FANGBLADE_PALADIN', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031368, 702001240, 'KNIFE_FANGBLADE_PALADIN', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031369, 702001240, 'KNIFE_FANGBLADE_PALADIN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031405, 200004483, 'KRISSSUPERV_MILITARY', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031417, 702015021, 'DUALKNIFE_DUAL_BONEKNIFE_MILITARY', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031287, 200004454, 'P90_EXT_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031288, 200004454, 'P90_EXT_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031290, 200004455, 'OA93_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031291, 200004455, 'OA93_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031292, 200004455, 'OA93_PBNC2017', 0, 2000, 259200, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031293, 300005237, 'CHEYTAC_M200_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031294, 300005237, 'CHEYTAC_M200_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031295, 300005237, 'CHEYTAC_M200_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031296, 300005238, 'TACTILITE_T2_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031297, 300005238, 'TACTILITE_T2_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031298, 300005238, 'TACTILITE_T2_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031299, 400006113, 'M1887_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031300, 400006113, 'M1887_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031301, 400006113, 'M1887_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031302, 601002125, 'COLTPYTHON_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031303, 601002125, 'COLTPYTHON_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031304, 601002125, 'COLTPYTHON_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031307, 601002126, 'TAURUS_454SS_SCOPE_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031285, 200004452, 'KRISSSUPERV_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031305, 601002126, 'TAURUS_454SS_SCOPE_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031376, 100003460, 'SC-2010 WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031378, 100003460, 'SC-2010 WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031379, 300005311, 'L115A1 WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031380, 300005311, 'L115A1 WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031381, 300005311, 'L115A1 WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031382, 300005310, 'CHEYTAC WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031383, 300005310, 'CHEYTAC WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031384, 300005310, 'CHEYTAC WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031385, 601002150, 'HANDGUN_COLTPYTHON_WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031386, 601002150, 'HANDGUN_COLTPYTHON_WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031387, 601002150, 'HANDGUN_COLTPYTHON_WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031390, 702001237, 'KNIFE_BUTTERFLYKNIFE_WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031371, 100003459, 'AUG WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031372, 100003459, 'AUG WHITERABBIT', 0, 2000, 2592000, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031373, 200004623, 'P90 EXT WHITTERABIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031406, 200004483, 'KRISSSUPERV_MILITARY', 0, 1920, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031407, 200004483, 'KRISSSUPERV_MILITARY', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031404, 100003386, 'AUG_A3_MILITARY ', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031418, 702015021, 'DUALKNIFE_DUAL_BONEKNIFE_MILITARY', 0, 1400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031420, 1103003030, 'BeretMilitary', 0, 2750, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031413, 200004486, 'OA93_MILITARY', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10038902, 200004005, 'Kriss S.V Cupido', 60000, 1920, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10049502, 300005147, 'Cheytac M200 Cupid', 60000, 2580, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10059902, 400006065, 'M1887 Cupid', 60000, 3300, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031403, 100003386, 'AUG_A3_MILITARY ', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031449, 100003380, 'AUG_A3_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031450, 100003380, 'AUG_A3_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031451, 100003381, 'SC_2010_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031452, 100003381, 'SC_2010_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031453, 100003381, 'SC_2010_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031454, 200004471, 'KRISSSUPERV_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031455, 200004471, 'KRISSSUPERV_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031456, 200004471, 'KRISSSUPERV_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031457, 200004473, 'P90_EXT_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031458, 200004473, 'P90_EXT_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031459, 200004473, 'P90_EXT_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031460, 300005245, 'L115A1_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031462, 300005245, 'L115A1_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031463, 300005246, 'CHEYTAC_M200_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031464, 300005246, 'CHEYTAC_M200_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031465, 300005246, 'CHEYTAC_M200_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031466, 300005247, 'PGM_HECATE2_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031468, 300005247, 'PGM_HECATE2_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031469, 601014024, 'DUALHANDGUN_SCORPION_VZ61_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031470, 601014024, 'DUALHANDGUN_SCORPION_VZ61_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031471, 601014024, 'DUALHANDGUN_SCORPION_VZ61_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031472, 702001203, 'KARAMBIT_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031473, 702001203, 'KARAMBIT_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031474, 702001203, 'KARAMBIT_7TH_ANNIVERSARY', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10007001, 100003173, 'AUG A3 Cangaceiro', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10038701, 200004139, 'Kriss S.V Brazuca', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10045801, 300005083, 'Cheytac M200 Brazuca', 0, 430, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20008501, 601002049, 'C. Python Brazuca', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30002203, 702001052, 'Fang Blade Brazuca', 0, 3000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10005601, 100003155, 'AUG A3 Brazuca', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70004001, 1103003031, 'nan', 0, 230, 86400, 2, 1, 1, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10055877, 100003406, 'AUG HBAR', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90005801, 1301152000, 'Random Box Beast', 0, 2500, 3, 1, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031486, 200004312, 'KRISSSUPERV_PBIC2016', 0, 3200, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031487, 200004314, 'OA93_PBIC2016', 0, 400, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031488, 200004314, 'OA93_PBIC2016', 0, 2400, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031489, 200004314, 'OA93_PBIC2016', 0, 4000, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031503, 803007067, 'C5_PBIC2016', 0, 900, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031505, 100003249, 'AUG-A3_SILENCE', 0, 2400, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30009202, 702023007, 'Ballock Knuckle', 0, 300, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031366, 300005315, 'CHEYTAC PALADIN', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031461, 300005245, 'L115A1_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031467, 300005247, 'PGM_HECATE2_7TH_ANNIVERSARY', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (80017501, 1104003215, 'Máscara Spy-Normal', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30002602, 702001064, 'Badminton Racket', 0, 900, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031479, 100003292, 'SC_2010_PBIC2016', 0, 2400, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (10064201, 100003449, 'AUG A3 DIGITAL', 0, 300, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031480, 100003292, 'SC_2010_PBIC2016', 0, 4000, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031481, 100003293, 'K2C_PBIC2016', 0, 425, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031482, 100003293, 'K2C_PBIC2016', 0, 2500, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (10064202, 100003449, 'AUG A3 DIGITAL', 0, 1200, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10064403, 200004598, 'KRISSSUPERV DIGITAL', 0, 2500, 2592000, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031483, 100003293, 'K2C_PBIC2016', 0, 4000, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031475, 100003291, 'AUG_A3_PBIC2016', 0, 400, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031476, 100003291, 'AUG_A3_PBIC2016', 0, 2400, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031477, 100003291, 'AUG_A3_PBIC2016', 0, 4000, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031478, 100003292, 'SC_2010_PBIC2016', 0, 400, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031484, 200004312, 'KRISSSUPERV_PBIC2016', 0, 320, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031485, 200004312, 'KRISSSUPERV_PBIC2016', 0, 1920, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031490, 300005181, 'CHEYTAC_M200_PBIC2016', 0, 430, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (30003102, 702001070, 'Machete de Combate Cangaceiro', 60000, 1500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10013001, 100003244, 'AUG A3 Arena Normal', 60000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031448, 100003380, 'AUG_A3_7TH_ANNIVERSARY', 0, 200, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031491, 300005181, 'CHEYTAC_M200_PBIC2016', 0, 2580, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031424, 100003480, 'ASSAULT_AUG_HBAR_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031425, 100003480, 'ASSAULT_AUG_HBAR_RENEGADE2', 0, 2000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031426, 100003480, 'ASSAULT_AUG_HBAR_RENEGADE2', 0, 3000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031427, 200004657, 'SMG_OA93_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031428, 200004657, 'SMG_OA93_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031429, 200004657, 'SMG_OA93_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031433, 400006156, 'SHOTGUN_M1887_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031434, 400006156, 'SHOTGUN_M1887_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031435, 400006156, 'SHOTGUN_M1887_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031436, 300005331, 'SNIPER_TACTILITE_T2_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031437, 300005331, 'SNIPER_TACTILITE_T2_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031438, 300005331, 'SNIPER_TACTILITE_T2_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031439, 702001249, 'KNIFE_KARAMBIT_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031440, 702001249, 'KNIFE_KARAMBIT_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031441, 702001249, 'KNIFE_KARAMBIT_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031443, 200004659, 'SMG_KRISSSUPERV_SILENCE_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031445, 200004661, 'SMG_P90_EXT_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031446, 200004661, 'SMG_P90_EXT_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031447, 200004661, 'SMG_P90_EXT_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031492, 300005181, 'CHEYTAC_M200_PBIC2016', 0, 4300, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031493, 300005182, 'TACTILITE_T2_PBIC2016', 0, 430, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031494, 300005182, 'TACTILITE_T2_PBIC2016', 0, 2580, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031495, 300005182, 'TACTILITE_T2_PBIC2016', 0, 4300, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031496, 601002097, 'COLTPYTHON_PBIC2016', 0, 200, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031497, 601002097, 'COLTPYTHON_PBIC2016', 0, 700, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031498, 601002097, 'COLTPYTHON_PBIC2016', 0, 1500, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031499, 702001155, 'GH5007_PBIC2016', 0, 200, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031500, 702001155, 'GH5007_PBIC2016', 0, 700, 604800, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031501, 702001155, 'GH5007_PBIC2016', 0, 1500, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031502, 803007067, 'C5_PBIC2016', 0, 300, 86400, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031504, 803007067, 'C5_PBIC2016', 0, 1600, 2592000, 2, 1, 2, 1, 2, 2);
INSERT INTO "public"."shop" VALUES (1000031523, 200004481, 'P90_MC_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031525, 200004482, 'P90_EXT_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031527, 300005249, 'TACTILITE_T2_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031526, 200004482, 'P90_EXT_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031528, 300005249, 'TACTILITE_T2_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031529, 300005249, 'TACTILITE_T2_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031535, 601002131, 'COLTPYTHON_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031530, 601002130, 'TEC_9_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031536, 702015020, 'DUALKNIFE_BONEKNIFE_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031537, 702015020, 'DUALKNIFE_BONEKNIFE_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031538, 702015020, 'DUALKNIFE_BONEKNIFE_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (10064502, 300005300, 'CHEYTAC M200 DIGITAL', 0, 1520, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10014401, 100003259, 'AUG A3 Tiger-Normal', 60000, 0, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (30010401, 702015025, 'DUALKNIFE M9 DIGITAL', 0, 250, 86400, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20007501, 601002023, 'IMI Uzi 9mm', 0, 190, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007502, 601002023, 'IMI Uzi 9mm', 0, 1140, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20007503, 601002023, 'IMI Uzi 9mm', 0, 1900, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30002601, 702001064, 'Badminton Racket', 0, 200, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031514, 200004476, 'OA93_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031515, 200004478, 'MX4_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031516, 200004478, 'MX4_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031517, 200004478, 'MX4_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031518, 200004479, 'KRISSSUPERV_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031519, 200004479, 'KRISSSUPERV_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031520, 200004479, 'KRISSSUPERV_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031521, 200004481, 'P90_MC_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031522, 200004481, 'P90_MC_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031531, 601002130, 'TEC_9_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031506, 100003384, 'AUG_A3_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031507, 100003384, 'AUG_A3_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031508, 100003384, 'AUG_A3_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031509, 100003385, 'SC_2010_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031510, 100003385, 'SC_2010_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031511, 100003385, 'SC_2010_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031512, 200004476, 'OA93_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031513, 200004476, 'OA93_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031532, 601002130, 'TEC_9_PBST_ES', 0, 2000, 2592000, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031533, 601002131, 'COLTPYTHON_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1000031534, 601002131, 'COLTPYTHON_PBST_ES', 0, 1000, 604800, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (30010402, 702015025, 'DUALKNIFE M9 DIGITAL', 0, 1000, 604800, 2, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031524, 200004482, 'P90_EXT_PBST_ES', 0, 200, 86400, 2, 1, 2, 4, 4, 2);
INSERT INTO "public"."shop" VALUES (1010, 100003040, '', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031541, 100003271, 'AUG_A3_ID_1STANNI', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031233, 100003346, 'AK 47 COMIC', 0, 4500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031542, 200004280, 'KRISSSUPERV_ID_1STANNI', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031543, 200004280, 'KRISSSUPERV_ID_1STANNI', 0, 1890, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031544, 200004280, 'KRISSSUPERV_ID_1STANNI', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031545, 200004282, 'P90_ID_1STANNI', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031546, 200004282, 'P90_ID_1STANNI', 0, 1890, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031547, 200004282, 'P90_ID_1STANNI', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031548, 300005165, 'CHEYTAC_M200_ID_1STANNI', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031549, 300005165, 'CHEYTAC_M200_ID_1STANNI', 0, 2580, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031540, 100003271, 'AUG_A3_ID_1STANNI', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031539, 100003271, 'AUG_A3_ID_1STANNI', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90007301, 1301326000, 'Random Box DarkSteel', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90007401, 1301335000, 'Random Box Supreme', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031550, 300005165, 'CHEYTAC_M200_ID_1STANNI', 0, 4200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031551, 400006071, 'M1887_ID_1STANNI', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031552, 400006071, 'M1887_ID_1STANNI', 0, 3300, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031553, 400006071, 'M1887_ID_1STANNI', 0, 5500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031554, 702001144, 'KERIS_ID_1STANNI', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031555, 702001144, 'KERIS_ID_1STANNI', 0, 1380, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031559, 1103003019, 'BeretID1stAnni', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031557, 1103003019, 'BeretID1stAnni', 0, 230, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10013003, 100003244, 'AUG A3 Arena Normal', 30000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10049001, 300005141, 'Cheytac M200 Arena Normal', 15000, 0, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10018601, 100003233, 'AUG A3 SPY', 60000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031562, 100003350, 'AUG_A3_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031575, 300005219, 'TACTILITE_T2_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031564, 100003351, 'FAMAS_G2_COMMANDO_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031566, 200004408, 'KRISSSUPERV_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031567, 200004408, 'KRISSSUPERV_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031568, 200004408, 'KRISSSUPERV_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031569, 200018144, 'DUALSMG_OA93_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031570, 200018144, 'DUALSMG_OA93_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031571, 200018144, 'DUALSMG_OA93_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031558, 1103003019, 'BeretID1stAnni', 0, 920, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031563, 100003351, 'FAMAS_G2_COMMANDO_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031560, 100003350, 'AUG_A3_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031572, 300005218, 'CHEYTAC_M200_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031573, 300005218, 'CHEYTAC_M200_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031561, 100003350, 'AUG_A3_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031565, 100003351, 'FAMAS_G2_COMMANDO_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10014901, 100003264, 'Famas G2 M203 E-Sport2', 0, 3500, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10023801, 200018004, 'Dual Uzi', 1000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031587, 601002114, 'TEC-9 Gold', 9000, 0, 100, 1, 1, 0, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (20006101, 601013008, 'C. Python Cutlass', 0, 200, 86400, 2, 1, 2, 0, 1, 0);
INSERT INTO "public"."shop" VALUES (10020201, 100003068, 'AK-47 FC Red', 0, 4200, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (30006702, 702001146, 'Death Scythe Demonic', 0, 1680, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002702, 1300065007, '90% Defense Up', 0, 600000, 1, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (2698, 400006108, 'Zombie Slayer Infinitum', 0, 1200, 604800, 2, 2, 0, 0, 2, 2);
INSERT INTO "public"."shop" VALUES (10014902, 100003264, 'Famas G2 M203 E-Sport2', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10013902, 100003254, 'Water Gun 2016', 0, 320, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10042101, 300005060, 'Rangermaster .338 Reload', 12500, 0, 100, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10042102, 300005060, 'Rangermaster .338 Reload', 50000, 0, 500, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10047801, 300005128, 'Rangermaster .338 Camo Soldier', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10026403, 200004112, 'P90 M.C Bloody', 0, 3200, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10026402, 200004112, 'P90 M.C Bloody', 0, 1920, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004403, 100003129, 'AUG A3 Bloody', 0, 4000, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10004401, 100003129, 'AUG A3 Bloody', 0, 400, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (10054702, 300005097, 'Cheytac M200 Cangaceiro', 60000, 2580, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10007003, 100003173, 'AUG A3 Cangaceiro', 60000, 2400, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (10049003, 300005141, 'Cheytac M200 Arena Normal', 60000, 0, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10014403, 100003259, 'AUG A3 Tiger-Normal', 30000, 0, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031576, 300005219, 'TACTILITE_T2_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031577, 300005219, 'TACTILITE_T2_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10009701, 100003203, 'AUG A3 Venezuela', 0, 2500, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031578, 400006103, 'M1887_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031579, 400006103, 'M1887_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10058001, 400006042, 'Zombie Slayer', 0, 450, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031580, 400006103, 'M1887_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031556, 702001144, 'KERIS_ID_1STANNI', 0, 2300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031581, 601002118, 'COLTPYTHON_PBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031582, 601002118, 'COLTPYTHON_PBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031583, 601002118, 'COLTPYTHON_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10013301, 100003248, 'AUG A3 VeraCruz 2016', 0, 4000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30004703, 702001103, 'Bambu Afiado Bamboo-Runcing', 0, 1800, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30004701, 702001103, 'Bambu Afiado Bamboo-Runcing', 0, 180, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031588, 100003406, 'AUG_HBAR', 0, 400, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031589, 100003406, 'AUG_HBAR', 0, 2500, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031590, 100003406, 'AUG_HBAR', 0, 4100, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031584, 702001183, 'BUTTERFLYPBWC2017', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031585, 702001183, 'BUTTERFLYPBWC2017', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031586, 702001183, 'BUTTERFLYPBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031574, 300005218, 'CHEYTAC_M200_PBWC2017', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (40002201, 803007053, 'WaterBomb', 0, 250, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (40002202, 803007053, 'WaterBomb', 0, 1500, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (40002203, 803007053, 'WaterBomb', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30004702, 702001103, 'Bambu Afiado Bamboo-Runcing', 0, 1080, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031591, 601002104, 'LUGER_P08_Gold', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031592, 601002104, 'LUGER_P08_Gold', 0, 900, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031593, 601002104, 'LUGER_P08_Gold', 0, 1500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (20006701, 601014018, 'Scorpion Vz.61 G.', 0, 400, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (20006702, 601014018, 'Scorpion Vz.61 G.', 0, 2400, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031596, 601002103, 'LUGER_P08_Silver', 0, 1600, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031597, 601002103, 'LUGER_P08_Silver', 0, 300, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031598, 601002103, 'LUGER_P08_Silver', 0, 1000, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031175, 100003470, 'AUG_A3_ARCADE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031610, 200004439, 'OA93_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031611, 300005231, 'TACTILITE_T2_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031612, 300005231, 'TACTILITE_T2_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031613, 300005231, 'TACTILITE_T2_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031614, 702001195, 'GH5007_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031615, 702001195, 'GH5007_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031616, 702001195, 'GH5007_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031176, 100003470, 'AUG_A3_ARCADE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031178, 200004639, 'KRISSSUPERV_ARCADE', 0, 150, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031197, 702001243, 'KNIFE_GH5007_ARCADE', 0, 900, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10011401, 100003222, 'AUG A3 VeraCruz', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10032901, 200004220, 'P90 M.C VeraCruz', 0, 320, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10032902, 200004220, 'P90 M.C VeraCruz', 0, 2240, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10032903, 200004220, 'P90 M.C VeraCruz', 0, 3200, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10047301, 300005122, 'Cheytac M200 VeraCruz', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (10049201, 300005143, 'Cheytac M200 Vera Cruz 2016', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20003401, 601002072, 'C. Python VeraCruz', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (20003402, 601002072, 'C. Python VeraCruz', 0, 1200, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (20003403, 601002072, 'C. Python VeraCruz', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30004901, 702001106, 'Machete de Combate VeraCruz', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30004903, 702001106, 'Machete de Combate VeraCruz', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (30008301, 702015011, 'Dual Knife Vera Cruz 2016', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (30008303, 702015011, 'Dual Knife Vera Cruz 2016', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70001801, 1103003018, 'Boina Vera Cruz 2016', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70001802, 1103003018, 'Boina Vera Cruz 2016', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70003430, 601002081, 'Taurus 454SS Scope VeraCruz2016', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70003431, 601002081, 'Taurus 454SS Scope VeraCruz2016', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70005004, 200004347, 'KrissSuperV Hybridman', 0, 1300, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (50001001, 904007043, 'Medical Kit Kurma', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90000102, 1300002007, '130% EXP UP', 0, 1200, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10040801, 300005018, 'M4 SPR Lvl-1', 9000, 0, 100, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10043401, 300005020, 'M4 SRP Lvl-3', 0, 300, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (70004103, 1103003034, 'BeretM1LGR4U', 0, 2300, 2592000, 2, 1, 2, 1, 3, 2);
INSERT INTO "public"."shop" VALUES (1000031645, 200004036, 'M4_CQBR_LV3', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031647, 200004036, 'M4_CQBR_LV3', 0, 2400, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (30003601, 702001080, 'Field Shovel Royal', 0, 210, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90003601, 1301047000, 'Change nickname', 0, 1500, 1, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (90002103, 1300036030, 'Damage & Accuracy Up, Move Down', 0, 5000000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031141, 601002143, 'R.B GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031142, 601002143, 'R.B GRSV', 0, 900, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031143, 601002143, 'R.B GRSV', 0, 1500, 2592000, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031321, 100003437, 'AUG_A3_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031324, 100003438, 'ASSAULT_SC_2010_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031333, 200004574, 'KRISSSUPERV_GRSV', 0, 200, 86400, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031599, 100003365, 'AUG_A3_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (90006101, 1301202000, 'Random Box Silence', 0, 2500, 3, 1, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (90007001, 1301300000, 'Random Box Dolphin', 0, 2500, 3, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031600, 100003365, 'AUG_A3_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031601, 100003365, 'AUG_A3_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031602, 100003366, 'SC_2010_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031603, 100003366, 'SC_2010_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031604, 100003366, 'SC_2010_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031606, 200004437, 'KRISSSUPERV_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031607, 200004437, 'KRISSSUPERV_BOLT', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031608, 200004439, 'OA93_BOLT', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031609, 200004439, 'OA93_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031618, 100003364, 'AUG_A3_KAREEM', 0, 2400, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031643, 1104003294, 'Mask Bolt', 0, 2500, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031644, 200004437, 'KRISSSUPERV_BOLT', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031641, 1104003294, 'Mask Bolt', 0, 250, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031642, 1104003294, 'Mask Bolt', 0, 1500, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031619, 100003364, 'AUG_A3_KAREEM', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031620, 200004431, 'OA93_KAREEM', 0, 350, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031621, 200004431, 'OA93_KAREEM', 0, 2480, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031622, 200004431, 'OA93_KAREEM', 0, 4000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031623, 200004433, 'P90_MC_KAREEM', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031624, 200004433, 'P90_MC_KAREEM', 0, 1050, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031625, 200004433, 'P90_MC_KAREEM', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031626, 300005230, 'CHEYTAC_M200_KAREEM', 0, 430, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031627, 300005230, 'CHEYTAC_M200_KAREEM', 0, 2580, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031628, 300005230, 'CHEYTAC_M200_KAREEM', 0, 4300, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031629, 400006110, 'M1887_KAREEM', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031630, 400006110, 'M1887_KAREEM', 0, 3300, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031631, 400006110, 'M1887_KAREEM', 0, 5500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031632, 601002122, 'COLTPYTHON_KAREEM', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031633, 601002122, 'COLTPYTHON_KAREEM', 0, 1200, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031634, 601002122, 'COLTPYTHON_KAREEM', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031635, 702001193, 'KARAMBIT_KAREEM', 0, 250, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031636, 702001193, 'KARAMBIT_KAREEM', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031637, 702001193, 'KARAMBIT_KAREEM', 0, 2500, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031638, 702001194, 'FANGBLADE_KAREEM', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031639, 702001194, 'FANGBLADE_KAREEM', 0, 1800, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031640, 702001194, 'FANGBLADE_KAREEM', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031646, 200004036, 'M4_CQBR_LV3', 0, 900, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031617, 100003364, 'AUG_A3_KAREEM', 0, 400, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031649, 100003439, 'ASSAULT_AUG_A3_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031650, 100003439, 'ASSAULT_AUG_A3_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031651, 100003440, 'ASSAULT_SC_2010_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031652, 100003440, 'ASSAULT_SC_2010_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031655, 200004578, 'SMG_KRISSSUPERV_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031656, 200004578, 'SMG_KRISSSUPERV_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031657, 200004580, 'SMG_OA93_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031658, 200004580, 'SMG_OA93_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031659, 200004580, 'SMG_OA93_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031660, 200004582, 'SMG_P90_EXT_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031661, 200004582, 'SMG_P90_EXT_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031662, 200004582, 'SMG_P90_EXT_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031664, 300005291, 'SNIPER_TACTILITE_T2_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031663, 300005291, 'SNIPER_TACTILITE_T2_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031665, 300005291, 'SNIPER_TACTILITE_T2_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031666, 300005292, 'SNIPER_BARRETT_PREMIUM_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031667, 300005292, 'SNIPER_BARRETT_PREMIUM_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031669, 400006141, 'SHOTGUN_M1887_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031670, 400006141, 'SHOTGUN_M1887_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031671, 400006141, 'SHOTGUN_M1887_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031672, 601002144, 'HANDGUN_TAURUS_454SS_SCOPE_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031673, 601002144, 'HANDGUN_TAURUS_454SS_SCOPE_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031653, 100003440, 'ASSAULT_SC_2010_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031654, 200004578, 'SMG_KRISSSUPERV_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031696, 601034003, 'COMPOUND BOW GOLD', 0, 500, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031697, 601034003, 'COMPOUND BOW GOLD', 0, 3000, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031698, 601034003, 'COMPOUND BOW GOLD', 0, 5000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031648, 100003439, 'ASSAULT_AUG_A3_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031668, 300005292, 'SNIPER_BARRETT_PREMIUM_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031674, 601002144, 'HANDGUN_TAURUS_454SS_SCOPE_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031675, 702015024, 'DUALKNIFE_BONEKNIFE_NUSANTARA', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031676, 702015024, 'DUALKNIFE_BONEKNIFE_NUSANTARA', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031677, 702015024, 'DUALKNIFE_BONEKNIFE_NUSANTARA', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031678, 100003400, 'AUG_A3_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031679, 100003400, 'AUG_A3_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031680, 100003400, 'AUG_A3_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031681, 200004524, 'OA93_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031682, 200004524, 'OA93_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031683, 200004524, 'OA93_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031684, 200004526, 'P90_MC_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031685, 200004526, 'P90_MC_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031686, 200004526, 'P90_MC_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031687, 400006121, 'ZOMBIE_SLAYER_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031688, 400006121, 'ZOMBIE_SLAYER_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031689, 400006121, 'ZOMBIE_SLAYER_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031690, 601014025, ' DUALHANDGUN_SCORPION_VZ61_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031691, 601014025, ' DUALHANDGUN_SCORPION_VZ61_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031692, 601014025, ' DUALHANDGUN_SCORPION_VZ61_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031693, 702001213, 'FANGBLADE_LATIN7', 0, 300, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031694, 702001213, 'FANGBLADE_LATIN7', 0, 1500, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031695, 702001213, 'FANGBLADE_LATIN7', 0, 3000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031701, 601034004, 'COMPOUND BOW BLUE', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031289, 200004454, 'P90_EXT_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031421, 100003479, 'ASSAULT_AUG_A3_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031423, 100003479, 'ASSAULT_AUG_A3_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031444, 200004659, 'SMG_KRISSSUPERV_SILENCE_RENEGADE2', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031209, 1302379000, '2018 Premium Knife Box', 0, 2500, 3, 1, 2, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (90004401, 1301058000, 'Random Box Bomb', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90006201, 1301203000, 'Random Box E-Sport2', 0, 2500, 3, 1, 1, 1, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90008201, 1301648000, 'Random Box Dragunov Elite', 0, 2500, 3, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031702, 1001002053, 'Hide_Soccer', 0, 550, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031703, 1001002053, 'Hide_Soccer', 0, 1600, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031704, 1001002053, 'Hide_Soccer', 0, 4000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031705, 1001001054, 'REBEL_Soccer', 0, 550, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031706, 1001001054, 'REBEL_Soccer', 0, 1600, 604800, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031148, 1001001275, 'Bella WW2', 0, 550, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031153, 1001002278, 'Chou WW2', 0, 5000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031162, 1001001049, 'REBEL Famale GRS', 0, 4000, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (70004101, 1103003034, 'BeretM1LGR4U', 0, 230, 86400, 2, 1, 2, 1, 3, 2);
INSERT INTO "public"."shop" VALUES (70004102, 1103003034, 'BeretM1LGR4U', 0, 920, 604800, 2, 1, 2, 1, 3, 2);
INSERT INTO "public"."shop" VALUES (1000031707, 1001001054, 'REBEL_Soccer', 0, 4000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031709, 1001001415, 'Bella_HalloweenNurse', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031712, 1001002418, 'Chou_HalloweenNurse', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031710, 1001001415, 'Bella_HalloweenNurse', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031711, 1001002418, 'Chou_HalloweenNurse', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031713, 1001002418, 'Chou_HalloweenNurse', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031714, 1001001302, 'REBEL_Female_P1000', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031715, 1001001302, 'REBEL_Female_P1000', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031716, 1001001302, 'REBEL_Female_P1000', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031717, 1001002305, 'SWAT_Female_P1000', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031718, 1001002305, 'SWAT_Female_P1000', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031719, 1001002305, 'SWAT_Female_P1000', 0, 2500, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031708, 1001001415, 'Bella_HalloweenNurse', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031199, 1001002027, 'Person Skin de 100 hp ct', 10000, 0, 100, 1, 1, 1, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (80000901, 1104003009, 'No alvo', 1, 0, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (70003439, 200004412, 'P90 Ext. CNPB T5', 0, 400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (70003433, 100003352, 'AUG-A3 CNPB T5', 0, 400, 604800, 2, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031742, 100003317, 'AUG_A3_CHICKEN', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031699, 601034004, 'COMPOUND BOW BLUE', 0, 300, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031700, 601034004, 'COMPOUND BOW BLUE', 0, 1200, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (70003603, 1103003002, 'Sniper Beret', 0, 5000, 2592000, 2, 1, 1, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031353, 1103003004, 'BeretShotgun', 0, 5000, 2592000, 2, 1, 1, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031351, 1103003002, 'BeretSMG', 0, 5000, 2592000, 2, 1, 1, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031286, 200004452, 'KRISSSUPERV_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031306, 601002126, 'TAURUS_454SS_SCOPE_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031311, 702015019, 'DUALKNIFE_BONEKNIFE_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031278, 100003371, 'PINDAD_SS2_V5_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031280, 100003371, 'PINDAD_SS2_V5_PBNC2017', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031312, 702015019, 'DUALKNIFE_BONEKNIFE_PBNC2017', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031275, 100003370, 'AUG_A3_PBNC2017', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031422, 100003479, 'ASSAULT_AUG_A3_RENEGADE2', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031442, 200004659, 'SMG_KRISSSUPERV_SILENCE_RENEGADE2', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031737, 300005204, 'TACTILITE_T2_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031747, 200004345, 'KRISSSUPERV_CHICKEN', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031751, 601002107, 'COLTPYTHON_CHICKEN', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031753, 601002107, 'COLTPYTHON_CHICKEN', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031744, 100003317, 'AUG_A3_CHICKEN', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031745, 200004345, 'KRISSSUPERV_CHICKEN', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031746, 200004345, 'KRISSSUPERV_CHICKEN', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031748, 300005195, 'CHEYTAC_M200_CHICKEN', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031749, 300005195, 'CHEYTAC_M200_CHICKEN', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031752, 601002107, 'COLTPYTHON_CHICKEN', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031754, 702001168, 'CHICKEN_HAMMER', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031755, 702001168, 'CHICKEN_HAMMER', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031756, 702001168, 'CHICKEN_HAMMER', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031757, 1105003018, 'Chicken', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031758, 1105003018, 'Chicken', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031759, 1105003018, 'Chicken', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031720, 100003327, 'AUG_A3_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (10013503, 100003250, 'AUG A3 Cupido', 0, 1500, 604800, 2, 1, 2, 3, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031743, 100003317, 'AUG_A3_CHICKEN', 0, 1000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (70003518, 300005193, 'CheyTac M2000 Latin6', 0, 400, 84600, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90006001, 1301154000, 'Random Box Serpent', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90006301, 1301210000, 'Random Box PBWC', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90006401, 1301211000, 'Random Box Mummy', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90007201, 1301306000, 'Random Box Newborn2016', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90009501, 1301895000, 'Random Box Monkey', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90007501, 1301336000, 'Random Box Special PBIC', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (90010301, 1302122000, 'RandomBox Premium Cheytac Box_TAM', 0, 2500, 3, 1, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031721, 100003327, 'AUG_A3_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031722, 100003327, 'AUG_A3_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031723, 200004366, 'KRISSSUPERV_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031725, 200004366, 'KRISSSUPERV_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031726, 200004366, 'KRISSSUPERV_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031727, 200004368, 'OA93_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031728, 200004368, 'OA93_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031729, 200004368, 'OA93_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031731, 200004370, 'P90_EXT_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031732, 200004370, 'P90_EXT_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031733, 300005203, 'CHEYTAC_M200_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031734, 300005203, 'CHEYTAC_M200_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031735, 300005203, 'CHEYTAC_M200_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031736, 300005204, 'TACTILITE_T2_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031738, 300005204, 'TACTILITE_T2_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031739, 400006093, 'M1887_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031740, 400006093, 'M1887_CURSED_VALENTINE', 0, 1000, 604800, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031741, 400006093, 'M1887_CURSED_VALENTINE', 0, 2000, 2592000, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031370, 100003459, 'AUG WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031388, 702001237, 'KNIFE_BUTTERFLYKNIFE_WHITERABBIT', 0, 200, 86400, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (90006801, 1301298000, 'Random Box Alien', 0, 2500, 3, 1, 1, 4, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (90005901, 1301153000, 'Random Box Sakura', 0, 2500, 3, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (70003519, 300005193, 'CheyTac M2000 Latin6', 0, 2000, 604800, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031770, 100003347, 'AUG_A3_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031771, 100003348, 'SC_2010_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031772, 100003348, 'SC_2010_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031773, 100003348, 'SC_2010_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031774, 200004400, 'KRISSSUPERV_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031775, 200004400, 'KRISSSUPERV_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031776, 200004400, 'KRISSSUPERV_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031761, 200004352, 'MX4', 0, 150, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031762, 200004352, 'MX4', 0, 600, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031763, 200004352, 'MX4', 0, 1700, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031777, 200004402, 'P90_EXT_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031778, 200004402, 'P90_EXT_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031764, 200004354, 'MX4 Gold', 0, 2800, 2592000, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031779, 200004402, 'P90_EXT_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031765, 200004354, 'MX4 Gold', 0, 1200, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031780, 300005216, 'TACTILITE_T2_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031766, 200004354, 'MX4 Gold', 0, 300, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000401, 100003003, 'M4A1 Ext.', 4000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10000402, 100003003, 'M4A1 Ext.', 16000, 0, 500, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10002901, 100003005, 'F2000 Ext.', 600, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10021903, 100003114, 'M4A1 Elite', 0, 1800, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031767, 100003337, 'AUG_A3_RENEGADE', 0, 200, 86400, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031781, 300005216, 'TACTILITE_T2_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (80004901, 1104003049, 'Latin Chile', 0, 250, 86400, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031782, 300005216, 'TACTILITE_T2_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (80008201, 1104003098, 'Crazy Cartoon Mask Set (Ffuu Meme)', 0, 600, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031783, 400006102, 'M1887_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031784, 400006102, 'M1887_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031785, 400006102, 'M1887_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031786, 702001182, 'FANGBLADE_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031787, 702001182, 'FANGBLADE_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031788, 702001182, 'FANGBLADE_GREEN', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031789, 1103003026, 'BeretGreen', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031790, 1103003026, 'BeretGreen', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031791, 1103003026, 'BeretGreen', 0, 2000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90006501, 1301212000, 'Random Box Dragon', 0, 2500, 3, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (1001, 100003048, '[FOR SET VISIBLE]Aug A3 Black[Aug A3 Black Set]', 0, 0, 2592000, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (100031768, 1200017007, 'Get Dropped Weapon', 0, 300000, 1, 1, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (90000703, 1300009007, 'Fake Rank', 0, 3000, 1, 1, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (90006901, 1301299000, 'Random Box Blue Diamond', 0, 2500, 3, 1, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (90009101, 1301794000, 'Random Box PBIC2015', 0, 2500, 3, 1, 1, 2, 2, 0, 2);
INSERT INTO "public"."shop" VALUES (10023101, 200004099, 'SS1-R5 Carbine Reload', 1500, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10027702, 200004162, 'PP-19 Bizon Gold', 0, 2310, 604800, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10027701, 200004162, 'PP-19 Bizon Gold', 0, 380, 86400, 2, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (10056001, 400006043, 'Remington ETA', 12000, 0, 100, 1, 1, 2, 0, 0, 0);
INSERT INTO "public"."shop" VALUES (40000401, 803007026, 'Decoy Bomb', 0, 3000, 2592000, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (10007703, 100003182, 'TAR-21 Sheep', 0, 2340, 604800, 2, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (90001300, 1200027000, 'MAX HP Up 10% [E]', 0, 100000000, 0, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (110072630, 601002104, 'Luger p08 Gold[GM Selection Set]', 0, 0, 2592000, 0, 1, 2, 0, 0, 3);
INSERT INTO "public"."shop" VALUES (90001303, 1300028030, 'MAX HP Up 10%', 0, 1000000000, 1, 1, 1, 2, 0, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031760, 300005195, 'CHEYTAC_M200_CHICKEN', 0, 2000, 2592000, 2, 1, 2, 1, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031730, 200004370, 'P90_EXT_CURSED_VALENTINE', 0, 200, 86400, 2, 1, 2, 4, 0, 2);
INSERT INTO "public"."shop" VALUES (1000031211, 100003428, 'AUG_A3_NEVASCA', 0, 400, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031216, 100003429, 'SC_2010_NEVASCA', 0, 4000, 2592000, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031223, 300005285, 'CHEYTAC_M200_NEVASCA', 0, 430, 86400, 2, 1, 2, 1, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031389, 702001237, 'KNIFE_BUTTERFLYKNIFE_WHITERABBIT', 0, 1000, 604800, 2, 1, 2, 3, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031768, 100003347, 'AUG_A3_GREEN', 0, 200, 86400, 2, 1, 2, 4, 0, 0);
INSERT INTO "public"."shop" VALUES (1000031769, 100003347, 'AUG_A3_GREEN', 0, 1000, 604800, 2, 1, 2, 4, 0, 0);

-- ----------------------------
-- Table structure for site_accounts_confirm
-- ----------------------------
DROP TABLE IF EXISTS "public"."site_accounts_confirm";
CREATE TABLE "public"."site_accounts_confirm" (
  "id" int2 NOT NULL DEFAULT nextval('site_accounts_confirm_id_seq'::regclass),
  "email" varchar(245) COLLATE "pg_catalog"."default" NOT NULL,
  "login" varchar(16) COLLATE "pg_catalog"."default" NOT NULL,
  "password" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "ip" inet NOT NULL,
  "data" timestamp(6) NOT NULL DEFAULT now(),
  "usado" bool NOT NULL DEFAULT false,
  "token" varchar(32) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of site_accounts_confirm
-- ----------------------------
INSERT INTO "public"."site_accounts_confirm" VALUES (3, 'suporteprojectstar@gmail.com', 'adms', '816fe01011c7ca4ebe1712046ea2680c', '192.99.216.57', '2019-11-22 03:00:35.624009', 'f', '909892563ba8ec7dcd5c471cb27f9220');
INSERT INTO "public"."site_accounts_confirm" VALUES (4, 'suporteprojectstar@gmail.com', 'adm123', '816fe01011c7ca4ebe1712046ea2680c', '192.99.216.57', '2019-11-22 03:02:20.524877', 'f', '416d08effb3e91b1efe1f7ea2c84d15f');
INSERT INTO "public"."site_accounts_confirm" VALUES (5, 'suporteprojectstar@gmail.com', 'fsdfsdf', 'b6e59b9533ef42d0aa3382d42efae9bc', '192.99.216.57', '2019-11-22 03:04:05.279274', 't', 'a2a5e53fa1d7b209d8b1464f01b2a4ce');

-- ----------------------------
-- Table structure for site_news
-- ----------------------------
DROP TABLE IF EXISTS "public"."site_news";
CREATE TABLE "public"."site_news" (
  "id" int2 NOT NULL DEFAULT nextval('site_news_id_seq'::regclass),
  "url_id" varchar(100) COLLATE "pg_catalog"."default" NOT NULL,
  "imagem" varchar(200) COLLATE "pg_catalog"."default" NOT NULL,
  "keywords" varchar(160) COLLATE "pg_catalog"."default" NOT NULL,
  "titulo" varchar(60) COLLATE "pg_catalog"."default" NOT NULL,
  "descricao" varchar(300) COLLATE "pg_catalog"."default" NOT NULL,
  "conteudo" varchar COLLATE "pg_catalog"."default" NOT NULL,
  "data" timestamp(6) NOT NULL DEFAULT now(),
  "autor" int8 NOT NULL,
  "ip" inet,
  "access" int2 NOT NULL DEFAULT 0,
  "destaque" int2 NOT NULL DEFAULT 0,
  "cat" int2 DEFAULT 1
)
;

-- ----------------------------
-- Records of site_news
-- ----------------------------
INSERT INTO "public"."site_news" VALUES (57, 'first-new', 'https://image.freepik.com/vetores-gratis/cabeca-preta-legal-da-pantera_68946-261.jpg', 'teste', 'lalalaa', 'dessssssssssscriçaoooo', '&lt;!-- #######  YAY, I AM THE SOURCE EDITOR! #########--&gt;
&lt;h1 style=&quot;color: #5e9ca0;&quot;&gt;You can edit &lt;span style=&quot;color: #2b2301;&quot;&gt;this demo&lt;/span&gt; text!&lt;/h1&gt;
&lt;h2 style=&quot;color: #2e6c80;&quot;&gt;How to use the editor:&lt;/h2&gt;
&lt;p&gt;Paste your documents in the visual editor on the left or your HTML code in the source editor in the right. &lt;br /&gt;Edit any of the two areas and see the other changing in real time.&amp;nbsp;&lt;/p&gt;
&lt;p&gt;Click the &lt;span style=&quot;background-color: #2b2301; color: #fff; display: inline-block; padding: 3px 10px; font-weight: bold; border-radius: 5px;&quot;&gt;Clean&lt;/span&gt; button to clean your source code.&lt;/p&gt;
&lt;h2 style=&quot;color: #2e6c80;&quot;&gt;Some useful features:&lt;/h2&gt;
&lt;ol style=&quot;list-style: none; font-size: 14px; line-height: 32px; font-weight: bold;&quot;&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/01-interactive-connection.png&quot; alt=&quot;interactive connection&quot; width=&quot;45&quot; /&gt; Interactive source editor&lt;/li&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/02-html-clean.png&quot; alt=&quot;html cleaner&quot; width=&quot;45&quot; /&gt; HTML Cleaning&lt;/li&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/03-docs-to-html.png&quot; alt=&quot;Word to html&quot; width=&quot;45&quot; /&gt; Word to HTML conversion&lt;/li&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/04-replace.png&quot; alt=&quot;replace text&quot; width=&quot;45&quot; /&gt; Find and Replace&lt;/li&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/05-gibberish.png&quot; alt=&quot;gibberish&quot; width=&quot;45&quot; /&gt; Lorem-Ipsum generator&lt;/li&gt;
&lt;li style=&quot;clear: both;&quot;&gt;&lt;img style=&quot;float: left;&quot; src=&quot;https://html-online.com/img/6-table-div-html.png&quot; alt=&quot;html table div&quot; width=&quot;45&quot; /&gt; Table to DIV conversion&lt;/li&gt;
&lt;/ol&gt;
&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/p&gt;
&lt;h2 style=&quot;color: #2e6c80;&quot;&gt;Cleaning options:&lt;/h2&gt;
&lt;table class=&quot;editorDemoTable&quot;&gt;
&lt;thead&gt;
&lt;tr&gt;
&lt;td&gt;Name of the feature&lt;/td&gt;
&lt;td&gt;Example&lt;/td&gt;
&lt;td&gt;Default&lt;/td&gt;
&lt;/tr&gt;
&lt;/thead&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td&gt;Remove tag attributes&lt;/td&gt;
&lt;td&gt;&lt;img style=&quot;margin: 1px 15px;&quot; src=&quot;images/smiley.png&quot; alt=&quot;laughing&quot; width=&quot;40&quot; height=&quot;16&quot; /&gt; (except &lt;strong&gt;img&lt;/strong&gt;-&lt;em&gt;src&lt;/em&gt; and &lt;strong&gt;a&lt;/strong&gt;-&lt;em&gt;href&lt;/em&gt;)&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove inline styles&lt;/td&gt;
&lt;td&gt;&lt;span style=&quot;color: green; font-size: 13px;&quot;&gt;You &lt;strong style=&quot;color: blue; text-decoration: underline;&quot;&gt;should never&lt;/strong&gt;&amp;nbsp;use inline styles!&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove classes and IDs&lt;/td&gt;
&lt;td&gt;&lt;span id=&quot;demoId&quot;&gt;Use classes to &lt;strong class=&quot;demoClass&quot;&gt;style everything&lt;/strong&gt;.&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove all tags&lt;/td&gt;
&lt;td&gt;This leaves &lt;strong style=&quot;color: blue;&quot;&gt;only the plain&lt;/strong&gt; &lt;em&gt;text&lt;/em&gt;. &lt;img style=&quot;margin: 1px;&quot; src=&quot;images/smiley.png&quot; alt=&quot;laughing&quot; width=&quot;16&quot; height=&quot;16&quot; /&gt;&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove successive &amp;amp;nbsp;s&lt;/td&gt;
&lt;td&gt;Never use non-breaking spaces&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;to set margins.&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove empty tags&lt;/td&gt;
&lt;td&gt;Empty tags should go!&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove tags with one &amp;amp;nbsp;&lt;/td&gt;
&lt;td&gt;This makes&amp;nbsp;no sense!&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove span tags&lt;/td&gt;
&lt;td&gt;Span tags with &lt;span style=&quot;color: green; font-size: 13px;&quot;&gt;all styles&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove images&lt;/td&gt;
&lt;td&gt;I am an image: &lt;img src=&quot;images/smiley.png&quot; alt=&quot;laughing&quot; /&gt;&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove links&lt;/td&gt;
&lt;td&gt;&lt;a href=&quot;https://html-online.com&quot;&gt;This is&lt;/a&gt; a link.&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove tables&lt;/td&gt;
&lt;td&gt;Takes everything out of the table.&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Replace table tags with structured divs&lt;/td&gt;
&lt;td&gt;This text is inside a table.&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Remove comments&lt;/td&gt;
&lt;td&gt;This is only visible in the source editor &lt;!-- HELLO! --&gt;&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Encode special characters&lt;/td&gt;
&lt;td&gt;&lt;span style=&quot;color: red; font-size: 17px;&quot;&gt;&amp;hearts;&lt;/span&gt; &lt;strong style=&quot;font-size: 20px;&quot;&gt;☺ ★&lt;/strong&gt; &amp;gt;&amp;lt;&lt;/td&gt;
&lt;td&gt;&lt;strong style=&quot;font-size: 17px; color: #2b2301;&quot;&gt;x&lt;/strong&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;Set new lines and text indents&lt;/td&gt;
&lt;td&gt;Organize the tags in a nice tree view.&lt;/td&gt;
&lt;td&gt;&amp;nbsp;&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;
&lt;p&gt;&lt;strong&gt;&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Save this link into your bookmarks and share it with your friends. It is all FREE! &lt;/strong&gt;&lt;br /&gt;&lt;strong&gt;Enjoy!&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;', '2019-11-22 00:11:52', 2, '192.99.216.57', 2, 0, 1);

-- ----------------------------
-- Table structure for site_pincode
-- ----------------------------
DROP TABLE IF EXISTS "public"."site_pincode";
CREATE TABLE "public"."site_pincode" (
  "id" int2 NOT NULL DEFAULT nextval('site_pincode_id_seq'::regclass),
  "criador_id" int8 NOT NULL,
  "pin" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "valor" int2 NOT NULL DEFAULT 5000
)
;

-- ----------------------------
-- Table structure for site_pincode_logs
-- ----------------------------
DROP TABLE IF EXISTS "public"."site_pincode_logs";
CREATE TABLE "public"."site_pincode_logs" (
  "id" int2 NOT NULL DEFAULT nextval('site_pincode_logs_id_seq'::regclass),
  "login" int8 NOT NULL,
  "pin" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "valor" int2 NOT NULL,
  "ip" inet DEFAULT '0.0.0.0'::inet,
  "data" timestamp(6) NOT NULL DEFAULT now(),
  "criador_id" int8 NOT NULL
)
;

-- ----------------------------
-- Table structure for site_recuperar_senha
-- ----------------------------
DROP TABLE IF EXISTS "public"."site_recuperar_senha";
CREATE TABLE "public"."site_recuperar_senha" (
  "id" int2 NOT NULL DEFAULT nextval('site_recuperar_senha_id_seq'::regclass),
  "user_id" int2 NOT NULL,
  "token" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "ip" inet NOT NULL,
  "data" timestamp(6) NOT NULL DEFAULT now()
)
;

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
SELECT setval('"public"."account_id_seq"', 3, true);
ALTER SEQUENCE "public"."banimentos_id_seq"
OWNED BY "public"."banimentos"."id";
SELECT setval('"public"."banimentos_id_seq"', 2, true);
ALTER SEQUENCE "public"."block_mac_id_seq"
OWNED BY "public"."block_mac"."id";
SELECT setval('"public"."block_mac_id_seq"', 2, true);
SELECT setval('"public"."check_event_seq"', 19, true);
SELECT setval('"public"."clan_seq"', 307, true);
ALTER SEQUENCE "public"."player_items_id_seq"
OWNED BY "public"."player_items"."id";
SELECT setval('"public"."player_items_id_seq"', 2, true);
ALTER SEQUENCE "public"."player_messages_id_seq"
OWNED BY "public"."player_messages"."id";
SELECT setval('"public"."player_messages_id_seq"', 2, true);
ALTER SEQUENCE "public"."regras_id_seq"
OWNED BY "public"."regras"."id";
SELECT setval('"public"."regras_id_seq"', 892, true);
ALTER SEQUENCE "public"."shop_good_id_seq"
OWNED BY "public"."shop"."good_id";
SELECT setval('"public"."shop_good_id_seq"', 2707, true);
ALTER SEQUENCE "public"."site_accounts_confirm_id_seq"
OWNED BY "public"."site_accounts_confirm"."id";
SELECT setval('"public"."site_accounts_confirm_id_seq"', 6, true);
ALTER SEQUENCE "public"."site_news_id_seq"
OWNED BY "public"."site_news"."id";
SELECT setval('"public"."site_news_id_seq"', 58, true);
ALTER SEQUENCE "public"."site_pincode_id_seq"
OWNED BY "public"."site_pincode"."id";
SELECT setval('"public"."site_pincode_id_seq"', 2, true);
ALTER SEQUENCE "public"."site_pincode_logs_id_seq"
OWNED BY "public"."site_pincode_logs"."id";
SELECT setval('"public"."site_pincode_logs_id_seq"', 2, true);
ALTER SEQUENCE "public"."site_recuperar_senha_id_seq"
OWNED BY "public"."site_recuperar_senha"."id";
SELECT setval('"public"."site_recuperar_senha_id_seq"', 2, true);

-- ----------------------------
-- Primary Key structure for table banimentos
-- ----------------------------
ALTER TABLE "public"."banimentos" ADD CONSTRAINT "banimentos_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table block_mac
-- ----------------------------
ALTER TABLE "public"."block_mac" ADD CONSTRAINT "block_mac_mac_key" UNIQUE ("mac");

-- ----------------------------
-- Primary Key structure for table block_mac
-- ----------------------------
ALTER TABLE "public"."block_mac" ADD CONSTRAINT "block_mac_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table clan_data
-- ----------------------------
ALTER TABLE "public"."clan_data" ADD CONSTRAINT "clan_data_pkey" PRIMARY KEY ("clan_id");

-- ----------------------------
-- Uniques structure for table contas
-- ----------------------------
ALTER TABLE "public"."contas" ADD CONSTRAINT "accounts_login" UNIQUE ("login");

-- ----------------------------
-- Primary Key structure for table contas
-- ----------------------------
ALTER TABLE "public"."contas" ADD CONSTRAINT "accounts_pkey" PRIMARY KEY ("player_id") WITH (fillfactor=23);

-- ----------------------------
-- Primary Key structure for table player_configs
-- ----------------------------
ALTER TABLE "public"."player_configs" ADD CONSTRAINT "player_configs_pkey" PRIMARY KEY ("owner_id");

-- ----------------------------
-- Uniques structure for table regras
-- ----------------------------
ALTER TABLE "public"."regras" ADD CONSTRAINT "regras_item_id_key" UNIQUE ("item_id");

-- ----------------------------
-- Primary Key structure for table regras
-- ----------------------------
ALTER TABLE "public"."regras" ADD CONSTRAINT "regras_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table site_accounts_confirm
-- ----------------------------
ALTER TABLE "public"."site_accounts_confirm" ADD CONSTRAINT "site_accounts_confirm_token_key" UNIQUE ("token");

-- ----------------------------
-- Primary Key structure for table site_accounts_confirm
-- ----------------------------
ALTER TABLE "public"."site_accounts_confirm" ADD CONSTRAINT "site_accounts_confirm_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table site_news
-- ----------------------------
ALTER TABLE "public"."site_news" ADD CONSTRAINT "site_news_url_id_key" UNIQUE ("url_id");

-- ----------------------------
-- Primary Key structure for table site_news
-- ----------------------------
ALTER TABLE "public"."site_news" ADD CONSTRAINT "site_news_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table site_pincode
-- ----------------------------
ALTER TABLE "public"."site_pincode" ADD CONSTRAINT "site_pincode_pin_key" UNIQUE ("pin");

-- ----------------------------
-- Primary Key structure for table site_pincode
-- ----------------------------
ALTER TABLE "public"."site_pincode" ADD CONSTRAINT "site_pincode_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table site_pincode_logs
-- ----------------------------
ALTER TABLE "public"."site_pincode_logs" ADD CONSTRAINT "site_pincode_logs_pin_key" UNIQUE ("pin");

-- ----------------------------
-- Primary Key structure for table site_pincode_logs
-- ----------------------------
ALTER TABLE "public"."site_pincode_logs" ADD CONSTRAINT "site_pincode_logs_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table site_recuperar_senha
-- ----------------------------
ALTER TABLE "public"."site_recuperar_senha" ADD CONSTRAINT "site_recuperar_senha_token_key" UNIQUE ("token");

-- ----------------------------
-- Primary Key structure for table site_recuperar_senha
-- ----------------------------
ALTER TABLE "public"."site_recuperar_senha" ADD CONSTRAINT "site_recuperar_senha_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Foreign Keys structure for table banimentos
-- ----------------------------
ALTER TABLE "public"."banimentos" ADD CONSTRAINT "banimentos_player_fkey" FOREIGN KEY ("player") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."banimentos" ADD CONSTRAINT "banimentos_staffer_fkey" FOREIGN KEY ("staffer") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table friends
-- ----------------------------
ALTER TABLE "public"."friends" ADD CONSTRAINT "friends_friend_id_fkey" FOREIGN KEY ("friend_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."friends" ADD CONSTRAINT "friends_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table nick_history
-- ----------------------------
ALTER TABLE "public"."nick_history" ADD CONSTRAINT "nick_history_player_id_fkey" FOREIGN KEY ("player_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table player_items
-- ----------------------------
ALTER TABLE "public"."player_items" ADD CONSTRAINT "player_items_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table player_messages
-- ----------------------------
ALTER TABLE "public"."player_messages" ADD CONSTRAINT "player_messages_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table site_news
-- ----------------------------
ALTER TABLE "public"."site_news" ADD CONSTRAINT "site_news_autor_fkey" FOREIGN KEY ("autor") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table site_pincode
-- ----------------------------
ALTER TABLE "public"."site_pincode" ADD CONSTRAINT "site_pincode_criador_id_fkey" FOREIGN KEY ("criador_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table site_pincode_logs
-- ----------------------------
ALTER TABLE "public"."site_pincode_logs" ADD CONSTRAINT "site_pincode_logs_criador_id_fkey" FOREIGN KEY ("criador_id") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."site_pincode_logs" ADD CONSTRAINT "site_pincode_logs_login_fkey" FOREIGN KEY ("login") REFERENCES "public"."contas" ("player_id") ON DELETE NO ACTION ON UPDATE NO ACTION;
